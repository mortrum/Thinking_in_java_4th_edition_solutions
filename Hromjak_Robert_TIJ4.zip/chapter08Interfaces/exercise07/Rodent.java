package exercise07;

public interface Rodent {
	void what();
}
