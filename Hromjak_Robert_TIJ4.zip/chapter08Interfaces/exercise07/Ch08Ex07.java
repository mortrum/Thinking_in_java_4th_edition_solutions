package exercise07;

class Mouse implements Rodent {
	public void what() {
		System.out.println("Mouse");
	}
}

class Gerbil implements Rodent {
	public void what() {
		System.out.println("Gerbil");
	}
}

class Hamster implements Rodent {
	public void what() {
		System.out.println("Hamster");
	}
}

public class Ch08Ex07 {

	/**
	 * Exercise 7: (1) Change Exercise 9 in the Polymorphism chapter so that Rodent
	 * is an interface.
	 * 
	 * @param args
	 * @return Mouse Gerbil Hamster
	 * 
	 */
	public static void main(String[] args) {
		Mouse mouse = new Mouse();
		Gerbil gerbil = new Gerbil();
		Hamster hamster = new Hamster();
		mouse.what();
		gerbil.what();
		hamster.what();
	}
}
