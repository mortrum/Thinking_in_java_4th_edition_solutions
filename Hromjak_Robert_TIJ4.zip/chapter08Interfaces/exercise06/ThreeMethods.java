package exercise06;

public interface ThreeMethods {
	void one();

	void two();

	void three();

}
