package exercise01;

abstract class Rodent {
	abstract void what();
}

class Mouse extends Rodent {
	void what() {
		System.out.println("Mouse");
	}
}

class Gerbil extends Rodent {
	void what() {
		System.out.println("Gerbil");
	}
}

class Hamster extends Rodent {
	void what() {
		System.out.println("Hamster");
	}
}

public class Ch08Ex01 {

	/**
	 * Exercise 1: (1) Modify Exercise 9 in the previous chapter so that Rodent is
	 * an abstract class. Make the methods of Rodent abstract whenever possible.
	 * 
	 * @param args
	 * @return Mouse Gerbil Hamster
	 */
	public static void main(String[] args) {
		Rodent[] rodents = { new Mouse(), new Gerbil(), new Hamster() };
		for (Rodent rodent : rodents) {
			rodent.what();
		}
	}
}
