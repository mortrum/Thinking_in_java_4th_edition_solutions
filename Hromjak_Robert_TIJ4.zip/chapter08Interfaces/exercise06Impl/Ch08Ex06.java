package exercise06Impl;

import exercise06.ThreeMethods;

public class Ch08Ex06 implements ThreeMethods {

	@Override
	public void one() {
		System.out.println("one");

	}

	@Override
	public void two() {
		System.out.println("two");

	}

	@Override
	public void three() {
		System.out.println("three");

	}

	/**
	 * Exercise 6: (2) Prove that all the methods in an interface are automatically
	 * public.
	 * 
	 * @param args
	 * @return one two three
	 * 
	 */
	public static void main(String[] args) {
		Ch08Ex06 demo = new Ch08Ex06();
		demo.one();
		demo.two();
		demo.three();
	}
}
