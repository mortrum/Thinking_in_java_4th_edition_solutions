package exercise18;

interface Cycle {
	void name();
}

interface CycleFactory {
	Cycle getCycle();
}

class Unicycle implements Cycle {
	public Unicycle() {

	}

	@Override
	public void name() {
		System.out.println("Unicycle Impl");
	}
}

class UnicycleFactory implements CycleFactory {
	public Cycle getCycle() {
		return new Unicycle();
	}
}

class Bicycle implements Cycle {
	public Bicycle() {

	}

	@Override
	public void name() {
		System.out.println("Bicycle Impl");
	}
}

class BicycleFactory implements CycleFactory {
	public Cycle getCycle() {
		return new Bicycle();
	}
}

class Tricycle implements Cycle {
	public Tricycle() {

	}

	@Override
	public void name() {
		System.out.println("Tricycle Impl");

	}
}

class TricycleFactory implements CycleFactory {
	public Cycle getCycle() {
		return new Tricycle();
	}
}

public class Ch08Ex18 {

	public static void cycleConsumer(CycleFactory fact) {
		Cycle c = fact.getCycle();
		c.name();
	}

	/**
	 * Exercise 18: (2) Create a Cycle interface, with implementations Unicycle,
	 * Bicycle and Tricycle. Create factories for each type of Cycle, and code that
	 * uses these factories.
	 * 
	 * @param args
	 * @return Unicycle Impl
	 * 		   Bicycle Impl 
	 * 		   Tricycle Impl
	 * 
	 */
	public static void main(String[] args) {
		cycleConsumer(new UnicycleFactory());
		cycleConsumer(new BicycleFactory());
		cycleConsumer(new TricycleFactory());
	}

}
