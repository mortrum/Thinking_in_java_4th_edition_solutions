package exercise13;

interface A{
	
}

interface B extends A{
	
}

interface C extends A{
	
}

interface D extends B, C{
	
}
public class Ch08Ex13 {

	/**
	 * Exercise 13: (2) Create an interface, and inherit two new interfaces from
	 * that interface. Multiply inherit a third interface from the second two.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

	}

}
