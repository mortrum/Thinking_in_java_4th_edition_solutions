package exercise15;


interface A {
	void a1();

	void a2();
}

interface B {
	void b1();

	void b2();
}

interface C {
	void c1();

	void c2();
}

abstract class Tripple implements A, B, C {
	abstract void newMethod();
}


class TrippleImpl extends Tripple {

	@Override
	public void a1() {
		// TODO Auto-generated method stub

	}

	@Override
	public void a2() {
		// TODO Auto-generated method stub

	}

	@Override
	public void b1() {
		// TODO Auto-generated method stub

	}

	@Override
	public void b2() {
		// TODO Auto-generated method stub

	}

	@Override
	public void c1() {
		// TODO Auto-generated method stub

	}

	@Override
	public void c2() {
		// TODO Auto-generated method stub

	}

	@Override
	public void newMethod() {
		// TODO Auto-generated method stub

	}

	void f1(A a) {

	}

	void f2(B b) {

	}

	void f3(C c) {

	}

	void f4(Tripple tripple) {

	}

}

public class Ch08Ex15 {

	/**
	 * Exercise 15: (2) Modify the previous exercise by creating an abstract class
	 * and inheriting that into the derived class.
	 * 
	 * @param args
	 * @return
	 */
	public static void main(String[] args) {
		TrippleImpl trippleImpl = new TrippleImpl();
		trippleImpl.a1();
		trippleImpl.a2();
		trippleImpl.b1();
		trippleImpl.b2();
		trippleImpl.c1();
		trippleImpl.c2();
		trippleImpl.f1(trippleImpl);
		trippleImpl.f2(trippleImpl);
		trippleImpl.f3(trippleImpl);
		trippleImpl.f4(trippleImpl);
	}
}
