package exercise14;

interface A {
	void a1();

	void a2();
}

interface B {
	void b1();

	void b2();
}

interface C {
	void c1();

	void c2();
}

interface Tripple extends A, B, C{
	void newMethod();
}

class ConcreteClass{
	
}

class TrippleImpl extends ConcreteClass implements Tripple{

	@Override
	public void a1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void a2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void b1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void b2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void c1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void c2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void newMethod() {
		// TODO Auto-generated method stub
		
	}
	
	void f1(A a) {
		
	}
	
	void f2(B b) {
		
	}
	
	void f3(C c) {
		
	}
	
	void f4(Tripple tripple) {
		
	}
	
}

public class Ch08Ex14 {

	/**
	 * Exercise 14: (2) Create three interfaces, each with two methods. Inherit a
	 * new interface that combines the three, adding a new method. Create a class by
	 * implementing the new interface and also inheriting from a concrete class. Now
	 * write four methods, each of which takes one of the four interfaces as an
	 * argument. In main( ), create an object of your class and pass it to each of
	 * the methods.
	 * 
	 * @param args
	 * @return 
	 */
	public static void main(String[] args) {
		TrippleImpl trippleImpl = new TrippleImpl();
		trippleImpl.a1();
		trippleImpl.a2();
		trippleImpl.b1();
		trippleImpl.b2();
		trippleImpl.c1();
		trippleImpl.c2();
		trippleImpl.f1(trippleImpl);
		trippleImpl.f2(trippleImpl);
		trippleImpl.f3(trippleImpl);
		trippleImpl.f4(trippleImpl);

	}
}
