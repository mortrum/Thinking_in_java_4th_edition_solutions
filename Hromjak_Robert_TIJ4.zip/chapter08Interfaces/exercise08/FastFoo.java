package exercise08;

public interface FastFoo {
	void meal();

	void lunch();
}
