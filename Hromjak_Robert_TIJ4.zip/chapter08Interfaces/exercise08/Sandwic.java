package exercise08;

public interface Sandwic extends FastFoo {
	void pickle();

	void bread();

	void cheese();

	void lettuce();
}
