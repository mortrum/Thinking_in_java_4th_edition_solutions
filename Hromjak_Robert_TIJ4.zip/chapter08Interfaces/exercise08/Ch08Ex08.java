package exercise08;

class MySandvich implements Sandwic{

	@Override
	public void meal() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void lunch() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pickle() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void bread() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void cheese() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void lettuce() {
		// TODO Auto-generated method stub
		
	}
	
}

public class Ch08Ex08 {

	/**
	 * Exercise 8: (2) In polymorphism.Sandwich.java, create an interface called
	 * FastFoo d (with appropriate methods) and change Sandwic h so that it also
	 * implements FastFood.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		
	}
}
