package exercise05Impl;

import exercise05.ThreeMethods;

public class ThreeMethodsImpl implements ThreeMethods {

	@Override
	public void one() {
		// TODO Auto-generated method stub

	}

	@Override
	public void two() {
		// TODO Auto-generated method stub

	}

	@Override
	public void three() {
		// TODO Auto-generated method stub

	}

	/**
	 * Exercise 5: (2) Create an interface containing three methods, in its own
	 * package. Implement the interface in a different package.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

	}

}
