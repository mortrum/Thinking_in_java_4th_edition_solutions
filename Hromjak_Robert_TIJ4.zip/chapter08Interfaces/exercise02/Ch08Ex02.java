package exercise02;

abstract class Abstract{
	
}

public class Ch08Ex02 {

	/**
	 * Exercise 2: (1) Create a class as abstract without including any abstract
	 * methods and verify that you cannot create any instances of that class.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// ! Abstract abstract1 = new Abstract();
	}
}
