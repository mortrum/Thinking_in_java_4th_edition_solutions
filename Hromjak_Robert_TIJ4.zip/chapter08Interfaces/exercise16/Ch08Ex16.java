package exercise16;

import java.io.IOException;
import java.nio.CharBuffer;
import java.util.Random;
import java.util.Scanner;

class SequenceOfChars implements Readable {
	private static Random rand = new Random(47);
	private static final char[] capitals = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
	private static final char[] lowers = "abcdefghijklmnopqrstuvwxyz".toCharArray();
	private static final char[] vowels = "aeiou".toCharArray();
	private int count;

	public SequenceOfChars(int count) {
		this.count = count;
	}

	public int read(CharBuffer cb) {
		if (count-- == 0)
			return -1; // Indicates end of input
		cb.append(capitals[rand.nextInt(capitals.length)]);
		for (int i = 0; i < 4; i++) {
			cb.append(vowels[rand.nextInt(vowels.length)]);
			cb.append(lowers[rand.nextInt(lowers.length)]);
		}
		cb.append(" ");
		return 10; // Number of characters appended

	}
}

public class Ch08Ex16 {

	/**
	 * Exercise 16: (3) Create a class that produces a sequence of chars. Adapt this
	 * class so that it can be an input to a Scanner object.
	 * 
	 * @param args
	 * @return Yazeruyac Fowenucor Goeazimom Raeuuacio Nuoadesiw Hageaikux Ruqicibui
	 *         Numasetih Kuuuuozog Waqizeyoy
	 */
	public static void main(String[] args) {
		Scanner s = new Scanner(new SequenceOfChars(10));
		while (s.hasNext())
			System.out.println(s.next());
	}
}
