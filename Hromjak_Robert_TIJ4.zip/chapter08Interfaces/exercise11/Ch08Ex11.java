package exercise11;

import static net.mindview.util.Print.print;

interface Processor {
	String name();

	Object process(Object input);
} /// :~

class Producer {

	String toString(char[] c) {
		String s = "";
		for (int i = 0; i < c.length; i++)
			s = s + c[i];
		return s;
	}

	String swap(String s) {
		char[] c = s.toCharArray();
		for (int i = 0; i < c.length - 1; i += 2) {
			char tmp = c[i];
			c[i] = c[i + 1];
			c[i + 1] = tmp;

		}

		return toString(c);
	}
}

class ProducerAdapter implements Processor{
	public String name() {					//Just an implementation of interface's method that returns a name of class.
		return "ProducerAdapter"; 
		}
	Producer prod;
	public ProducerAdapter(Producer prod) {	//Constructor saves argument's Producer object into a field of Adapter 
		this.prod = prod;
	}
	public String process(Object input) {	//A Producer filed's method is called via Processor interface 
		return prod.swap((String)input);
	}	
}

public class Ch08Ex11 {

	public static void process(Processor p, Object s) {
		print("Using Processor " + p.name());
		print(p.process(s));
	}

	/**
	 * Exercise 11: (4) Create a class with a method that takes a String argument
	 * and produces a result that swaps each pair of characters in that argument.
	 * Adapt the class so that it works with interfaceprocessor.Apply.process( ).
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		String s = "123456789";
		process(new ProducerAdapter(new Producer()), s);
	}
}
/*
Using Processor ProducerAdapter
214365879
*/