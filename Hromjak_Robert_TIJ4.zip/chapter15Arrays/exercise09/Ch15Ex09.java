package exercise09;

import java.util.ArrayList;

class Peel<T> {
}

class Banana {
}

public class Ch15Ex09 {

	/**
	 * Exercise 9: (3) Create the classes necessary for the Peel<Banana> example and
	 * show that the compiler doesn�t accept it. Fix the problem using an ArrayList.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		ArrayList<Peel<Banana>> apb = new ArrayList<Peel<Banana>>();
	}
}
