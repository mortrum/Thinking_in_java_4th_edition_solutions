package exercise08;

import java.util.Arrays;

class ArrayOfGenericType<T> {
	T[] array; // OK

	@SuppressWarnings("unchecked")
	public ArrayOfGenericType(int size) {
		array = (T[]) new Object[size];
	}

	public void insertFirst(T t) {
		array[0] = t;
	}

	@SuppressWarnings("unchecked")
	public <U> U[] makeArray() {
		return (U[]) new Object[10];
	}
}

public class Ch15Ex08 {

	/*
	 * Exercise 8: (1) Demonstrate the assertions in the previous paragraph.
	 */
	public static void main(String[] args) {
		ArrayOfGenericType<String> agt = new ArrayOfGenericType<String>(10);
		agt.insertFirst("Hello");
		Object[] str = agt.makeArray();
		System.out.println(Arrays.toString(str));
	}
}
/*
[null, null, null, null, null, null, null, null, null, null]
*/