package exercise16;

import java.util.Arrays;

import net.mindview.util.Generated;

class PrimConv {
	public static boolean[] toPrim(Boolean[] ba) {
		boolean[] b = new boolean[ba.length];
		for (int j = 0; j < ba.length; j++) {
			b[j] = ba[j];
		}
		return b;
	}

	public static int[] toPrim(Integer[] ia) {
		int[] i = new int[ia.length];
		for (int j = 0; j < ia.length; j++) {
			i[j] = ia[j];
		}
		return i;
	}

	public static long[] toPrim(Long[] la) {
		long[] l = new long[la.length];
		for (int j = 0; j < la.length; j++) {
			l[j] = la[j];
		}
		return l;
	}

	public static short[] toPrim(Short[] sa) {
		short[] s = new short[sa.length];
		for (int j = 0; j < sa.length; j++) {
			s[j] = sa[j];
		}
		return s;
	}

	public static float[] toPrim(Float[] fa) {
		float[] f = new float[fa.length];
		for (int j = 0; j < fa.length; j++) {
			f[j] = fa[j];
		}
		return f;
	}

	public static double[] toPrim(Double[] da) {
		double[] d = new double[da.length];
		for (int j = 0; j < da.length; j++) {
			d[j] = da[j];
		}
		return d;
	}

	public static byte[] toPrim(Byte[] ba) {
		byte[] b = new byte[ba.length];
		for (int j = 0; j < ba.length; j++) {
			b[j] = ba[j];
		}
		return b;
	}

	public static char[] toPrim(Character[] ca) {
		char[] c = new char[ca.length];
		for (int j = 0; j < ca.length; j++) {
			c[j] = ca[j];
		}
		return c;
	}

}

public class Ch15Ex16 {
	/**
	 * Exercise 16: (3) Starting with CountingGenerator.java, create a SkipGenerator
	 * class that produces new values by incrementing according to a constructor
	 * argument. Modify TestArrayGeneration.java to show that your new class works
	 * correctly.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		int size = 6;
		SkipGenerator sg = new SkipGenerator(2);

		boolean[] a1 = PrimConv.toPrim(Generated.array(Boolean.class, sg.new Boolean(), size));
		System.out.println("a1 = " + Arrays.toString(a1));
		byte[] a2 = PrimConv.toPrim(Generated.array(Byte.class, sg.new Byte(), size));
		System.out.println("a2 = " + Arrays.toString(a2));
		char[] a3 = PrimConv.toPrim(Generated.array(Character.class, sg.new Character(), size));
		System.out.println("a3 = " + Arrays.toString(a3));
		short[] a4 = PrimConv.toPrim(Generated.array(Short.class, sg.new Short(), size));
		System.out.println("a4 = " + Arrays.toString(a4));
		int[] a5 = PrimConv.toPrim(Generated.array(Integer.class, sg.new Integer(), size));
		System.out.println("a5 = " + Arrays.toString(a5));
		long[] a6 = PrimConv.toPrim(Generated.array(Long.class, sg.new Long(), size));
		System.out.println("a6 = " + Arrays.toString(a6));
		float[] a7 = PrimConv.toPrim(Generated.array(Float.class, sg.new Float(), size));
		System.out.println("a7 = " + Arrays.toString(a7));
		double[] a8 = PrimConv.toPrim(Generated.array(Double.class, sg.new Double(), size));
		System.out.println("a8 = " + Arrays.toString(a8));
	}
}
/*
 * a1 = [false, false, false, false, false, false] a2 = [2, 4, 6, 8, 10, 12] a3
 * = [c, c, c, c, c, c] a4 = [2, 4, 6, 8, 10, 12] a5 = [2, 4, 6, 8, 10, 12] a6 =
 * [2, 4, 6, 8, 10, 12] a7 = [2.0, 4.0, 6.0, 8.0, 10.0, 12.0] a8 = [2.0, 4.0,
 * 6.0, 8.0, 10.0, 12.0]
 */
