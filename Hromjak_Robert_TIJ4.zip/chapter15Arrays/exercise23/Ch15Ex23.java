package exercise23;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Random;

public class Ch15Ex23 {

	/**
	 * Exercise 23: (2) Create an array of Integer, fill it with random int values
	 * (using autoboxing), and sort it into reverse order using a Comparator.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Random rand = new Random();
		Integer[] array = new Integer[3];
		for (int i = 0; i < 3; i++) {
			array[i] = rand.nextInt(10);
		}
		
		Arrays.sort(array, Collections.reverseOrder());
		System.out.println(Arrays.toString(array));
	}
}
/*
[7, 6, 5]
*/