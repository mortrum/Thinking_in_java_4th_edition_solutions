package exercise19;

import java.util.Arrays;

class Item {
	int i;

	public Item(int i) {
		super();
		this.i = i;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		if (i != other.i)
			return false;
		return true;
	}

}

public class Ch15Ex19 {

	/**
	 * Exercise 19: (2) Create a class with an int field that�s initialized from a
	 * constructor argument. Create two arrays of these objects, using identical
	 * initialization values for each array, and show that Arrays.equals( ) says
	 * that they are unequal. Add an equals( ) method to your class to fix the
	 * problem.
	 * 
	 * @param args
	 * @return true
	 * 
	 */
	public static void main(String[] args) {
		Item[] items = new Item[3];
		Item[] items2 = new Item[3];

		for (int i = 0; i < 3; i++) {
			items[i] = new Item(i);
			items2[i] = new Item(i);
		}
		System.out.println(Arrays.equals(items, items2));
	}
}
/*
true
*/