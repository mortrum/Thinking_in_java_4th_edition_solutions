package exercise21;

import java.util.Arrays;
import java.util.Comparator;

class BerylliumSphere {
	private static long counter;
	private final long id = counter++;

	public String toString() {
		return "Sphere " + id;
	}

	public long getId() {
		return id;
	}
	
}

class SphereComparator implements Comparator<BerylliumSphere> {

	public int compare(BerylliumSphere s1, BerylliumSphere s2) {
		return (int) (s1.getId() - s2.getId());
	}

	public int reversed(BerylliumSphere s1, BerylliumSphere s2) {
		return (int) (s2.getId() - s1.getId());
	}

}

public class Ch15Ex21 {

	/**
	 * Exercise 21: (3) Try to sort an array of the objects in Exercise 18.
	 * Implement Comparable to fix the problem. Now create a Comparator to sort the
	 * objects into reverse order.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		BerylliumSphere[] array = { new BerylliumSphere(), new BerylliumSphere(), new BerylliumSphere() };
		BerylliumSphere[] arrayCopy = new BerylliumSphere[3];
		System.arraycopy(array, 0, arrayCopy, 0, array.length);

		Arrays.sort(array, new SphereComparator());

		System.out.println(Arrays.toString(array));
		System.out.println(Arrays.toString(arrayCopy));
		
		Arrays.sort(array, new SphereComparator().reversed());
		

		System.out.println(Arrays.toString(array));
		System.out.println(Arrays.toString(arrayCopy));
		
		
	}
}

/*
	[Sphere 0, Sphere 1, Sphere 2]
	[Sphere 0, Sphere 1, Sphere 2]
	[Sphere 2, Sphere 1, Sphere 0]
	[Sphere 0, Sphere 1, Sphere 2]
*/
