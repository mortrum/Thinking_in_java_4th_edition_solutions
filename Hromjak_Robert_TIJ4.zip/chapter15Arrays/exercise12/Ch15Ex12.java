package exercise12;

import java.util.Arrays;

import net.mindview.util.CountingGenerator;

public class Ch15Ex12 {

	/**
	 * Exercise 12: (1) Create an initialized array of double using
	 * CountingGenerator. Print the results.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		CountingGenerator.Double genD=new CountingGenerator.Double();
		
		Double[] array = {genD.next(), genD.next(), genD.next()};
		
		System.out.println(Arrays.toString(array));

	}
}
/*
[0.0, 1.0, 2.0]
*/