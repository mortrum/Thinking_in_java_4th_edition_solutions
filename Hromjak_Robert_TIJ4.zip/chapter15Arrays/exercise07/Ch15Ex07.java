package exercise07;

import java.util.Arrays;

class BerylliumSphere {
	private static long counter;
	private final long id = counter++;

	public String toString() {
		return "Sphere " + id;
	}
}

public class Ch15Ex07 {
	static BerylliumSphere[][][] create(int x, int y, int z) {
		BerylliumSphere[][][] tmp = new BerylliumSphere[x][y][z];
		for (int i = 0; i < x; i++) {
			for (int j = 0; j < y; j++) {
				for (int k = 0; k < z; k++) {
					tmp[i][j][k] = new BerylliumSphere();
				}
			}
		}

		return tmp;
	}

	/**
	 * Exercise 7: (1) Repeat the previous exercise for a 3-D array.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(Arrays.deepToString(create(2, 3, 2)));
	}
}
/*
[[[Sphere 0, Sphere 1], [Sphere 2, Sphere 3], [Sphere 4, Sphere 5]], [[Sphere 6, Sphere 7], [Sphere 8, Sphere 9], [Sphere 10, Sphere 11]]]
*/