package exercise18;

import java.util.Arrays;

class BerylliumSphere {
	private static long counter;
	private final long id = counter++;

	public String toString() {
		return "Sphere " + id;
	}
}

public class Ch15Ex18 {

	/**
	 * Exercise 18: (3) Create and fill an array of BerylliumSphere. Copy this array
	 * to a new array and show that it�s a shallow copy.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		BerylliumSphere[] array = { new BerylliumSphere(), new BerylliumSphere(), new BerylliumSphere() };
		BerylliumSphere[] arrayCopy = new BerylliumSphere[3];
		System.arraycopy(array, 0, arrayCopy, 0, array.length);
		System.out.println(Arrays.toString(array));
		System.out.println(Arrays.toString(arrayCopy));
	}
}
/*
[Sphere 0, Sphere 1, Sphere 2]
[Sphere 0, Sphere 1, Sphere 2]
*/