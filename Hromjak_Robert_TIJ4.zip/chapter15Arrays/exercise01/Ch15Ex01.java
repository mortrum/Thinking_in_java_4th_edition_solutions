package exercise01;

class BerylliumSphere {
	private static long counter;
	private final long id;

	
	public BerylliumSphere() {
		super();
		id = counter++;
	}


	public String toString() {
		return "Sphere " + id;
	}
}

public class Ch15Ex01 {

	static void print(BerylliumSphere[] berylliumSpheres) {

		for (BerylliumSphere berylliumSphere : berylliumSpheres) {
			System.out.println(berylliumSphere);
		}
	}

	/**
	 * Exercise 1: (2) Create a method that takes an array of BerylliumSphere as an
	 * argument. Call the method, creating the argument dynamically. Demonstrate
	 * that ordinary aggregate array initialization doesn�t work in this case.
	 * Discover the only situations where ordinary aggregate array initialization
	 * works, and where dynamic aggregate initialization is redundant.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		print(new BerylliumSphere[] { new BerylliumSphere(), new BerylliumSphere(), new BerylliumSphere()});
	}
}
/*
Sphere 0
Sphere 1
Sphere 2
*/