package exercise02;

import java.util.Arrays;

class BerylliumSphere {
	private static long counter;
	private final long id = counter++;

	public String toString() {
		return "Sphere " + id;
	}
}

public class Ch15Ex02 {

	static BerylliumSphere[] create(int n) {
		BerylliumSphere[] tmp = new BerylliumSphere[n];
		for (int i = 0; i < n; i++) {
			tmp[i] = new BerylliumSphere();
		}
		return tmp;
	}

	/**
	 * Exercise 2: (1) Write a method that takes an int argument and returns an
	 * array of that size, filled with BerylliumSphere objects.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(Arrays.toString(create(6)));
	}
}
/*
[Sphere 0, Sphere 1, Sphere 2, Sphere 3, Sphere 4, Sphere 5]
*/