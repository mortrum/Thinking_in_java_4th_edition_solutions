package exercise14;

import java.util.Arrays;

import net.mindview.util.CountingGenerator;

public class Ch15Ex14 {

	/**
	 * Exercise 14: (6) Create an array of each primitive type, then fill each array
	 * by using CountingGenerator. Print each array.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		CountingGenerator.Boolean b = new CountingGenerator.Boolean();
		CountingGenerator.Integer ii = new CountingGenerator.Integer();
		CountingGenerator.Long l = new CountingGenerator.Long();
		CountingGenerator.Short s = new CountingGenerator.Short();
		CountingGenerator.Float f = new CountingGenerator.Float();
		CountingGenerator.Double d = new CountingGenerator.Double();
		CountingGenerator.Byte bt = new CountingGenerator.Byte();
		CountingGenerator.Character c = new CountingGenerator.Character();

		Boolean[] ba = { b.next(), b.next() };
		Integer[] ia = { ii.next(), ii.next() };
		Long[] la = { l.next(), l.next() };
		Short[] sa = { s.next(), s.next() };
		Float[] fa = { f.next(), f.next() };
		Double[] da = { d.next(), d.next() };
		Byte[] bta = { bt.next(), bt.next() };
		Character[] ca = { c.next(), c.next() };

		System.out.println(Arrays.toString(ba));
		System.out.println(Arrays.toString(ia));
		System.out.println(Arrays.toString(la));
		System.out.println(Arrays.toString(sa));
		System.out.println(Arrays.toString(fa));
		System.out.println(Arrays.toString(da));
		System.out.println(Arrays.toString(bta));
		System.out.println(Arrays.toString(ca));
	}
}
/*
[true, false]
[0, 1]
[0, 1]
[0, 1]
[0.0, 1.0]
[0.0, 1.0]
[0, 1]
[a, b]
*/