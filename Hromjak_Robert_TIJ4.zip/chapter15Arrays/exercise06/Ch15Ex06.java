package exercise06;

import java.util.Arrays;

class BerylliumSphere {
	private static long counter;
	private final long id = counter++;

	public String toString() {
		return "Sphere " + id;
	}
}

public class Ch15Ex06 {

	static BerylliumSphere[][] create(int x, int y) {
		BerylliumSphere[][] tmp = new BerylliumSphere[x][y];
		for (int i = 0; i < x; i++) {
			for (int j = 0; j < y; j++) {
				tmp[i][j] = new BerylliumSphere();
			}
		}
		
		return tmp;
	}

	/**
	 * Exercise 6: (1) Write a method that takes two int arguments, indicating the
	 * two sizes of a 2-D array. The method should create and fill a 2-D array of
	 * BerylliumSphere according to the size arguments.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(Arrays.deepToString(create(2, 3)));
	}
}
/*
[[Sphere 0, Sphere 1, Sphere 2], [Sphere 3, Sphere 4, Sphere 5]]
*/