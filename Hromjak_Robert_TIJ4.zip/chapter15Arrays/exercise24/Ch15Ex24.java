package exercise24;

import java.util.Arrays;

class Item implements Comparable<Item> {
	int i;

	public Item(int i) {
		super();
		this.i = i;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		if (i != other.i)
			return false;
		return true;
	}

	@Override
	public int compareTo(Item obj) {
		return (this.i < obj.i ? -1 : (this.i == obj.i ? 0 : 1));
	}

}

public class Ch15Ex24 {

	/**
	 * Exercise 24: (3) Show that the class from Exercise 19 can be searched.
	 * 
	 * @param args
	 * @return 2
	 * 
	 * 
	 */
	public static void main(String[] args) {
		Item[] items = new Item[3];
		Item[] items2 = new Item[3];

		for (int i = 0; i < 3; i++) {
			items[i] = new Item(i);
			items2[i] = new Item(i);
		}

		int index = Arrays.binarySearch(items, new Item(2));
		System.out.println(index);
	}
}
/*
	2
*/
