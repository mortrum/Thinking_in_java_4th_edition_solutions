package exercise17;

import java.math.BigDecimal;
import java.util.Arrays;

import net.mindview.util.Generated;
import net.mindview.util.Generator;

class BigDecimalGenerator implements Generator<BigDecimal> {
	BigDecimal bd = new BigDecimal(0);

	public BigDecimal next() {
		bd = bd.add(BigDecimal.ONE);
		return bd;
	}
}

public class Ch15Ex17 {

	/**
	 * Exercise 17: (5) Create and test a Generator for BigDecimal, and ensure that
	 * it works with the Generated methods.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		BigDecimal[] bda = Generated.array(BigDecimal.class, new BigDecimalGenerator(), 10);
		System.out.println(Arrays.toString(bda));
	}
}
/*
[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
*/