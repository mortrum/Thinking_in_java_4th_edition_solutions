package exercise13;

import net.mindview.util.CountingGenerator;

public class Ch15Ex13 {

	/**
	 * Exercise 13: (2) Fill a String using CountingGenerator.Character.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		CountingGenerator.Character genC = new CountingGenerator.Character();
		StringBuilder sb=new StringBuilder();
        for(int i=0;i<10;i++){
            sb.append(genC.next());
        }
        String s=sb.toString();
        System.out.println(s);
	}
}
/*
abcdefghij
*/