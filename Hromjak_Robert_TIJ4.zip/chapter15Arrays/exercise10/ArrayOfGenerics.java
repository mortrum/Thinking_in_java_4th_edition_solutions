package exercise10;

import java.util.ArrayList;
import java.util.List;

class ArrayOfGenericType<T> {
    List<T> array;
    public ArrayOfGenericType() {
        array = new ArrayList<T>();
    }
}
public class ArrayOfGenerics {

	/**
	 * Exercise 10: (2) Modify ArrayOfGenerics .Java to use containers instead of
	 * arrays. Show that you can eliminate the compile-time warnings.
	 * 
	 * @param args
	 */
	
	public static void main(String[] args) {
		ArrayOfGenericType<String> agt=new ArrayOfGenericType<String>();
	}
}
