package exercise15;

import net.mindview.util.Generated;
import net.mindview.util.Generator;

class Sphere {
	private static int count = 0;
	private int id = ++count;

	public String toString() {
		return "Sphere " + id;
	}
}

class ContainerComparison {
	public static class SphereGenerator implements Generator<Sphere> {
		public Sphere next() {
			return new Sphere();
		}
	}
}

public class Ch15Ex15 {

	/**
	 * Exercise 15: (2) Modify ContainerComparison.java by creating a Generator for
	 * BerylliumSphere, and change main( ) to use that Generator with
	 * Generated.array().
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		ContainerComparison.SphereGenerator sg = new ContainerComparison.SphereGenerator();
		Sphere[] ss = Generated.array(Sphere.class, sg, 10);
		for (Sphere s : ss) {
			System.out.println(s);
		}
	}
}
/*
Sphere 1
Sphere 2
Sphere 3
Sphere 4
Sphere 5
Sphere 6
Sphere 7
Sphere 8
Sphere 9
Sphere 10
*/