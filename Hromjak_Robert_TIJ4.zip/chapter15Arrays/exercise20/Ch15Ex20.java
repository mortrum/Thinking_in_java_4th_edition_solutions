package exercise20;

import java.util.Arrays;

class ItemTest {
	int i;

	public ItemTest(int i) {
		super();
		this.i = i;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ItemTest other = (ItemTest) obj;
		if (i != other.i)
			return false;
		return true;
	}

}

public class Ch15Ex20 {

	/**
	 * Exercise 20: (4) Demonstrate deepEquals( ) for multidimensional arrays
	 * 
	 * @param args
	 * @return true
	 * 
	 */
	public static void main(String[] args) {
		ItemTest[][] items = new ItemTest[2][2];
		ItemTest[][] items2 = new ItemTest[2][2];

		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < 2; j++) {
				items[i][j] = new ItemTest(i + j);
				items2[i][j] = new ItemTest(i + j);
			}
		}

		System.out.println(Arrays.deepEquals(items, items2));
	}
}
/*
true
*/