package exercise05;

import java.util.Arrays;

public class Ch15Ex05 {

	/**
	 * Exercise 5: (1) Demonstrate that multidimensional arrays of nonprimitive
	 * types are automatically initialized to null.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		String[][] s__ = new String[2][2];
		
		System.out.println(Arrays.deepToString(s__));
	}
}
/*
[[null, null], [null, null]]
*/