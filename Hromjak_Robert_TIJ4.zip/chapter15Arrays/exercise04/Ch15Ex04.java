package exercise04;

import java.util.Arrays;
import java.util.Random;

public class Ch15Ex04 {

	static Double[][][] create(int x, int y, int z, int min, int max) {
		Random rand = new Random();
		Double[][][] tmp = new Double[x][y][z];
		for (int i = 0; i < x; i++) {
			for (int j = 0; j < y; j++) {
				for (int k = 0; k < z; k++) {
					tmp[i][j][k] = min + (max - min) * rand.nextDouble();
				}
			}
		}

		return tmp;
	}

	static void print(Double[][][] d) {
		System.out.println(Arrays.deepToString(d));
	}

	/**
	 * Exercise 4: (2) Repeat the previous exercise for a three-dimensional array.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		print(create(2, 2, 2, 1, 10));
	}
}
/*
 * [[[9.46002949231818, 2.747623984190255], [1.728964498151111,
 * 6.833041499127508]], [[7.459281201078441, 8.02487150947363],
 * [3.6240092673725943, 5.156651496035337]]]
 */