package exercise05;

public class DataOnly {
	int i;
	double d;
	boolean b;

	@Override
	public String toString() {
		return "DataOnly [i=" + i + ", d=" + d + ", b=" + b + "]";
	}

	/**
	 * Exercise 5: (1) Modify the previous exercise so that the values of the data
	 * in DataOnly are assigned to and printed in main( ).
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		DataOnly data = new DataOnly();
		System.out.println(data);
	}
}
/*
DataOnly [i=0, d=0.0, b=false]
*/