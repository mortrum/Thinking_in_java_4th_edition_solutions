package exercise15;

import java.util.Date;


/** HelloDate class */
public class HelloDate {

	/**
	 * Exercise 15: (1) Take the program in Exercise 2 and add comment documentation
	 * to it. Extract this comment documentation into an HTML file using Javadoc and
	 * view it with your Web browser.
	 * 
	 * @param args
	 * @return Hello, it�s: Mon Aug 26 15:12:00 CEST 2019
	 * 
	 */
	/** main */
	public static void main(String[] args) {
		/** print hello*/
		System.out.println("Hello, it�s: ");
		/** print date */
		System.out.println(new Date());
	}
}
