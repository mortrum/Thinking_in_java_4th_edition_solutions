package exercise08;

class StaticTest {
	static int i = 47;
}

public class Test2 {
	/**
	 * Exercise 8: (3) Write a program that demonstrates that, no matter how many
	 * objects you create of a particular class, there is only one instance of a
	 * particular static field in that class
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		StaticTest st1 = new StaticTest();
		StaticTest st2 = new StaticTest();
		StaticTest.i++;
		System.out.println("st1: " + st1.i + " st2: " + st2.i);
	}
}
/*
st1: 48 st2: 48
*/