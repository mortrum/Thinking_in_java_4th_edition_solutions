package exercise03;

public class ATypeName {
	/**
	 * Exercise 3: (1) Find the code fragments involving ATypeName and turn them
	 * into a program that compiles and runs
	 * 
	 * @param args
	 * @return
	 */
	public static void main(String[] args) {
		ATypeName a = new ATypeName();
	}

}
