package exercise07;

class StaticTest {
	static int i = 47;
}

public class Incrementable {
	static void increment() {
		StaticTest.i++;
	}

	/**
	 * Exercise 7: (1) Turn the Incrementable code fragments into a working program.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(StaticTest.i);
		increment();
		System.out.println(StaticTest.i);
	}
}
/*
47
48
*/