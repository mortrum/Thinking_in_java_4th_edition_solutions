package exercise04;

public class DataOnly {
	int i;
	double d;
	boolean b;

	@Override
	public String toString() {
		return "DataOnly [i=" + i + ", d=" + d + ", b=" + b + "]";
	}

	/**
	 * Exercise 4: (1) Turn the DataOnly code fragments into a program that compiles
	 * and runs.
	 * 
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		DataOnly data = new DataOnly();
		System.out.println(data);
	}
}
/*
DataOnly [i=0, d=0.0, b=false]
*/