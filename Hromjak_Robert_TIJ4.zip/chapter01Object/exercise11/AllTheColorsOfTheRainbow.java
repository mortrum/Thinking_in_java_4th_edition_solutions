package exercise11;

public class AllTheColorsOfTheRainbow {
	int anIntegerRepresentingColors;

	void changeTheHueOfTheColor(int newHue) {
		anIntegerRepresentingColors = newHue;
	}

	@Override
	public String toString() {
		return "AllTheColorsOfTheRainbow [anIntegerRepresentingColors=" + anIntegerRepresentingColors + "]";
	}

	/**
	 * Exercise 11: (1) Turn the AllTheColorsOfTheRainbow example into a program
	 * that compiles and runs.
	 * 
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		AllTheColorsOfTheRainbow rainbow = new AllTheColorsOfTheRainbow();
		rainbow.changeTheHueOfTheColor(1);
		System.out.println(rainbow);
	}
}
/*
AllTheColorsOfTheRainbow [anIntegerRepresentingColors=1]
*/