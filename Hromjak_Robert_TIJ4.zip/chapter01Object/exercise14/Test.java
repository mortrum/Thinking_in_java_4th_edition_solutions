package exercise14;

/**
 * 
 * @author robert.hromjak Exercise 14: (1) Add an HTML list of items to the
 *documentation in the previous exercise.
 *<ul>
 *	<li>Coffee</li>
 *	<li>Tea</li>
 *	<li>Milk</li>
 *</ul>
 * 
 */
public class Test {

}
