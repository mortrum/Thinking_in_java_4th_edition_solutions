package exercise01;

public class Data {
	int n;
	char c;

	/**
	 * Exercise 1: (2) Create a class containing an int and a char that are not
	 * initialized, and print their values to verify that Java performs default
	 * initialization.
	 * 
	 * @param args
	 */
	 
	public static void main(String[] args) {
		Data data = new Data();
		System.out.println("int: " + data.n + ", char: " + data.c);
	}
}
/*
int: 0, char: 
*/