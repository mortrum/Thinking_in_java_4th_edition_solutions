package exercise13;

/**
 * 
 * @author robert.hromjak
 *
 */
/** A class comment */
public class Documentation1 {
	/** A field comment */
	public int i;

	/** A method comment */
	public void f() {
	}
}

/*
 * Run Documentation1.java, Documentation2.java and Documentation3.java through
 * Javadoc. Verify the resulting documentation with your Web browser.
 */