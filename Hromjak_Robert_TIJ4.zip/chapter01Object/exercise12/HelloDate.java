package exercise12;

import java.util.Date;

public class HelloDate {

	/**
	 * @author robert.hromjak
	 * @since 1.0
	 * 
	 *        Exercise 12: (2) Find the code for the second version of
	 *        HelloDate.java, which is the simple comment documentation example.
	 *        <p>
	 *        Execute Javadoc on the file and view the results with your Web
	 *        browser.
	 *
	 * @param args
	 * @returns Hello, it�s: Wed Aug 07 13:32:56 CEST 2019
	 */
	public static void main(String[] args) {
		System.out.println("Hello, it�s: ");
		System.out.println(new Date());
	}
}
/*
Hello, it�s: 
Wed Aug 28 16:10:59 CEST 2019
*/