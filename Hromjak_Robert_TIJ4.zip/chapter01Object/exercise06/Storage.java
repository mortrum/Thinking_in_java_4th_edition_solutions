package exercise06;

public class Storage {
	static int storage(String s) {
		return s.length() * 2;
	}

	/**
	 * Exercise 6: (2) Write a program that includes and calls the storage( ) method
	 * defined as a code fragment in this chapter
	 * 
	 * @param "alma"
	 */
	public static void main(String[] args) {
		System.out.println("storage is: " + storage("alma"));
	}
}
/*
storage is: 8
*/