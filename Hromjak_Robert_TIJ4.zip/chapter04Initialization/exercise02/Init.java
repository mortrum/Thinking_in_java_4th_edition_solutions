package exercise02;

class MyClass {
	String s1 = "xyz";
	String s2;
}

class MyClass2 {
	String s1;
	String s2;

	MyClass2() {
		s1 = "xyz";
	}
}

public class Init {

	/**
	 * Exercise 2: (2) Create a class with a String field that is initialized at the
	 * point of definition, and another one that is initialized by the constructor.
	 * What is the difference between the two approaches?
	 * 
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		MyClass obj1 = new MyClass();
        MyClass2 obj2 = new MyClass2();
        System.out.println(("obj1.s1 = " + obj1.s1));
        System.out.println(("obj1.s2 = " + obj1.s2));
        System.out.println(("obj2.s1 = " + obj2.s1));
        System.out.println(("obj2.s2 = " + obj2.s2));

	}
}
/*
Output:
obj1.s1 = xyz
obj1.s2 = null
obj2.s1 = xyz
obj2.s2 = null
*/