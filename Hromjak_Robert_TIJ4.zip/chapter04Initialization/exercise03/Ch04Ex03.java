package exercise03;

class Default {
	public Default() {
		System.out.println("default constructor");
	}
}

public class Ch04Ex03 {

	/**
	 * Exercise 3: (1) Create a class with a default constructor (one that takes no
	 * arguments) that prints a message. Create an object of this class.
	 * 
	 * @param args
	 * @return default constructor
	 * 
	 */
	public static void main(String[] args) {
		Default default1 = new Default();
		
	}

}
