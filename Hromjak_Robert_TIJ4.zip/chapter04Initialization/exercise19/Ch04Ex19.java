package exercise19;

public class Ch04Ex19 {

	static void f(String... args) {
		System.out.print("f()... ");
		for (String x : args) {
			System.out.print(x + " ");
		}
		System.out.println(" ");
	}

	/**
	 * Exercise 19: (2) Write a method that takes a vararg String array. Verify that
	 * you can pass either a comma-separated list of Strings or a String[] into this
	 * method.
	 * 
	 * @param args
	 * @return f()... Comma separated list 
	 * f()... These are array elements
	 * 
	 */
	public static void main(String[] args) {
		f("Comma", "separated", "list");
		f(new String[] { "These", "are", "array", "elements" });
	}

}
