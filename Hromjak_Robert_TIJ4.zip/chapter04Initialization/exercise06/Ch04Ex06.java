package exercise06;

class Dogi {
	void bark(String s, int i) {
		System.out.println("barking");
	}

	void bark(int i, String s) {
		System.out.println("howling");
	}

}

public class Ch04Ex06 {

	/**
	 * Exercise 6: (1) Modify the previous exercise so that two of the overloaded
	 * methods have two arguments (of two different types), but in reversed order
	 * relative to each other. Verify that this works.
	 * 
	 * @param args
	 * @return howling barking
	 * 
	 */
	public static void main(String[] args) {
		Dogi dog = new Dogi();
		dog.bark(1, "a");
		dog.bark("a", 1);
	}
}
