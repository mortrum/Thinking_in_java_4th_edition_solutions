package exercise18;

class Item {
	String s;

	public Item(String s) {
		super();
		this.s = s;
		System.out.println("from constructor " + s);
	}

}

public class Ch04Ex18 {

	/**
	 * Exercise 18: (1) Complete the previous exercise by creating objects to attach
	 * to the array of references.
	 * 
	 * @param args
	 * @return from constructor egy from constructor ket
	 * 
	 */
	public static void main(String[] args) {
		Item egy = new Item("egy");
		Item ket = new Item("ket");
		Item[] items = { egy, ket };
	}
}
