package exercise22;

public class Ch04Ex22 {
	public enum Paper {
		NOT, HOT, GOOD;
	}

	Paper p;

	/**
	 * Exercise 22: (2) Write a switch statement for the enum in the previous
	 * example. For each case, output a description of that particular currency.
	 * 
	 * @param args
	 * @return not! hot! good!
	 * 
	 */
	public static void main(String[] args) {
		for (Paper p : Paper.values()) {
			switch (p) {
			case NOT:
				System.out.println("not!");
				break;
			case HOT:
				System.out.println("hot!");
				break;
			case GOOD:
				System.out.println("good!");
				break;
			default:
				break;
			}
		}
	}
}
