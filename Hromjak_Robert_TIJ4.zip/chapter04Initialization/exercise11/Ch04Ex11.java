package exercise11;

class Tank {
	private boolean filled;

	public void fill() {
		filled = true;
	}

	public void shoot() {
		filled = false;
	}

	protected void finalize() {
		if (filled)
			System.err.println("tank is filled!");
	}
}

public class Ch04Ex11 {

	/**
	 * Exercise 11: (4) Modify the previous exercise so that your finalize( ) will
	 * always be called.
	 * 
	 * @param args
	 * @return tank is filled!
	 * 
	 */
	public static void main(String[] args) {
		Tank tank = new Tank();
		tank.fill();
		System.runFinalization();
		Runtime.getRuntime().runFinalization();
		System.gc();
		System.runFinalizersOnExit(true);

	}

}
