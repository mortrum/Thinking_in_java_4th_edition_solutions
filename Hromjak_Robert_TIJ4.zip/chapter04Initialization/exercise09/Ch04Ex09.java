package exercise09;

class ToOverload {
	int n;

	public ToOverload(int n) {
		this.n = n + 2;
	}

	public ToOverload(int n, int a) {
		this(n);
		this.n = this.n * a;
	}

	@Override
	public String toString() {
		return "ToOverload [n=" + n + "]";
	}

}

public class Ch04Ex09 {

	/**
	 * Exercise 9: (1) Create a class with two (overloaded) constructors. Using
	 * this, call the second constructor inside the first one.
	 * 
	 * @param args
	 * @return ToOverload [n=20] 
	 * 		   ToOverload [n=5]
	 * 
	 * 
	 */
	public static void main(String[] args) {
		ToOverload overload = new ToOverload(3, 4);
		ToOverload overload2 = new ToOverload(3);
		System.out.println(overload);
		System.out.println(overload2);
	}
}
