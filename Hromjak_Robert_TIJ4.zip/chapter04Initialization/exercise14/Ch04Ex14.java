package exercise14;

class StaticString {
	static String staticS = "ertek";
	static String instaticBlocks;

	static {
		instaticBlocks = "block";
		System.out.println("creating inStaticBlockS");
	}

	static void f() {
		System.out.println("static string: " + staticS + " in static block string: " + instaticBlocks);
	}
}

public class Ch04Ex14 {

	/**
	 * Exercise 14: (1) Create a class with a static String field that is
	 * initialized at the point of definition, and another one that is initialized
	 * by the static block. Add a static method that prints both fields and
	 * demonstrates that they are both initialized before they are used.
	 * 
	 * @param args
	 * @return creating inStaticBlockS static string: ertek in static block string:
	 *         block
	 * 
	 */
	public static void main(String[] args) {
		StaticString.f();
	}
}
