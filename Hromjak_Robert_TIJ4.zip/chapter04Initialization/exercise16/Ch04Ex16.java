package exercise16;

public class Ch04Ex16 {

	/**
	 * Exercise 16: (1) Create an array of String objects and assign a String to
	 * each element. Print the array by using a for loop.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		String[] array = new String[2];
		array[0] = "egy";
		array[1] = "ketto";
		
		for (int i = 0; i < array.length; i++) {
			System.out.println(array[i]);
		}
	}

}
/*
egy
ketto
*/