package exercise20;

public class Ch04Ex20 {

	/**
	 * Exercise 20: (1) Create a main( ) that uses varargs instead of the ordinary
	 * main( ) syntax. Print all the elements in the resulting args array. Test it
	 * with various numbers of command-line arguments.
	 * 
	 * @param args 1 2 3
	 * @return 1 2 3
	 */
	public static void main(String[] args) {
		for (String s : args) {
			System.out.println(s + " ");
		}
	}
}
