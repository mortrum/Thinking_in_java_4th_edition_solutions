package exercise15;

class MyClass {
	String s = "alma";

}

public class Ch04Ex15 {

	/**
	 * Exercise 15: (1) Create a class with a String that is initialized using
	 * instance initialization.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		MyClass class1 = new MyClass();
		System.out.println(class1.s);
	}

}
