package exercise17;

class Item {
	String s;

	public Item(String s) {
		super();

		this.s = s;
		System.out.println("from constructor " + s);
	}
}

public class Ch04Ex17 {

	/**
	 * Exercise 17: (2) Create a class with a constructor that takes a String
	 * argument. During construction, print the argument. Create an array of object
	 * references to this class, but don�t actually create objects to assign into
	 * the array. When you run the program, notice whether the initialization
	 * messages from the constructor calls are printed.
	 * 
	 * @param args
	 * @return from constructor egy from constructor ket
	 * 
	 */
	public static void main(String[] args) {
		Item[] items = { new Item("egy"), new Item("ket") };

	}

}
