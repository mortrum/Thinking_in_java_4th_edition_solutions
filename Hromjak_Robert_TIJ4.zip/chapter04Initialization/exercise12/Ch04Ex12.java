package exercise12;

class Tank {
	boolean full = false;

	Tank(boolean status) {
		full = status;
	}

	void fill() {
		full = true;
	}

	void empty() {
		full = false;
	}

	protected void finalize() {
		if (full)
			System.out.println("Tank level: full");
		else
			System.out.println("Tank level: empty");
	}

}

public class Ch04Ex12 {

	/**
	 * Exercise 12: (4) Create a class called Tank that can be filled and emptied,
	 * and has a termination condition that it must be empty when the object is
	 * cleaned up. Write a finalize( ) that verifies this termination condition. In
	 * main( ), test the possible scenarios that can occur when your Tank is used.
	 * 
	 * @param args
	 * @return Tank level: full
	 * 
	 */
	public static void main(String[] args) {
		Tank tank1 = new Tank(true);
		Tank tank2 = new Tank(true);
		tank1.empty();
		new Tank(true);
		System.gc();
	}

}
