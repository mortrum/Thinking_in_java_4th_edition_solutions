package exercise21;

enum Paper {
	NOT, MILD, MEDIUM, HOT, FLAMING, GOOD;
}

public class Ch04Ex21 {

	/**
	 * Exercise 21: (1) Create an enum of the least-valuable six types of paper
	 * currency. Loop through the values( ) and print each value and its ordinal( ).
	 * 
	 * @param args
	 * @return NOT MILD MEDIUM HOT FLAMING GOOD
	 * 
	 */
	public static void main(String[] args) {
		for (Paper s : Paper.values()) {
			System.out.println(s);
		}
	}
}
