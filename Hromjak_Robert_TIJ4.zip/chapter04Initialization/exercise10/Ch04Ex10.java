package exercise10;

class MyClass {

	void print() {
		System.out.println("print smth what in the future will be destroyed");
	}

	protected void finalize() {
		System.out.println("message: destroyed");
	}
}

public class Ch04Ex10 {

	/**
	 * Exercise 10: (2) Create a class with a finalize( ) method that prints a
	 * message. In main( ), create an object of your class. Explain the behavior of
	 * your program.
	 * 
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		MyClass class1 = new MyClass();
		class1.print();
		class1.finalize();

	}
}
/*
print smth what in the future will be destroyed
message: destroyed
*/