package exercise07;

class NoConstructor {
	void show() {
		System.out.println("showing");
	}
}

public class Ch04Ex07 {

	/**
	 * Exercise 7: (1) Create a class without a constructor, and then create an
	 * object of that class in main( ) to verify that the default constructor is
	 * automatically synthesized.
	 * 
	 * @param args
	 * @return showing
	 * 
	 */
	public static void main(String[] args) {
		NoConstructor constructor = new NoConstructor();
		constructor.show();

	}

}
