package exercise01;

public class Ch04Ex01 {
	String s;

	@Override
	public String toString() {
		return "Ch04Ex01 [s=" + s + "]";
	}

	/**
	 * Exercise 1: (1) Create a class containing an uninitialized String reference.
	 * Demonstrate that this reference is initialized by Java to null.
	 * 
	 * @param args
	 * @return Ch04Ex01 [s=null]
	 * 
	 */
	public static void main(String[] args) {
		Ch14Ex01 ch04Ex01 = new Ch14Ex01();
		System.out.println(ch04Ex01);
	}

}

