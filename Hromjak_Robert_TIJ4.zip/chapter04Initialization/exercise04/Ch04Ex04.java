package exercise04;

class Test {
	String s;

	public Test() {
		System.out.println("default constructor!");
	}

	@Override
	public String toString() {
		return "Test [s=" + s + "]";
	}

	public Test(String s) {
		System.out.println("ovverided constructor");
		this.s = s;
	}

}

public class Ch04Ex04 {

	/**
	 * Exercise 4: (1) Add an overloaded constructor to the previous exercise that
	 * takes a String argument and prints it along with your message.
	 * 
	 * @param args

	 * 
	 */
	public static void main(String[] args) {
		Test test = new Test();
		Test test2 = new Test("just a string");

		System.out.println(test);
		System.out.println(test2.toString());
	}
}
/*
default constructor!
ovverided constructor
Test [s=null]
Test [s=just a string]

*/