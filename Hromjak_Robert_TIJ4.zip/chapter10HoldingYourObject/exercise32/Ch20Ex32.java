package exercise32;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;

import typeinfo.pets.Pet;
import typeinfo.pets.Pets;

class PetSequence {
	protected Pet[] pets = Pets.createArray(8);
}

class NonCollectionSequence extends PetSequence implements Iterable<Pet> {
	public Iterator<Pet> iterator() {
		return new Iterator<Pet>() {
			private int index = 0;

			public boolean hasNext() {
				return index < pets.length;
			}

			public Pet next() {
				return pets[index++];
			}

			public void remove() { // Not implemented
				throw new UnsupportedOperationException();
			}
		};
	}
}

class MulriIterableClass extends NonCollectionSequence {

	public Iterable<Pet> reverse() {
		return new Iterable<Pet>() {
			public Iterator<Pet> iterator() {
				return new Iterator<Pet>() {
					private int index = pets.length - 1; // begin from the last element

					public boolean hasNext() {
						return index >= 0;
					}

					public Pet next() {
						return pets[index--];
					}
				};
			}
		};
	}

	public Iterable<Pet> shuffle() {
		return new Iterable<Pet>() {
			public Iterator<Pet> iterator() {
				ArrayList<Pet> copyList = new ArrayList<Pet>(Arrays.asList(pets));
				Collections.shuffle(copyList);
				return copyList.iterator();
			}
		};
	}
}

public class Ch20Ex32 {

	/**
	 * Exercise 32: (2) Following the example of MultilterableClass, add reversed( )
	 * and randomized( ) methods to NonCollectionSequence.java, as well as making
	 * NonCollectionSequence implement Iterable, and show that all the approaches
	 * work in foreach statements.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		MulriIterableClass m = new MulriIterableClass();
		for (Pet string : m) {
			System.out.println(string);
		}

		System.out.println("---------");
		for (Pet string : m.reverse()) {
			System.out.println(string);
		}

		System.out.println("---------");
		for (Pet string : m.shuffle()) {
			System.out.println(string);
		}
	}
}

/*
Rat
Manx
Cymric
Mutt
Pug
Cymric
Pug
Manx
---------
Manx
Pug
Cymric
Pug
Mutt
Cymric
Manx
Rat
---------
Mutt
Pug
Rat
Manx
Manx
Cymric
Cymric
Pug
*/
