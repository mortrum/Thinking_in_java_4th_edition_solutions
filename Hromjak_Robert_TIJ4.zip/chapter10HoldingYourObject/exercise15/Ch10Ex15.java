package exercise15;

import java.util.*;

import net.mindview.util.Stack;

public class Ch10Ex15 {

	/**
	 * Exercise 15: (4) Stacks are often used to evaluate expressions in programming
	 * languages. Using net.mindview.util.Stack, evaluate the following expression,
	 * where�+� means "push the following letter onto the stack," and�-� means "pop
	 * the top of the stack and print it": "+U+n+c�+e+r+t�+a-+i-+n+t+y�+
	 * -+r+u�+l+e+s�"
	 * 
	 * @param args
	 * @return c t r e n U
	 */
	public static void main(String[] args) {
		Stack<String> stack = new Stack<>();
		char[] c = "+U+n+c-+e+r+t-----".toCharArray();
		List<String> list = new ArrayList<String>();
		for (char x : c) {
			list.add(String.valueOf(x));
		}
		Iterator<String> it = list.iterator();
		while (it.hasNext()) {
			String tmp = it.next();
			if (tmp.equals("+")) {
				stack.push(it.next());
			}
			if (tmp.equals("-")) {
				System.out.print(stack.pop() + " ");
			}
		}
	}
}
