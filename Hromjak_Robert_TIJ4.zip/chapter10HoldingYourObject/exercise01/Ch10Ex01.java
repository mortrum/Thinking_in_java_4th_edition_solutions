package exercise01;

import java.util.ArrayList;

class Gerbil1 {
	int gerbilNumber;

	public Gerbil1(int gerbilNumber) {
		super();
		this.gerbilNumber = gerbilNumber;
	}

	void hop() {
		System.out.println(gerbilNumber);
	}

}

public class Ch10Ex01 {

	/**
	 * Exercise 1: (2) Create a new class called Gerbil with an int gerbilNumber
	 * that�s initialized in the constructor. Give it a method called hop( ) that
	 * displays which gerbil number this is, and that it�s hopping. Create an
	 * ArrayList and add Gerbil objects to the List. Now use the get( ) method to
	 * move through the List and call hop( ) for each Gerbil.
	 * 
	 * @param args
	 * @return 11 5
	 * 
	 */
	public static void main(String[] args) {
		ArrayList<Gerbil1> list = new ArrayList<>();
		list.add(new Gerbil1(11));
		list.add(new Gerbil1(5));

		for (int i = 0; i < list.size(); i++) {
			list.get(i).hop();
		}
	}
}
