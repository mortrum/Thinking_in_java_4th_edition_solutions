//: innerclasses/controller/Controller.java
// The reusable framework for control systems.
package innerclasses.controller;

import java.util.*;

public class Controller {
	// A class from java.util to hold Event objects:
	private List<Event> eventList = new LinkedList<Event>();

	public void addEvent(Event c) {
		eventList.add(c);
	}

	public void run() {
		while (eventList.size() > 0) {
			// Make a copy so you're not modifying the list
			// while you're selecting the elements in it:
			/*
			 * for (Event e : new LinkedList<Event>(eventList)) if (e.ready()) {
			 * System.out.println(e); e.action(); eventList.remove(e); }
			 */
			new LinkedList<Event>(eventList);
			Iterator<Event> it = new LinkedList<Event>(eventList).iterator();
			while (it.hasNext()) {
				Event tmp = it.next();
				if (tmp.ready()) {
					System.out.println(tmp);
					tmp.action();
					eventList.remove(tmp);
				}
			}
		}
	}
} /// :~
