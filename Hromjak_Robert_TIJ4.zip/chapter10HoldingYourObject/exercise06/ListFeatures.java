package exercise06;

import static net.mindview.util.Print.print;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class ListFeatures {
	

	static ArrayList<String> arrayList(int size) {
		ArrayList<String> result = new ArrayList<String>();
		for(int i = 0; i < size; i++) {
			result.add(createString());
		}
		return result;
	}
	static String createString() {
	    byte[] array = new byte[7]; // length is bounded by 7
	    new Random().nextBytes(array);
	    String generatedString = new String(array, Charset.forName("UTF-8"));
	    return generatedString;

	}

	/**
	 * Exercise 6: (2) Modify ListFeatures.java so that it uses Strings instead of
	 * Pets, and explain any difference in results.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Random rand = new Random(47);

		List<String> StringList = new ArrayList<>(arrayList(7));

		print("1: " + StringList);
		String h = "alma";
		StringList.add(h); // Automatically resizes
		print("2: " + StringList);
		print("3: " + StringList.contains(h));
		StringList.remove(h); // Remove by object
		String p = StringList.get(2);
		print("4: " + p + " " + StringList.indexOf(p));
		String cymric = "asd";
		print("5: " + StringList.indexOf(cymric));
		print("6: " + StringList.remove(cymric));
		// Must be the exact object:
		print("7: " + StringList.remove(p));
		print("8: " + StringList);
		StringList.add(3, "a"); // Insert at an index
		print("9: " + StringList);
		List<String> sub = StringList.subList(1, 4);
		print("subList: " + sub);
		print("10: " + StringList.containsAll(sub));
		Collections.sort(sub); // In-place sort
		print("sorted subList: " + sub);
		// Order is not important in containsAll():
		print("11: " + StringList.containsAll(sub));
		Collections.shuffle(sub, rand); // Mix it up
		print("shuffled subList: " + sub);
		print("12: " + StringList.containsAll(sub));
		List<String> copy = new ArrayList<String>(StringList);
		sub = Arrays.asList(StringList.get(1), StringList.get(4));
		print("sub: " + sub);
		copy.retainAll(sub);
		print("13: " + copy);
		copy = new ArrayList<String>(StringList); // Get a fresh copy
		copy.remove(2); // Remove by index
		print("14: " + copy);
		copy.removeAll(sub); // Only removes exact objects
		print("15: " + copy);
		copy.set(1, "aaa"); // Replace an element
		print("16: " + copy);
		copy.addAll(2, sub); // Insert a list in the middle
		print("17: " + copy);
		print("18: " + StringList.isEmpty());
		StringList.clear(); // Remove all elements
		print("19: " + StringList);
		print("20: " + StringList.isEmpty());
		print("21: " + StringList);
		Object[] o = StringList.toArray();

	}
}

/*
 * 1: [?#????, ?A?i, ??w?v, sg?G?, f??f#%Q, H5?'sj, ?p???]
2: [?#????, ?A?i, ??w?v, sg?G?, f??f#%Q, H5?'sj, ?p???, alma]
3: true
4: ??w?v 2
5: -1
6: false
7: true
8: [?#????, ?A?i, sg?G?, f??f#%Q, H5?'sj, ?p???]
9: [?#????, ?A?i, sg?G?, a, f??f#%Q, H5?'sj, ?p???]
subList: [?A?i, sg?G?, a]
10: true
sorted subList: [?A?i, a, sg?G?]
11: true
shuffled subList: [a, ?A?i, sg?G?]
12: true
sub: [a, f??f#%Q]
13: [a, f??f#%Q]
14: [?#????, a, sg?G?, f??f#%Q, H5?'sj, ?p???]
15: [?#????, sg?G?, H5?'sj, ?p???]
16: [?#????, aaa, H5?'sj, ?p???]
17: [?#????, aaa, a, f??f#%Q, H5?'sj, ?p???]
18: false
19: []
20: true
21: []

 * 
 */