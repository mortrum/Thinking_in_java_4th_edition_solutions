package exercise31;

public class Ch10Ex31 {

	/**
	 * Exercise 31: (3) Modify polymorphism/shape/RandomShapeGenerator.java to make
	 * it Iterable. You�ll need to add a constructor that takes the number of
	 * elements that you want the iterator to produce before stopping. Verify that
	 * it works.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		RandomShapeGenerator generator = new RandomShapeGenerator(7);
		for (Shape shape : generator) {
			shape.draw();
		}
	}
}
/*
Circle.draw()
Circle.draw()
Circle.draw()
Square.draw()
Circle.draw()
Square.draw()
Triangle.draw()
*/