//: polymorphism/shape/Shape.java
package exercise31;

public class Shape {
  public void draw() {}
  public void erase() {}
} ///:~
