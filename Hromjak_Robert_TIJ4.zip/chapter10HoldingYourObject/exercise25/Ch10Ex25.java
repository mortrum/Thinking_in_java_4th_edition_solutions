package exercise25;

import net.mindview.util.TextFile;
import java.util.*;

public class Ch10Ex25 {

	/**
	 * Exercise 25: (3) Create a Map<String,ArrayList<Integer>>. Use
	 * net.mindview.TextFile to open a text file and read it in a word at a time
	 * (use "\\W+" as the second argument to the TextFile constructor). Count the
	 * words as you read them in, and for each word in the file, record in the
	 * ArrayList<Integer> the word count associated with that word�this is, in
	 * effect, the location in the file where that word was found.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Map<String, ArrayList<Integer>> map = new HashMap<String, ArrayList<Integer>>();
		TextFile t = new TextFile("chapter10HoldingYourObject/exercise16/SetOperations.java", "\\W+");
		int n = 1;
		Map<Integer, String> counted = new HashMap<Integer, String>();
		for (String string : t) {
			counted.put(n++, string);
		}

		for (Map.Entry<Integer, String> entry : counted.entrySet()) {
			String key = entry.getValue();
			ArrayList<Integer> value = new ArrayList<Integer>();
			if (map.containsKey(key)) {
				value = map.get(key);
				value.add(entry.getKey());
				map.put(key, value);
			} else {
				value.add(entry.getKey());
				map.put(key, value);
			}
		}
		
		System.out.println(map); // print word and where it was used in file
	}
}
/*
 * Output: {added=[111, 156], SetOperations=[14], main=[18], String=[19, 22, 26,
 * 57, 61], Print=[11], removeAll=[92], java=[4], split=[42, 70, 106], from=[97,
 * 143], net=[8], Collections=[27, 62, 100], HashSet=[25, 60], add=[44],
 * new=[24, 59], package=[1], static=[7, 16], void=[17], set2=[58, 64, 72, 77,
 * 85, 90, 93, 95, 120, 137, 141], in=[73, 86, 121, 138], exercise16=[2],
 * contains=[49, 54], util=[5, 10], true=[117, 123], set1=[23, 29, 43, 48, 53,
 * 74, 75, 78, 82, 83, 87, 88, 91, 98, 99, 102, 113, 114, 122, 124, 139, 144,
 * 158], A=[30, 133, 150, 165], B=[31, 128, 147, 162], Set=[21, 56], C=[32, 127,
 * 146, 161], import=[3, 6], D=[33, 125, 145, 160], E=[34, 136, 152, 169],
 * F=[35, 134, 151, 166], G=[36, 130, 148, 163], H=[37, 47, 50, 65, 80, 116],
 * I=[38, 66, 131], J=[39, 67, 135], K=[40, 68, 126], mindview=[9], L=[41, 69,
 * 129], M=[45, 132, 149, 164], N=[52, 55, 118], remove=[79], public=[12, 15],
 * Output=[115], X=[103, 108, 153, 168], Y=[104, 109, 154, 167], Z=[105, 110,
 * 155, 159], class=[13], containsAll=[76, 89], false=[119, 140], args=[20],
 * print=[46, 51, 71, 81, 84, 94, 107], removed=[96, 142], addAll=[28, 63, 101],
 * to=[112, 157]}
 */