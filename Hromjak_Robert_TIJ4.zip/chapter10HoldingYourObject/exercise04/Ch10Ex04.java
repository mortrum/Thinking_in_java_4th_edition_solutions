package exercise04;


import java.util.*;

class Generator {
	static int i = 0;
	String[] s = { "alma", "korte", "szilva", "barack", "narancs" };

	String next() {
		String tmp = s[i];
		increment();
		return tmp;
	}

	void increment() {
		i++;
		if (i > s.length - 1)
			i = 0;
	}
}

public class Ch10Ex04 {

	static Collection fill(Collection<String> collection) {
		for (int i = 0; i < 11; i++) {
			collection.add(new Generator().next());
		}
		return collection;
	}

	static String[] fill(String[] array) {
		for (int i = 0; i < 11; i++) {
			array[i] = new Generator().next();
		}
		return array;
	}

	/**
	 * Exercise 4: (3) Create a generator class that produces character names (as
	 * String objects) from your favorite movie (you can use Snow White or Star Wars
	 * as a fallback) each time you call next( ), and loops around to the beginning
	 * of the character list when it runs out of names. Use this generator to fill
	 * an array, an ArrayList, a LinkedList, a HashSet, a LinkedHashSet, and a
	 * TreeSet, then print each container. page 283
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		String[] array = new String[15];
		System.out.println(Arrays.asList(fill(array)));
		System.out.println(fill(new ArrayList<String>()));
		System.out.println(fill(new LinkedList<String>()));
		System.out.println(fill(new HashSet<String>()));
		System.out.println(fill(new LinkedHashSet<String>()));
		System.out.println(fill(new TreeSet<String>()));
	}
}

/*
Output:
[alma, korte, szilva, barack, narancs, alma, korte, szilva, barack, narancs, alma, null, null, null, null]
[korte, szilva, barack, narancs, alma, korte, szilva, barack, narancs, alma, korte]
[szilva, barack, narancs, alma, korte, szilva, barack, narancs, alma, korte, szilva]
[szilva, barack, alma, korte, narancs]
[narancs, alma, korte, szilva, barack]
[alma, barack, korte, narancs, szilva]
*/