package exercise17;

import java.util.*;

class Gerbil1 {
	int gerbilNumber;

	public Gerbil1(int gerbilNumber) {
		super();
		this.gerbilNumber = gerbilNumber;
	}

	void hop() {
		System.out.println(gerbilNumber);
	}

}

public class Ch10Ex17 {

	/**
	 * Exercise 17: (2) Take the Gerbil class in Exercise 1 and put it into a Map
	 * instead, associating each Gerbil�s name (e.g. "Fuzzy" or "Spot") as a String
	 * (the key) for each Gerbil (the value) you put in the table. Get an Iterator
	 * for the keySet( ) and use it to move through the Map, looking up the Gerbil
	 * for each key and printing out the key and telling the Gerbil to hop( ).
	 * 
	 * @param args
	 * @return 1 2
	 * 
	 */
	public static void main(String[] args) {
		Map<String, Gerbil1> map = new HashMap<String, Gerbil1>();
		map.put("egy", new Gerbil1(1));
		map.put("ketto", new Gerbil1(2));

		Iterator<Map.Entry<String, Gerbil1>> it = map.entrySet().iterator();

		while (it.hasNext()) {
			Map.Entry<String, Gerbil1> entry = it.next();
			entry.getValue().hop();
		}

	}
}
