package exercise10;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

class Rodent {
	void what() {
		System.out.println("Rodent");
	}
}

class Mouse extends Rodent {
	void what() {
		System.out.println("Mouse");
	}
}

class Gerbil extends Rodent {
	void what() {
		System.out.println("Gerbil");
	}
}

class Hamster extends Rodent {
	void what() {
		System.out.println("Hamster");
	}
}

public class Ch10Ex10 {

	/**
	 * Exercise 10: (2) Change Exercise 9 in the Polymorphism chapter to use an
	 * ArrayList to hold the Rodents and an Iterator to move through the sequence of
	 * Rodents.
	 * 
	 * @param args
	 * @return Mouse Gerbil Hamster
	 * 
	 */
	public static void main(String[] args) {
		Rodent[] rodents = { new Mouse(), new Gerbil(), new Hamster() };
		List<Rodent> list = new ArrayList<>();
		list = Arrays.asList(rodents);
		Iterator<Rodent> it = list.iterator();
		while (it.hasNext()) {
			it.next().what();
		}
	}
}
