package exercise07;

import java.util.*;

class Number {
	private static int count = 0;
    private final int ID = ++count;
	@Override
	public String toString() {
		return "Number [ID=" + ID + "]";
	}
    
    
}

public class Ch10Ex07 {

	/**
	 * Exercise 7: (3) Create a class, then make an initialized array of objects of
	 * your class. Fill a List from your array. Create a subset of your List by
	 * using subList( ), then remove this subset from your List.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Number[] numbers = new Number[10];
		
		for (int i = 0; i < 7; i++) {
			numbers[i] = new Number();
		}
		
		List<Number> list = new ArrayList<>();
		
		for (Number number : numbers) {
			list.add(number);
		}

		System.out.println(list);
		
		List<Number> sub = list.subList(1, 4);

		System.out.println(sub);
		List<Number> copy = new ArrayList<Number>(list);
		copy.removeAll(sub);
		System.out.println(copy);
	}
}
/*
Output:
[Number [ID=1], Number [ID=2], Number [ID=3], Number [ID=4], Number [ID=5], Number [ID=6], Number [ID=7], null, null, null]
[Number [ID=2], Number [ID=3], Number [ID=4]]
[Number [ID=1], Number [ID=5], Number [ID=6], Number [ID=7], null, null, null]
*/