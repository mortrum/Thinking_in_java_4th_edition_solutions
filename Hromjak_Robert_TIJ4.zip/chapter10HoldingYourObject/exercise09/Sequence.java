package exercise09;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Sequence {
	private List items = new ArrayList();

	public void add(Object x) {
		items.add(x);
	}

	private class SequenceSelector implements Iterator {
		private int i = 0;

		@Override
		public boolean hasNext() {
			if (i < items.size())
				return true;
			return false;
		}

		@Override
		public Object next() {
			int tmp = i;
			if (i < items.size()) {
				return items.get(i++);

			} else
				return null;
		}
	}

	public Iterator selector() {
		return new SequenceSelector();
	}

	/**
	 * Exercise 9: (4) Modify innerclasses/Sequence.java so that Sequence works with
	 * an Iterator instead of a Selector.
	 * 
	 * @param args
	 * @return 10 11 12 13 14 15 16 17 18 19 
	 */
	public static void main(String[] args) {
		Sequence sequence = new Sequence();
		for (int i = 10; i < 20; i++)
			sequence.add(Integer.toString(i));

		Iterator it = sequence.selector();
		while (it.hasNext()) {
			System.out.print(it.next() + " ");
		}
	}
}
/*
10 11 12 13 14 15 16 17 18 19 
*/