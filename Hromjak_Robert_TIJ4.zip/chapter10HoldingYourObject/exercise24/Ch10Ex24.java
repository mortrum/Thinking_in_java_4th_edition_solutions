package exercise24;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class Ch10Ex24 {

	/**
	 * Exercise 24: (2) Fill a LinkedHashMap with String keys and objects of your
	 * choice. Now extract the pairs, sort them based on the keys, and reinsert them
	 * into the Map.
	 * 
	 * @param args
	 * @return {a=6, b=1, c=3}
	 * 
	 */
	public static void main(String[] args) {
		Map<String, Integer> map = new LinkedHashMap<>();
		map.put("b", 1);
		map.put("c", 3);
		map.put("a", 6);
		Map<String, Integer> sortedMap = new TreeMap<String, Integer>(map);
		System.out.println(sortedMap);

	}
}
