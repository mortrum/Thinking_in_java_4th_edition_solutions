package exercise22;

import java.util.*;

import net.mindview.util.TextFile;

class Data {
	String word;
	int count;

	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public Data(String word, int count) {
		super();
		this.word = word;
		this.count = count;
	}

	@Override
	public String toString() {
		return "word=" + word + ", count=" + count;
	}

}

public class Ch10Ex22 {

	/**
	 * Exercise 22: (5) Modify the previous exercise so that it uses a class
	 * containing a String and a count field to store each different word, and a Set
	 * of these objects to maintain the list of words.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Set<Data> dataSet = new HashSet<Data>();
		Set<String> setVowels = new HashSet<>();
		setVowels.add("a");
		setVowels.add("e");
		setVowels.add("i");
		setVowels.add("o");
		setVowels.add("u");
		setVowels.add("A");
		setVowels.add("E");
		setVowels.add("I");
		setVowels.add("O");
		setVowels.add("U");

		Set<String> words = new TreeSet<String>(
				new TextFile("chapter10HoldingYourObject/exercise16/SetOperations.java", "\\W+"));
		for (String word : words) {
			int n = 0;
			for (String string : setVowels) {
				if (word.contains(string)) {
					n++;

				}
			}
			dataSet.add(new Data(word, n));
		}

		System.out.println(dataSet);
	}
}
/*
 * Output: [word=print, count=1, word=exercise16, count=2, word=import, count=2,
 * word=K, count=0, word=contains, count=3, word=void, count=2, word=removed,
 * count=2, word=set2, count=1, word=J, count=0, word=L, count=0, word=A,
 * count=1, word=B, count=0, word=util, count=2, word=mindview, count=2,
 * word=Set, count=1, word=containsAll, count=4, word=new, count=1, word=H,
 * count=0, word=Print, count=1, word=I, count=1, word=class, count=1,
 * word=package, count=2, word=false, count=2, word=removeAll, count=3,
 * word=HashSet, count=2, word=net, count=1, word=added, count=2, word=F,
 * count=0, word=D, count=0, word=public, count=2, word=String, count=1,
 * word=split, count=1, word=Z, count=0, word=addAll, count=2, word=args,
 * count=1, word=set1, count=1, word=in, count=1, word=from, count=1,
 * word=SetOperations, count=5, word=java, count=1, word=E, count=1, word=M,
 * count=0, word=N, count=0, word=Collections, count=3, word=Output, count=2,
 * word=Y, count=0, word=X, count=0, word=C, count=0, word=main, count=2,
 * word=true, count=2, word=static, count=2, word=G, count=0, word=add, count=1,
 * word=to, count=1, word=remove, count=2]
 */