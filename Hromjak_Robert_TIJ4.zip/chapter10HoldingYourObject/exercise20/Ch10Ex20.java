package exercise20;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import net.mindview.util.TextFile;

public class Ch10Ex20 {

	/**
	 * Exercise 20: (3) Modify Exercise 16 so that you keep a count of the
	 * occurrence of each vowel.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Set<String> setVowels = new HashSet<>();
		setVowels.add("a");
		setVowels.add("e");
		setVowels.add("i");
		setVowels.add("o");
		setVowels.add("u");
		setVowels.add("A");
		setVowels.add("E");
		setVowels.add("I");
		setVowels.add("O");
		setVowels.add("U");
		int total = 0;
		Set<String> words = new TreeSet<String>(
				new TextFile("chapter10HoldingYourObject/exercise16/SetOperations.java", "\\W+"));
		for (String word : words) {
			int n = 0;
			for (String string : setVowels) {
				if (word.contains(string)) {
					n++;
					total++;
				}
			}
			System.out.println(word + " in this word count of the occurrence vowels is: " + n);
		}
		System.out.println("total: " + total);
	}
}
/*
Output:
A in this word count of the occurrence vowels is: 1
B in this word count of the occurrence vowels is: 0
C in this word count of the occurrence vowels is: 0
Collections in this word count of the occurrence vowels is: 3
D in this word count of the occurrence vowels is: 0
E in this word count of the occurrence vowels is: 1
F in this word count of the occurrence vowels is: 0
G in this word count of the occurrence vowels is: 0
H in this word count of the occurrence vowels is: 0
HashSet in this word count of the occurrence vowels is: 2
I in this word count of the occurrence vowels is: 1
J in this word count of the occurrence vowels is: 0
K in this word count of the occurrence vowels is: 0
L in this word count of the occurrence vowels is: 0
M in this word count of the occurrence vowels is: 0
N in this word count of the occurrence vowels is: 0
Output in this word count of the occurrence vowels is: 2
Print in this word count of the occurrence vowels is: 1
Set in this word count of the occurrence vowels is: 1
SetOperations in this word count of the occurrence vowels is: 5
String in this word count of the occurrence vowels is: 1
X in this word count of the occurrence vowels is: 0
Y in this word count of the occurrence vowels is: 0
Z in this word count of the occurrence vowels is: 0
add in this word count of the occurrence vowels is: 1
addAll in this word count of the occurrence vowels is: 2
added in this word count of the occurrence vowels is: 2
args in this word count of the occurrence vowels is: 1
class in this word count of the occurrence vowels is: 1
contains in this word count of the occurrence vowels is: 3
containsAll in this word count of the occurrence vowels is: 4
exercise16 in this word count of the occurrence vowels is: 2
false in this word count of the occurrence vowels is: 2
from in this word count of the occurrence vowels is: 1
import in this word count of the occurrence vowels is: 2
in in this word count of the occurrence vowels is: 1
java in this word count of the occurrence vowels is: 1
main in this word count of the occurrence vowels is: 2
mindview in this word count of the occurrence vowels is: 2
net in this word count of the occurrence vowels is: 1
new in this word count of the occurrence vowels is: 1
package in this word count of the occurrence vowels is: 2
print in this word count of the occurrence vowels is: 1
public in this word count of the occurrence vowels is: 2
remove in this word count of the occurrence vowels is: 2
removeAll in this word count of the occurrence vowels is: 3
removed in this word count of the occurrence vowels is: 2
set1 in this word count of the occurrence vowels is: 1
set2 in this word count of the occurrence vowels is: 1
split in this word count of the occurrence vowels is: 1
static in this word count of the occurrence vowels is: 2
to in this word count of the occurrence vowels is: 1
true in this word count of the occurrence vowels is: 2
util in this word count of the occurrence vowels is: 2
void in this word count of the occurrence vowels is: 2
total: 71
*/