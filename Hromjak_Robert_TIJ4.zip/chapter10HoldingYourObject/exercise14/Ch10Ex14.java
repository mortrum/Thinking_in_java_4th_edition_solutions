package exercise14;

import java.util.*;

public class Ch10Ex14 {

	static List<Integer> addInTheMiddle(List<Integer> list, Integer i) {
		int middle = list.size() / 2;
		int n = 0;
		Iterator<Integer> it = list.listIterator();
		if (!it.hasNext()) {
			list.add(i);

			return list;
		}
		while (it.hasNext()) {
			if (n == middle) {
				list.add(n, i);

				return list;
			}
			n++;
		}
		return list;
	}

	/**
	 * Exercise 14: (3) Create an empty LinkedList<Integer>. Using a Listlterator,
	 * add Integers to the List by always inserting them in the middle of the List.
	 * 
	 * @param args
	 * @return [1, 3, 5, 7, 9, 8, 6, 4, 2, 0]
	 * 
	 */
	public static void main(String[] args) {
		List<Integer> list = new LinkedList<>();

		for (int i = 0; i < 10; i++) {
			list = addInTheMiddle(list, i);
		}

		System.out.println(list);

	}
}
