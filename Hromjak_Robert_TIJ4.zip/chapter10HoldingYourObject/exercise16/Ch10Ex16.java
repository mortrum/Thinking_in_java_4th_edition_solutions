package exercise16;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import net.mindview.util.TextFile;

public class Ch10Ex16 {

	/**
	 * Exercise 16: (5) Create a Set of the vowels. Working from UniqueWords.Java,
	 * count and display the number of vowels in each input word, and also display
	 * the total number of vowels in the input file.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Set<String> setVowels = new HashSet<>();
		setVowels.add("a");
		setVowels.add("e");
		setVowels.add("i");
		setVowels.add("o");
		setVowels.add("u");
		setVowels.add("A");
		setVowels.add("E");
		setVowels.add("I");
		setVowels.add("O");
		setVowels.add("U");
		int total = 0;
		Set<String> words = new TreeSet<String>(new TextFile("chapter10HoldingYourObject/exercise16/SetOperations.java", "\\W+"));
		for (String word : words) {
			int n=0;
			char[] array = word.toCharArray();
			for (int i = 0; i < array.length; i++) {
				String tmp = Character.toString(array[i]);
				for (String x : setVowels) {
					if(tmp.equals(x)) {
						n++;
						total++;
					}
				}
			}
			System.out.println(word + " vowels in this word: " + n);
		}
		System.out.println("All vowels: " + total);
		
	}
}
/*
A vowels in this word: 1
B vowels in this word: 0
C vowels in this word: 0
Collections vowels in this word: 4
D vowels in this word: 0
E vowels in this word: 1
F vowels in this word: 0
G vowels in this word: 0
H vowels in this word: 0
HashSet vowels in this word: 2
I vowels in this word: 1
J vowels in this word: 0
K vowels in this word: 0
L vowels in this word: 0
M vowels in this word: 0
N vowels in this word: 0
Output vowels in this word: 3
Print vowels in this word: 1
Set vowels in this word: 1
SetOperations vowels in this word: 6
String vowels in this word: 1
X vowels in this word: 0
Y vowels in this word: 0
Z vowels in this word: 0
add vowels in this word: 1
addAll vowels in this word: 2
added vowels in this word: 2
args vowels in this word: 1
class vowels in this word: 1
contains vowels in this word: 3
containsAll vowels in this word: 4
exercise16 vowels in this word: 4
false vowels in this word: 2
from vowels in this word: 1
import vowels in this word: 2
in vowels in this word: 1
java vowels in this word: 2
main vowels in this word: 2
mindview vowels in this word: 3
net vowels in this word: 1
new vowels in this word: 1
package vowels in this word: 3
print vowels in this word: 1
public vowels in this word: 2
remove vowels in this word: 3
removeAll vowels in this word: 4
removed vowels in this word: 3
set1 vowels in this word: 1
set2 vowels in this word: 1
split vowels in this word: 1
static vowels in this word: 2
to vowels in this word: 1
true vowels in this word: 2
util vowels in this word: 2
void vowels in this word: 2
All vowels: 82
*/