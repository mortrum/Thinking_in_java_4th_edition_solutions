package exercise08;

import java.util.ArrayList;
import java.util.Iterator;

class Gerbil1 {
	int gerbilNumber;

	public Gerbil1(int gerbilNumber) {
		super();
		this.gerbilNumber = gerbilNumber;
	}

	void hop() {
		System.out.println(gerbilNumber);
	}

}

public class Ch10Ex08 {

	/**
	 * Exercise 8: (1) Modify Exercise l so it uses an Iterator to move through the
	 * List while calling hop( ).
	 * 
	 * @param args
	 * @return 11 5
	 */
	public static void main(String[] args) {
		ArrayList<Gerbil1> list = new ArrayList<>();
		list.add(new Gerbil1(11));
		list.add(new Gerbil1(5));

		Iterator<Gerbil1> it = list.iterator();
		while (it.hasNext()) {
			it.next().hop();
		}

	}
}
