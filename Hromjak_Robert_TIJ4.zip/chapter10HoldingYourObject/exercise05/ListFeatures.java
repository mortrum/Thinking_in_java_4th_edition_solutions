package exercise05;

import static net.mindview.util.Print.print;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class ListFeatures {
	static int[] createArray(int size) {
		Random random = new Random(47);
		int[] result = new int[size];
		for (int i = 0; i < size; i++)
			result[i] = random.nextInt(10);
		return result;
	}

	static ArrayList<Integer> arrayList(int size) {
		ArrayList<Integer> result = new ArrayList<Integer>();
		for (Integer integer : createArray(7)) {
			result.add(integer);
		}
		return result;
	}

	/**
	 * Exercise 5: (3) Modify ListFeatures.java so that it uses Integers (remember
	 * autoboxing!) instead of numbersList, and explain any difference in results.
	 * page 286
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Random rand = new Random(47);

		List<Integer> numbersList = new ArrayList<>(arrayList(7));

		print("1: " + numbersList);
		Integer h = 3;
		numbersList.add(h); // Automatically resizes
		print("2: " + numbersList);
		print("3: " + numbersList.contains(h));
		numbersList.remove(h); // Remove by object
		Integer p = numbersList.get(2);
		print("4: " + p + " " + numbersList.indexOf(p));
		Integer cymric = 3;
		print("5: " + numbersList.indexOf(cymric));
		print("6: " + numbersList.remove(cymric));
		// Must be the exact object:
		print("7: " + numbersList.remove(p));
		print("8: " + numbersList);
		numbersList.add(3, 23); // Insert at an index
		print("9: " + numbersList);
		List<Integer> sub = numbersList.subList(1, 4);
		print("subList: " + sub);
		print("10: " + numbersList.containsAll(sub));
		Collections.sort(sub); // In-place sort
		print("sorted subList: " + sub);
		// Order is not important in containsAll():
		print("11: " + numbersList.containsAll(sub));
		Collections.shuffle(sub, rand); // Mix it up
		print("shuffled subList: " + sub);
		print("12: " + numbersList.containsAll(sub));
		List<Integer> copy = new ArrayList<Integer>(numbersList);
		sub = Arrays.asList(numbersList.get(1), numbersList.get(4));
		print("sub: " + sub);
		copy.retainAll(sub);
		print("13: " + copy);
		copy = new ArrayList<Integer>(numbersList); // Get a fresh copy
		copy.remove(2); // Remove by index
		print("14: " + copy);
		copy.removeAll(sub); // Only removes exact objects
		print("15: " + copy);
		copy.set(1, 23); // Replace an element
		print("16: " + copy);
		copy.addAll(2, sub); // Insert a list in the middle
		print("17: " + copy);
		print("18: " + numbersList.isEmpty());
		numbersList.clear(); // Remove all elements
		print("19: " + numbersList);
		print("20: " + numbersList.isEmpty());
		print("21: " + numbersList);
		Object[] o = numbersList.toArray();

	}
}

/*
Output:
1: [8, 5, 3, 1, 1, 9, 8]
2: [8, 5, 3, 1, 1, 9, 8, 3]
3: true
4: 1 2
5: 6
6: true
7: true
8: [8, 5, 1, 9, 8]
9: [8, 5, 1, 23, 9, 8]
subList: [5, 1, 23]
10: true
sorted subList: [1, 5, 23]
11: true
shuffled subList: [5, 1, 23]
12: true
sub: [5, 9]
13: [5, 9]
14: [8, 5, 23, 9, 8]
15: [8, 23, 8]
16: [8, 23, 8]
17: [8, 23, 5, 9, 8]
18: false
19: []
20: true
21: []

*/