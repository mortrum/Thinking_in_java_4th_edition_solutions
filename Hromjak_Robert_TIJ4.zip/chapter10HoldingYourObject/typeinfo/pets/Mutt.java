//: typeinfo/pets/Mutt.java
package typeinfo.pets;


public class Mutt extends Dog {
  public Mutt(String name) { super(name); }
  public Mutt() { super(); }
} ///:~
