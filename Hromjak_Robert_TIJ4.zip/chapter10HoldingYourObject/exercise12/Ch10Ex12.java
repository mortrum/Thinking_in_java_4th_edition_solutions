package exercise12;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class Ch10Ex12 {

	/**
	 * Exercise 12: (3) Create and populate a List<Integer>. Create a second
	 * List<Integer> of the same size as the first, and use ListIterators to read
	 * elements from the first List and insert them into the second in reverse
	 * order. (You may want to explore a number of different ways to solve this
	 * problem.)
	 * 
	 * @param args
	 * @return 9 8 7 6 5 4 3 2 1 0
	 */
	public static void main(String[] args) {
		List<Integer> list = new ArrayList<Integer>();
		List<Integer> reversedList = new ArrayList<Integer>();
		for (int i = 0; i < 10; i++) {
			list.add(i);
		}
		ListIterator<Integer> it = list.listIterator();
		while (it.hasNext())
			it.next();
		while (it.hasPrevious()) {
			reversedList.add(it.previous());
		}

		for (Integer x : reversedList) {
			System.out.print(x + " ");
		}
	}
}
