package exercise11;

import java.util.*;

class A {
	int i;

	public A(int i) {
		super();
		this.i = i;
	}

	@Override
	public String toString() {
		return "A [i=" + i + "]";
	}
}

class B {
	int i;
	String s;

	public B(int i, String s) {
		super();
		this.i = i;
		this.s = s;
	}

	@Override
	public String toString() {
		return "B [i=" + i + ", s=" + s + "]";
	}
}

public class Ch10Ex11 {

	static void print(Collection<Object> collection) {
		Iterator<Object> it = collection.iterator();
		while (it.hasNext()) {
			System.out.println(it.next().toString());
		}
	}

	/**
	 * Exercise 11: (2) Write a method that uses an Iterator to step through a
	 * Collection and print the toString( ) of each object in the container. Fill
	 * all the different types of Collections with objects and apply your method to
	 * each container.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		List<Object> list = new ArrayList<Object>();
		list.add(new A(12));
		list.add(new B(6, "hat"));
		print(list);
	}
}
/*
A [i=12]
B [i=6, s=hat]
*/