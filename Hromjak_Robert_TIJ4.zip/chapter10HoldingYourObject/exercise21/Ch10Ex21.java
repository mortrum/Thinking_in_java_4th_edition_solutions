package exercise21;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.mindview.util.TextFile;

public class Ch10Ex21 {

	/**
	 * Exercise 21: (3) Using a Map<String,Integer>, follow the form of
	 * UniqueWords.java to create a program that counts the occurrence of words in a
	 * file. Sort the results using Collections.sort( ) with a second argument of
	 * String.CASE_INSENSITIVE_ORDER (to produce an alphabetic sort), and display
	 * the result.
	 * 
	 *
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Set<String> setVowels = new HashSet<>();
		Map<String, Integer> hashMap = new HashMap<String, Integer>();
		setVowels.add("a");
		setVowels.add("e");
		setVowels.add("i");
		setVowels.add("o");
		setVowels.add("u");
		setVowels.add("A");
		setVowels.add("E");
		setVowels.add("I");
		setVowels.add("O");
		setVowels.add("U");

		Set<String> words = new HashSet<String>(
				new TextFile("chapter10HoldingYourObject/exercise16/SetOperations.java", "\\W+"));
		for (String word : words) {
			int n = 0;
			for (String string : setVowels) {
				if (word.contains(string)) {
					n++;
				}
			}
			hashMap.put(word, n);
		}

		List<String> list = new ArrayList<String>();
		list.addAll(hashMap.keySet());
		Collections.sort(list, String.CASE_INSENSITIVE_ORDER);

		Map<String, Integer> linkedHashMap = new LinkedHashMap<String, Integer>();

		for (String word : list) {
			Integer feq = hashMap.get(word);
			if (feq == null) {
				continue;
			}
			linkedHashMap.put(word, feq);
		}

		System.out.println(linkedHashMap);

	}
}
/*
 * Output: {A=1, add=1, addAll=2, added=2, args=1, B=0, C=0, class=1,
 * Collections=3, contains=3, containsAll=4, D=0, E=1, exercise16=2, F=0,
 * false=2, from=1, G=0, H=0, HashSet=2, I=1, import=2, in=1, J=0, java=1, K=0,
 * L=0, M=0, main=2, mindview=2, N=0, net=1, new=1, Output=2, package=2,
 * Print=1, print=1, public=2, remove=2, removeAll=3, removed=2, Set=1, set1=1,
 * set2=1, SetOperations=5, split=1, static=2, String=1, to=1, true=2, util=2,
 * void=2, X=0, Y=0, Z=0}
 * 
 * 
 */