package exercise29;

import java.util.PriorityQueue;

public class Ch10Ex29 {
	private static class NoMemberClass extends Object {
	}

	/**
	 * Exercise 29: (2) Create a simple class that inherits from Object and contains
	 * no members, and show that you cannot successfully add multiple elements of
	 * that class to a PriorityQueue. This issue will be fully explained in the
	 * Containers in Depth chapter.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		/*PriorityQueue<NoMemberClass> pq = new PriorityQueue<NoMemberClass>();
		for (int i = 0; i < 10; i++) {
			pq.offer(new NoMemberClass());
		}*/ // java.lang.ClassCastException
	}
}
