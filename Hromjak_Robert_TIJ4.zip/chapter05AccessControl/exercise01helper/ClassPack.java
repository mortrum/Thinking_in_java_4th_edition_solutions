package exercise01helper;

public class ClassPack {

}
