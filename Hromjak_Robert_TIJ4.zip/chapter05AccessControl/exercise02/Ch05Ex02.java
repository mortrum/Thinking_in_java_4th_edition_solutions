package exercise02;

import net.mindview.simple.Vector;

public class Ch05Ex02 {

	/**
	 * Exercise 2: (1) Take the code fragments in this section and turn them into a
	 * program, and verify that collisions do in fact occur.
	 * 
	 * @param args
	 * @return net.mindview.simple.Vector
	 * 
	 */
	public static void main(String[] args) {
		net.mindview.simple.Vector v = new net.mindview.simple.Vector();
		java.util.Vector v2 = new java.util.Vector();

	}
}
