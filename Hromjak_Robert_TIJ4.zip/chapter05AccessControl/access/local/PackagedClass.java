package access.local;

public class PackagedClass {
	public PackagedClass() {
		System.out.println("Creating a packaged class");
	}
}
