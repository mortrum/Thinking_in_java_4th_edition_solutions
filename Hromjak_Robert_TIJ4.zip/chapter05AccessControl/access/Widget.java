package access;

public class Widget {

}
