package exercise04;

public class Ch05Ex04 {
	public void fooPublic() {
		System.out.println("public method");
	}

	protected void fooProtected() {
		System.out.println("protected method");
	}

	/**
	 * Exercise 4: (2) Show that protected methods have package access but are not
	 * public.
	 * 
	 * @param args
	 * @return protected method
	 * 
	 */
	public static void main(String[] args) {
		Ch05Ex04 availableProtectredMethods = new Ch05Ex04();
		availableProtectredMethods.fooProtected();
	}
}
