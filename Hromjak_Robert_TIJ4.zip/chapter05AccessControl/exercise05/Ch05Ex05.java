package exercise05;

class Access {
	public int publicI = 1;
	private int privateI = 2;
	protected int protectedI = 3;
	int packageAccessI = 4;

	public void publicM() {
		System.out.println("public method");
	}

	private void privateM() {
		System.out.println("private method");
	}

	protected void protectedM() {
		System.out.println("protected method");
	}

	void packadgeAccessM() {
		System.out.println("package-access method");
	}
}

public class Ch05Ex05 {

	/**
	 * Exercise 5: (2) Create a class with public, private, protected, and
	 * package-access fields and method members. Create an object of this class and
	 * see what kind of compiler messages you get when you try to access all the
	 * class members. Be aware that classes in the same directory are part of the
	 * �default� package.
	 * 
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		Access access = new Access();
		System.out.println("public int: " + access.publicI);
		// System.out.println("private int: " + access.privateI); //The field
		// Access.privateI is not visible
		System.out.println("protected int: " + access.protectedI);
		System.out.println("package-access int: " + access.packageAccessI);

		access.publicM();
		// access.privateM();//The method privateM() from the type Access is not visible
		access.protectedM();
		access.packadgeAccessM();
	}
}
/*
public int: 1
protected int: 3
package-access int: 4
public method
protected method
package-access method
*/
