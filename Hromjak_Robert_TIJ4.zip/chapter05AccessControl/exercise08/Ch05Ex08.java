package exercise08;

class Soup1 {
	private Soup1() {
	}

	// (1) Allow creation via static method:
	public static Soup1 makeSoup() {
		System.out.println("soup created");
		return new Soup1();
	}
}

class Soup2 {
	private Soup2() {
	}

	// (2) Create a static object and return a reference
	// upon request.(The "Singleton" pattern):
	private static Soup2 ps1 = new Soup2();

	public static Soup2 access() {
		return ps1;
	}

	public void f() {
		System.out.println("public void f()");
	}
}

class ConnectionManager {
	static Soup1[] list = new Soup1[5];
	int count = 0;
	boolean hasNext() {
		return (count < 5);
			
	}
	void newSoup() {
		if(hasNext()) {
			list[count] = Soup1.makeSoup();
			count++;
		}
		else {
			System.err.println("Connection manager error");
		}
	}
}

public class Ch05Ex08 {

	/**
	 * Exercise 8: (4) Following the form of the example Lunch.java, create a class
	 * called ConnectionManager that manages a fixed array of Connection objects.
	 * The client programmer must not be able to explicitly create Connection
	 * objects, but can only get them via a static method in ConnectionManager. When
	 * the ConnectionManager runs out of objects, it returns a null reference. Test
	 * the classes in main( ).
	 * 
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		ConnectionManager connectionManager = new ConnectionManager();
		connectionManager.newSoup();
		connectionManager.newSoup();
		connectionManager.newSoup();
		connectionManager.newSoup();
		connectionManager.newSoup();
		connectionManager.newSoup();
	}
}
/*
 * Output:
soup created
soup created
soup created
soup created
soup created
Connection manager error
*/
