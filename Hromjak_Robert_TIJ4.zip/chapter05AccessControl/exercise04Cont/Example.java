package exercise04Cont;

import exercise04.Ch05Ex04;;

public class Example {

	public static void main(String[] args) {
		Ch05Ex04 notAvailable = new Ch05Ex04();
		notAvailable.fooPublic();
		//notAvailable.fooProtected();  access only for public methods
	}
}
