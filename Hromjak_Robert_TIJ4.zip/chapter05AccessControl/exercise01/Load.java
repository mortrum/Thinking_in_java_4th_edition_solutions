package exercise01;

import exercise01helper.ClassPack;

public class Load {

	/**
	 * Exercise 1: (1) Create a class in a package. Create an instance of your class
	 * outside of that package.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		ClassPack classPack = new ClassPack();
	}

	
}
