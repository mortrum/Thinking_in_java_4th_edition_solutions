package exercise07;

import access.Widget;

public class Ch05Ex07 {

	/**
	 * Exercise 7: (1) Create the library according to the code fragments describing
	 * access and Widget. Create a Widget in a class that is not part of the access
	 * package 
	 * 
	 * @param args
	 * @return 
	 */
	public static void main(String[] args) {
		Widget widget = new Widget();
	}

}
