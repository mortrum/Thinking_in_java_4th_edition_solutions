package exercise09;

public class Ch05Ex09 {

	/**
	 * Exercise 9: (2) Create the following file in the access/local directory
	 * (presumably in your CLASSPATH):
	 * 
	 * + Explain why the compiler generates an error. Would making the Foreign class
	 * part of the access.local package change anything?
	 *  in Foreign class we have an error because class PackagedClass not been public!
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

	}
}
