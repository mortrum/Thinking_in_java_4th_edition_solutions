package exercise06;

class ProtectedData{
	static protected int data;
}

class Manipulator{
	public void changeData(){
		ProtectedData.data = 2;
	}
}

public class Ch05Ex06 {

	/**
	 * Exercise 6: (1) Create a class with protected data. Create a second class in
	 * the same file with a method that manipulates the protected data in the first
	 * class.
	 * 
	 * @param args
	 * @return 2
	 */
	public static void main(String[] args) {
		Manipulator manipulator = new Manipulator();
		manipulator.changeData();
		System.out.println(ProtectedData.data);
	}
}
