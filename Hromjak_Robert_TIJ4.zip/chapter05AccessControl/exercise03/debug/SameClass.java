package exercise03.debug;

import java.util.Arrays;

public class SameClass {
	public static void debug(String... args) {
		System.out.println(Arrays.toString(args));

	}
}
