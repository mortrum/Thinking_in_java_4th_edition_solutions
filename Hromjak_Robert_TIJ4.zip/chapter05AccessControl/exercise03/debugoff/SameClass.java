package exercise03.debugoff;

public class SameClass {
	public static void debug() {
		
	}
}
