package exercise03;

import static exercise03.debug.SameClass.debug;
import static exercise03.debugoff.SameClass.debug;


public class Test {

	/**
	 * Exercise 3: (2) Create two packages: debug and debugoff, containing an
	 * identical class with a debug( ) method. The first version displays its String
	 * argument to the console, the second does nothing. Use a static import line to
	 * import the class into a test program, and demonstrate the conditional
	 * compilation effect.
	 * 
	 * @param args
	 * @return [1, 2, 3]

	 */
	public static void main(String[] args) {
		debug(args);
	}
}
