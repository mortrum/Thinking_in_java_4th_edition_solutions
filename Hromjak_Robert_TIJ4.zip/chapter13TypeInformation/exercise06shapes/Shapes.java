package exercise06shapes;

import java.util.Arrays;
import java.util.List;

abstract class Shape {
	String flag;

	void draw() {
		System.out.println(this + ".draw()");
	}

	abstract public String toString();
}

class Circle extends Shape {
	public String toString() {
		return "Circle, Shape is highlighted to: " + flag;
	}
}

class Square extends Shape {
	public String toString() {
		return "Square, Shape is highlighted to: " + flag;
	}
}

class Triangle extends Shape {
	public String toString() {
		return "Triangle, Shape is highlighted to: " + flag;
	}
}

public class Shapes {
	/**
	 * Exercise 6: (4) Modify Shapes.java so that it can "highlight" (set a flag in)
	 * all shapes of a particular type. The toString( ) method for each derived
	 * Shape should indicate whether that Shape is "highlighted."
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		List<Shape> shapeList = Arrays.asList(new Circle(), new Square(), new Triangle());
		for (Shape shape : shapeList) {
			if(shape instanceof Triangle)
				shape.flag = "Triangle";
			if(shape instanceof Square)
				shape.flag = "Square";
			if(shape instanceof Circle)
				shape.flag = "Circle";
		}
		for (Shape shape : shapeList) {
			System.out.println(shape);
		}
	}
}
/*
Circle, Shape is highlighted to: Circle
Square, Shape is highlighted to: Square
Triangle, Shape is highlighted to: Triangle
*/