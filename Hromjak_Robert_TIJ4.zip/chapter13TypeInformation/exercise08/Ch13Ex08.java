package exercise08;

class A {

}

class B extends A {

}

class C extends B {

}

public class Ch13Ex08 {
	static void printHierarchy(Class<?> c) {
		if(c == Object.class) {
			System.out.println("Object is a last one");
			return;
		}
		System.out.println(c);
		printHierarchy(c.getSuperclass());
		
	}

	/**
	 * Exercise 8: (5) Write a method that takes an object and recursively prints
	 * all the classes in that object�s hierarchy.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Class c = null;
		try {
			c = Class.forName("exercise08.C");
		} catch (ClassNotFoundException e) {
			System.out.println("Can�t find C");
			System.exit(1);
		}
		printHierarchy(c);
	}

}
/*
class exercise08.C
class exercise08.B
class exercise08.A
Object is a last one
*/