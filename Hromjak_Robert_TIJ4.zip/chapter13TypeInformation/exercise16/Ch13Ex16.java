package exercise16;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import generics.coffee.Americano;
import generics.coffee.Breve;
import generics.coffee.Cappuccino;
import generics.coffee.Coffee;
import generics.coffee.Latte;
import generics.coffee.Mocha;

class CoffeeFactory {
	public static Coffee creat() {
		int r = rand.nextInt(5);
		try {
			return facList.get(r).newInstance();
		} catch (InstantiationException ie) {
			System.out.println(facList.get(r) + " cannot be initialized!");
			return null;
		} catch (IllegalAccessException iae) {
			System.out.println("Check the access level of " + facList.get(r) + " class!");
			return null;
		}
	}

	private static Random rand = new Random();
	private static List<Class<? extends Coffee>> facList = new ArrayList<Class<? extends Coffee>>();
	static {
		facList.add(Latte.class);
		facList.add(Mocha.class);
		facList.add(Cappuccino.class);
		facList.add(Americano.class);
		facList.add(Breve.class);
	}
}

public class Ch13Ex16 {

	/**
	 * Exercise 16: (4) Modify the Coffee hierarchy in the Generics chapter to use
	 * Registered Factories.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		for (int i = 0; i < 10; i++) {
			System.out.println(CoffeeFactory.creat());
		}
	}
}
