package exercise03shapes;

import java.util.*;

abstract class Shape {
	void draw() {
		System.out.println(this + ".draw()");
	}

	abstract public String toString();
}

class Circle extends Shape {
	public String toString() {
		return "Circle";
	}
}

class Square extends Shape {
	public String toString() {
		return "Square";
	}
}

class Triangle extends Shape {
	public String toString() {
		return "Triangle";
	}
}

class Rhomboid extends Shape {
	public String toString() {
		return "Rhomboid";
	}

}

public class Shapes {
	/*
	 * /** Exercise 3: (2) Add Rhomboid to Shapes.java. Create a Rhomboid, upcast it
	 * to a Shape, then downcast it back to a Rhomboid. Try downcasting to a Circle
	 * and see what happens. page 398
	 * 
	 * @param args
	 * 
	 * @return Rhomboid
	 * 
	 */

	public static void main(String[] args) {
		List<Shape> shapeList = Arrays.asList(new Circle(), new Square(), new Triangle(), new Rhomboid());

		Rhomboid rhomboid = (Rhomboid) shapeList.get(3);

		System.out.println(rhomboid);

		// ! Circle circle = (Rhomboid) shapeList.get(3);//Type mismatch: cannot convert
		// from Rhomboid to Circle

	}
} /*
	 * Output: Circle.draw() Square.draw() Triangle.draw()
	 */// :~
