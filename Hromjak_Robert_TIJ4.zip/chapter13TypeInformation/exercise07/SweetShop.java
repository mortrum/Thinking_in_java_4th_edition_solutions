package exercise07;

// Examination of the way the class loader works.
import static net.mindview.util.Print.*;

class Candy {
	static {
		print("Loading Candy");
	}
}

class Gum {
	static {
		print("Loading Gum");
	}
}

class Cookie {
	static {
		print("Loading Cookie");
	}
}

public class SweetShop {

	/**
	 * Exercise 7: (3) Modify SweetShop.java so that each type of object creation is
	 * controlled by a command-line argument. That is, if your command line is "Java
	 * Sweetshop Candy," then only the Candy object is created. Notice how you can
	 * control which Class objects are loaded via the commandline argument.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		print("inside main");
		if (args[2].equals("Candy")) {
			new Candy();
			print("After creating Candy");
		}

		if (args[2].equals("Gum")) {
			try {
				Class.forName("exercise07.Gum");
			} catch (ClassNotFoundException e) {
				print("Couldn't find Gum");
			}
			print("After Class.forName(\"Gum\")");
		}

		if (args[2].equals("Cookie")) {
			new Cookie();
			print("After creating Cookie");
		}

	}
} 
/*
inside main
Loading Candy
After creating Candy
*/