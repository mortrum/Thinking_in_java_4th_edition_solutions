package exercise13;

import java.util.ArrayList;
import java.util.List;

import exercise12.TypeCounter;

public class Ch13Ex13 {

	/**
	 * Exercise 13: (3) Use TypeCounter with the RegisteredFactories.java example in
	 * this chapter.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		List<Part> list = new ArrayList<Part>();
		for (int i = 0; i < 10; i++) {
			list.add(Part.createRandom());
		}
		TypeCounter tc = new TypeCounter(Part.class);
		for (Part part : list) {
			tc.count(part);
		}
		System.out.println(tc);
	}
}
/*
{Belt=5, Filter=5, AirFilter=1, CabinAirFilter=2, FuelFilter=2, GeneratorBelt=2, Part=10, PowerSteeringBelt=3}
*/