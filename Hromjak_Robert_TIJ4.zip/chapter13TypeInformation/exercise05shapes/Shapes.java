package exercise05shapes;

import java.util.*;

abstract class Shape {
	void draw() {
		System.out.println(this + ".draw()");
	}

	abstract public String toString();
}

class Circle extends Shape {
	public String toString() {
		return "Circle";
	}
}

class Square extends Shape {
	public String toString() {
		return "Square";
	}
}

class Triangle extends Shape {
	public String toString() {
		return "Triangle";
	}
}

class Rhomboid extends Shape {
	public String toString() {
		return "Rhomboid";
	}

}

public class Shapes {
	static void rotate(Shape shape) {
		if (shape instanceof Circle) {
			System.out.println("cant rotate circle");
		} else {
			System.out.println("rotating " + shape);
		}
	}

	/*
	 * Exercise 5: (3) Implement a rotate(Shape) method in Shapes.java, such that it
	 * checks to see if it is rotating a Circle (and, if so, doesn�t perform the
	 * operation).
	 * 
	 * @param args
	 * 
	 * @return rotating Rhomboid cant rotate circle
	 * 
	 * 
	 * 
	 */
	public static void main(String[] args) {
		
		Shape rhomboid = new Rhomboid();
		Shape circle = new Circle();

		rotate(rhomboid);
		rotate(circle);

		// ! Circle circle = (Rhomboid) shapeList.get(3);//Type mismatch: cannot convert
		// from Rhomboid to Circle

	}
}
/*
rotating Rhomboid
cant rotate circle
*/