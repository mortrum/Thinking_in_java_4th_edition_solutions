package exercise09;

import java.lang.reflect.Field;

class A {
	static String s = "string in class A";

}

class B extends A {
	String s = "string in class B";

}

class C extends B {
	String s = "string in class C";

}

public class Ch13Ex09 {
	static void printHierarchy(Class<?> c) {
		if (c == Object.class) {
			System.out.println("Object is a last one");
			return;
		}

		System.out.println(c);

		Field[] fields = c.getDeclaredFields();

		for (Field field : fields) {

			System.out.println(field);
		}

		printHierarchy(c.getSuperclass());

	}

	/**
	 * Exercise 9: (5) Modify the previous exercise so that it uses
	 * Class.getDeclaredFields( ) to also display information about the fields in a
	 * class.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		C x = new C();

		printHierarchy(x.getClass());

	}

}

/*
class exercise09.C
java.lang.String exercise09.C.s
class exercise09.B
java.lang.String exercise09.B.s
class exercise09.A
static java.lang.String exercise09.A.s
Object is a last one
*/