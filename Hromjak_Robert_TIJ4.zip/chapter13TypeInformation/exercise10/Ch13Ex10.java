package exercise10;

public class Ch13Ex10 {

	/**
	 * Exercise 10: (3) Write a program to determine whether an array of char is a
	 * primitive type or a true Object.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		char[] c = new char[10];
		System.out.println(c instanceof char[]);
        System.out.println(c instanceof Object);
        System.out.println(c.getClass().getName());
        System.out.println(c.getClass().getSuperclass().getName());
        
	}
}
/*
true
true
[C
java.lang.Object
*/