package exercise02;

import static net.mindview.util.Print.print;

interface HasBatteries {
}

interface Waterproof {
}

interface Shoots {
}

interface A {

}

class Toy {
	// Comment out the following default constructor
	// to see NoSuchMethodError from (*1*)
	Toy() { // Cannot instantiate
	}

	Toy(int i) {
	}
}

class FancyToy extends Toy implements HasBatteries, Waterproof, Shoots, A {
	FancyToy() {
		super(1);
	}
}

public class ToyTest {
	static void printInfo(Class cc) {
		print("Class name: " + cc.getName() + " is interface? [" + cc.isInterface() + "]");
		print("Simple name: " + cc.getSimpleName());
		print("Canonical name : " + cc.getCanonicalName());
	}

	/**
	 * Exercise 2: (2) Incorporate a new kind of interface into ToyTest.java and
	 * verify that it is detected and displayed properly.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Class c = null;
		try {
			c = Class.forName("exercise02.FancyToy");
		} catch (ClassNotFoundException e) {
			print("Can�t find FancyToy");
			System.exit(1);
		}
		printInfo(c);
		for (Class face : c.getInterfaces())
			printInfo(face);
		Class up = c.getSuperclass();
		Object obj = null;
		try {
			// Requires default constructor:
			obj = up.newInstance();
		} catch (InstantiationException e) {
			print("Cannot instantiate");
			System.exit(1);
		} catch (IllegalAccessException e) {
			print("Cannot access");
			System.exit(1);
		}
		printInfo(obj.getClass());
	}
}

/*
Output:
Class name: exercise02.FancyToy is interface? [false]
Simple name: FancyToy
Canonical name : exercise02.FancyToy
Class name: exercise02.HasBatteries is interface? [true]
Simple name: HasBatteries
Canonical name : exercise02.HasBatteries
Class name: exercise02.Waterproof is interface? [true]
Simple name: Waterproof
Canonical name : exercise02.Waterproof
Class name: exercise02.Shoots is interface? [true]
Simple name: Shoots
Canonical name : exercise02.Shoots
Class name: exercise02.A is interface? [true]
Simple name: A
Canonical name : exercise02.A
Class name: exercise02.Toy is interface? [false]
Simple name: Toy
Canonical name : exercise02.Toy
*/