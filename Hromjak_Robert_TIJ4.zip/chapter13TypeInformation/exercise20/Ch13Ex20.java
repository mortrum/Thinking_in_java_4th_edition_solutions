package exercise20;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class Ch13Ex20 {

	/**
	 * Exercise 20: (5) Look up the interface for java.lang.Class in the JDK
	 * documentation from http://java.sun.com. Write a program that takes the name
	 * of a class as a command-line argument, then uses the Class methods to dump
	 * all the information available for that class. Test your program with a
	 * standard library class and a class you create.
	 * 
	 * @param args
	 * @args generics.coffee.CoffeeGenerator
	 */
	public static void main(String[] args) {
		try {
			Class<?> c = Class.forName(args[0]);

			// constructor
			Constructor<?>[] cons = c.getConstructors();
			if (cons.length > 0) {
				for (Constructor<?> con : cons) {
					System.out.println(con);
				}
			}
			// methods
			Method[] ms = c.getMethods();
			if (ms.length > 0) {
				for (Method m : ms) {
					System.out.println(m);
				}
			}
			// fields
			Field[] fs = c.getFields();
			if (fs.length > 0) {
				for (Field f : fs) {
					System.out.println(f);
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}

/*
public generics.coffee.CoffeeGenerator(int)
public generics.coffee.CoffeeGenerator()
public static void generics.coffee.CoffeeGenerator.main(java.lang.String[])
public java.util.Iterator generics.coffee.CoffeeGenerator.iterator()
public generics.coffee.Coffee generics.coffee.CoffeeGenerator.next()
public java.lang.Object generics.coffee.CoffeeGenerator.next()
public final void java.lang.Object.wait() throws java.lang.InterruptedException
public final void java.lang.Object.wait(long,int) throws java.lang.InterruptedException
public final native void java.lang.Object.wait(long) throws java.lang.InterruptedException
public boolean java.lang.Object.equals(java.lang.Object)
public java.lang.String java.lang.Object.toString()
public native int java.lang.Object.hashCode()
public final native java.lang.Class java.lang.Object.getClass()
public final native void java.lang.Object.notify()
public final native void java.lang.Object.notifyAll()
public default java.util.Spliterator java.lang.Iterable.spliterator()
public default void java.lang.Iterable.forEach(java.util.function.Consumer)
*/