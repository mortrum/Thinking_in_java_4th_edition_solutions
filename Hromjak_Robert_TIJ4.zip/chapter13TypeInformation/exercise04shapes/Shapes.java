package exercise04shapes;

import java.util.*;

abstract class Shape {
	void draw() {
		System.out.println(this + ".draw()");
	}

	abstract public String toString();
}

class Circle extends Shape {
	public String toString() {
		return "Circle";
	}
}

class Square extends Shape {
	public String toString() {
		return "Square";
	}
}

class Triangle extends Shape {
	public String toString() {
		return "Triangle";
	}
}

class Rhomboid extends Shape {
	public String toString() {
		return "Rhomboid";
	}

}

public class Shapes {
	/*
	 * Exercise 4: (2) Modify the previous exercise so that it uses instanceof to
	 * check the type before performing the downcast.
	 * 
	 * @param args
	 * 
	 * @return Rhomboid
	 * 
	 * 
	 */

	public static void main(String[] args) {
		List<Shape> shapeList = Arrays.asList(new Circle(), new Square(), new Triangle(), new Rhomboid());

		Shape rhomboid = new Rhomboid();
		if (rhomboid instanceof Rhomboid) {
			System.out.println(rhomboid);
		}

		if (rhomboid instanceof Circle) {
			System.out.println(rhomboid);
		}

		// ! Circle circle = (Rhomboid) shapeList.get(3);//Type mismatch: cannot convert
		// from Rhomboid to Circle

	}
} /*
	 * Output: Circle.draw() Square.draw() Triangle.draw()
	 */// :~
