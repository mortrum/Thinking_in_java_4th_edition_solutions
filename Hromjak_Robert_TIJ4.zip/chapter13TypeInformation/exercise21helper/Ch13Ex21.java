package exercise21helper;

import static net.mindview.util.Print.print;

interface Interface {
	void doSomething();

	void somethingElse(String arg);
}

class RealObject implements Interface {
	public void doSomething() {
		print("doSomething");
	}

	public void somethingElse(String arg) {
		print("somethingElse " + arg);
	}
}

class SimpleProxy implements Interface {
	private Interface proxied;
	private static int count1 = 0;
	private static int count2 = 0;

	public SimpleProxy(Interface proxied) {
		this.proxied = proxied;
	}

	public void doSomething() {
		print("SimpleProxy doSomething");
		proxied.doSomething();
		count1++;
	}

	public void somethingElse(String arg) {
		print("SimpleProxy somethingElse " + arg);
		proxied.somethingElse(arg);
		count2++;
	}

	public static void showCount() {
		System.out.println("doSomething: " + count1 + " somethingElse: " + count2);
	}
}

public class Ch13Ex21 {
	public static void consumer(Interface iface) {
		iface.doSomething();
		iface.somethingElse("bonobo");
	}

	/**
	 * Exercise 21: (3) Modify SimpleProxyDemo.java so that it measures method-call
	 * times.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		consumer(new RealObject());
		consumer(new SimpleProxy(new RealObject()));
		SimpleProxy.showCount();
	}
}

/*
 * doSomething somethingElse bonobo SimpleProxy doSomething doSomething
 * SimpleProxy somethingElse bonobo somethingElse bonobo doSomething: 1
 * somethingElse: 1
 */
