package exercise15;

import java.util.ArrayList;
import java.util.List;

class Pets {
	public Pets() {
		count++;
		id = count;
	}

	public String toString() {
		return "Pet No." + id;
	}

	private long id = 0l;
	private static long count = 0l;

}

class PetsCreator {
	private static List<Class<? extends Pets>> facList = new ArrayList<Class<? extends Pets>>();
	static {
		facList.add(Pets.class);
		System.out.println(facList);
	}

	public static Pets creat() {
		try {
			return facList.get(0).newInstance();
		} catch (InstantiationException ie) {
			System.out.println(facList.get(0) + " cannot be initialized!");
			return null;
		} catch (IllegalAccessException iae) {
			System.out.println("Check the access level of " + facList.get(0) + " class!");
			return null;
		}
	}
}

public class Ch13Ex15 {
	/**
	 * Exercise 15: (4) Implement a new PetCreator using Registered Factories, and
	 * modify the Pets Facade so that it uses this one instead of the other two.
	 * Ensure that the rest of the examples that use Pets .Java still work
	 * correctly.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		for (int i = 0; i < 10; i++) {
			System.out.println(PetsCreator.creat());
		}
	}
}

/*
 * Pet No.1 Pet No.2 Pet No.3 Pet No.4 Pet No.5 Pet No.6 Pet No.7 Pet No.8 Pet
 * No.9 Pet No.10
 */