package exercise25;

class Data {
	private void fPrivate() { //dont be work

	}

	protected void fProtected() {  //dont be work

	}

	void fPackageAccess() { //dont be work, only public will work in outher package (or if we exdent from this class then derived class can use protected methods)

	}
}

public class Ch13Ex25 {

	/**
	 * Exercise 25: (2) Create a class containing private, protected and
	 * package-access methods. Write code to access these methods from outside of
	 * the class�s package.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

	}
}
