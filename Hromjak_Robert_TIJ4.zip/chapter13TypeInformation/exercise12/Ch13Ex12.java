package exercise12;

import generics.coffee.Coffee;
import generics.coffee.CoffeeGenerator;

public class Ch13Ex12 {

	/**
	 * Exercise 12: (3) Use TypeCounter with the CoffeeGenerator.java class in the
	 * Generics chapter.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		CoffeeGenerator cg=new CoffeeGenerator(10);
        TypeCounter tc=new TypeCounter(Coffee.class);
        for(Coffee coffee:cg){
            tc.count(coffee);
        }
        System.out.println(tc);
	}
}

/*
{Coffee=10, Breve=1, Cappuccino=2, Mocha=2, Americano=3, Latte=2}
*/