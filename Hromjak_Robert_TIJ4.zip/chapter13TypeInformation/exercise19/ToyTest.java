package exercise19;

import java.lang.reflect.Constructor;

class Toy {
	public Toy() {
		System.out.println("not used");
	}

	public Toy(int i) {
		System.out.println("Toy(int i) " + i);
	}

	@Override
	public String toString() {
		return "Toy []";
	}

}

public class ToyTest {

	/**
	 * Exercise 19: (4) In ToyTest.java, use reflection to create a Toy object using
	 * the nondefault constructor.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		Constructor<?>[] cs = Toy.class.getConstructors();

		for (Constructor<?> c : cs) {

			if (c.getParameterTypes().length == 1) {
				Class<?>[] paraType = c.getParameterTypes();
				if (paraType[0] == int.class) {
					try {
						System.out.println(c.newInstance(1));
					} catch (Exception e) {
						System.out.println(e);
					}
				}
			}
		}
	}
}

/*
Toy(int i) 1
Toy []
*/