//: typeinfo/pets/Pet.java
package exercise11;

public class Pet extends Individual {
  public Pet(String name) { super(name); }
  public Pet() { super(); }
} ///:~
