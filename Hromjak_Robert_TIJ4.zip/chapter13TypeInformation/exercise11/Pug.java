//: typeinfo/pets/Pug.java
package exercise11;

public class Pug extends Dog {
  public Pug(String name) { super(name); }
  public Pug() { super(); }
} ///:~
