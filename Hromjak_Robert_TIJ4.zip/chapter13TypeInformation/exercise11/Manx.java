//: typeinfo/pets/Manx.java
package exercise11;

public class Manx extends Cat {
  public Manx(String name) { super(name); }
  public Manx() { super(); }
} ///:~
