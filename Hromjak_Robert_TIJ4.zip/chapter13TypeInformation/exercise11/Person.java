//: typeinfo/pets/Person.java
package exercise11;

public class Person extends Individual {
  public Person(String name) { super(name); }
} ///:~
