//: typeinfo/pets/EgyptianMau.java
package exercise11;

public class EgyptianMau extends Cat {
  public EgyptianMau(String name) { super(name); }
  public EgyptianMau() { super(); }
} ///:~
