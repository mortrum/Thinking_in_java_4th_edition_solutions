//: typeinfo/pets/Cat.java
package exercise11;

public class Cat extends Pet {
  public Cat(String name) { super(name); }
  public Cat() { super(); }
} ///:~
