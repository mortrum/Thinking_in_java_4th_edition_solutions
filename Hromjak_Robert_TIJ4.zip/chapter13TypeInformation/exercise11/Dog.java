//: typeinfo/pets/Dog.java
package exercise11;

public class Dog extends Pet {
  public Dog(String name) { super(name); }
  public Dog() { super(); }
} ///:~
