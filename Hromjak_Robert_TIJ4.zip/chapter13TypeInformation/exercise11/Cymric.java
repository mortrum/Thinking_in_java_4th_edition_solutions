//: typeinfo/pets/Cymric.java
package exercise11;

public class Cymric extends Manx {
  public Cymric(String name) { super(name); }
  public Cymric() { super(); }
} ///:~
