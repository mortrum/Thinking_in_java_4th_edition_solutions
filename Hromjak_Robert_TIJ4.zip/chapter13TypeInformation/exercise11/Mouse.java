//: typeinfo/pets/Mouse.java
package exercise11;

public class Mouse extends Rodent {
  public Mouse(String name) { super(name); }
  public Mouse() { super(); }
} ///:~
