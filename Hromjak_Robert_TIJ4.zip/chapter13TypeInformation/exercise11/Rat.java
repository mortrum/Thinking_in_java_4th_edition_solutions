//: typeinfo/pets/Rat.java
package exercise11;

public class Rat extends Rodent {
  public Rat(String name) { super(name); }
  public Rat() { super(); }
} ///:~
