//: typeinfo/pets/Mutt.java
package exercise11;

public class Mutt extends Dog {
  public Mutt(String name) { super(name); }
  public Mutt() { super(); }
} ///:~
