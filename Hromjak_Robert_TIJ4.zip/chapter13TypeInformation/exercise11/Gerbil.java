package exercise11;

public class Gerbil extends Rodent {
	public Gerbil(String name) { super(name); }

	public Gerbil() { super(); }
}
