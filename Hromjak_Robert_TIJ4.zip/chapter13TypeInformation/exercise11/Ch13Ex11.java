package exercise11;

public class Ch13Ex11 {
	/**
	 * Exercise 11: (2) Add Gerbil to the typeinfo.pets library and modify all the
	 * examples in this chapter to adapt to this new class.
	 * 
	 * @param args
	 * @return
	 */
	public static void main(String[] args) {
		Gerbil gerbil = new Gerbil();
		
	}
}
