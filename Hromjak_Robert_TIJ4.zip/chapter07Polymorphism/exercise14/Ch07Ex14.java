package exercise14;

class SomeObject {

	public SomeObject(String str) {
		System.out.println("SomeObject Constructor " + str);
	}

}

class Rodent {

	SomeObject object = new SomeObject("from Rodent");

	public Rodent() {
		System.out.println("Rodent Constructor");
	}

	void what() {
		System.out.println("Rodent");
	}
}

class Mouse extends Rodent {

	SomeObject object = new SomeObject("from Mouse");

	public Mouse() {
		System.out.println("Mouse Constructor");
	}

	void what() {
		System.out.println("Mouse");
	}
}

class Gerbil extends Rodent {

	SomeObject object = new SomeObject("from Gerbil");

	public Gerbil() {
		System.out.println("Gerbil Constructor");
	}

	void what() {
		System.out.println("Gerbil");
	}
}

class Hamster extends Rodent {
	Mouse mouse = new Mouse();

	public Hamster() {
		System.out.println("Hamster Constructor");
	}

	void what() {
		System.out.println("Hamster");
		mouse.what();
	}
}

public class Ch07Ex14 {

	/*
	 * Exercise 14: (4) Modify Exercise 12 so that one of the member objects is a
	 * shared object with reference counting, and demonstrate that it works
	 * properly.
	 */
	public static void main(String[] args) {
		Rodent[] rodents = { new Mouse(), new Gerbil(), new Hamster() };
		for (Rodent rodent : rodents) {
			rodent.what();
		}
	}
}
/*
SomeObject Constructor from Rodent
Rodent Constructor
SomeObject Constructor from Mouse
Mouse Constructor
SomeObject Constructor from Rodent
Rodent Constructor
SomeObject Constructor from Gerbil
Gerbil Constructor
SomeObject Constructor from Rodent
Rodent Constructor
SomeObject Constructor from Rodent
Rodent Constructor
SomeObject Constructor from Mouse
Mouse Constructor
Hamster Constructor
Mouse
Gerbil
Hamster
Mouse
*/
