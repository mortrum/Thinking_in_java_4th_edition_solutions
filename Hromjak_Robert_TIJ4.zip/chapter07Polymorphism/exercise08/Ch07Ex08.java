package exercise08;

import java.util.Random;

import polymorphism.music.Note;

class Instrument {
	void play(Note n) {
		System.out.println("Instrument.play() " + n);
	}

	String what() {
		return "Instrument";
	}

	void adjust() {
		System.out.println("Adjusting Instrument");
	}

	@Override
	public String toString() {
		return what();
	}
}

class Wind extends Instrument {
	void play(Note n) {
		System.out.println("Wind.play() " + n);
	}

	String what() {
		return "Wind";
	}

	void adjust() {
		System.out.println("Adjusting Wind");
	}

	@Override
	public String toString() {
		return what();
	}
}

class Percussion extends Instrument {
	void play(Note n) {
		System.out.println("Percussion.play() " + n);
	}

	String what() {
		return "Percussion";
	}

	void adjust() {
		System.out.println("Adjusting Percussion");
	}

	@Override
	public String toString() {
		return what();
	}
}

class Stringed extends Instrument {
	void play(Note n) {
		System.out.println("Stringed.play() " + n);
	}

	String what() {
		return "Stringed";
	}

	void adjust() {
		System.out.println("Adjusting Stringed");
	}

	@Override
	public String toString() {
		return what();
	}
}

class Brass extends Wind {
	void play(Note n) {
		System.out.println("Brass.play() " + n);
	}

	void adjust() {
		System.out.println("Adjusting Brass");
	}

	@Override
	public String toString() {
		return what();
	}
}

class Woodwind extends Wind {
	void play(Note n) {
		System.out.println("Woodwind.play() " + n);
	}

	String what() {
		return "Woodwind";
	}

	@Override
	public String toString() {
		return what();
	}
}

class RandomInstrumentGenerator {
	private Random rand = new Random(47);

	public Instrument next() {

		switch (rand.nextInt(5)) {
		default:
		case 0:
			return new Wind();
		case 1:
			return new Percussion();
		case 2:
			return new Stringed();
		case 3:
			return new Brass();
		case 4:
			return new Woodwind();
		}
	}
}

public class Ch07Ex08 {

	private static RandomInstrumentGenerator gen = new RandomInstrumentGenerator();

	public static void tune(Instrument i) {
		// ...
		i.play(Note.MIDDLE_C);
	}

	public static void tuneAll(Instrument[] e) {
		for (Instrument i : e)
			tune(i);
	}

	/**
	 * Exercise 8: (2) Modify Music3.java so that it randomly creates Instrument
	 * objects the way Shapes.java does.
	 * 
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		Instrument[] instruments = new Instrument[5];
		for (int i = 0; i < 5; i++) {
			instruments[i] = gen.next();
		}
		
		for (Instrument instrument : instruments) {
			tune(instrument);
		}
	}
}

/*
Brass.play() MIDDLE_C
Wind.play() MIDDLE_C
Brass.play() MIDDLE_C
Percussion.play() MIDDLE_C
Percussion.play() MIDDLE_C
*/
