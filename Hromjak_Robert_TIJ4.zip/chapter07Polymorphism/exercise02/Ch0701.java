package exercise02;

class Shape {
	public void draw() {
	}

	public void erase() {
	}
}

class Circle extends Shape {
	@Override
	public void draw() {
		System.out.println("Circle.draw()");
	}

	@Override
	public void erase() {
		System.out.println("Circle.erase()");
	}
}

class Triangle extends Shape {
	@Override
	public void draw() {
		System.out.println("Triangle.draw()");
	}

	@Override
	public void erase() {
		System.out.println("Triangle.erase()");
	}
}

public class Ch0701 {

	/**
	 * Exercise 2: (1) Add the @Override annotation to the shapes example
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

	}
}
