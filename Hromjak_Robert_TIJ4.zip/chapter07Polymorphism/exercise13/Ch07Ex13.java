package exercise13;

class Shared {
	private int refcount = 0;
	private static long counter = 0;
	private final long id = counter++;

	public Shared() {
		System.out.println("Creating " + this);
	}

	public void addRef() {
		refcount++;
	}

	protected void dispose() {
		if (--refcount == 0)
			System.out.println("Disposing " + this);
	}

	public String toString() {
		return "Shared " + id;
	}

	protected void finalize() {
		System.out.println("finalize()");
	}
}

class Composing {
	private Shared shared;
	private static long counter = 0;
	private final long id = counter++;

	public Composing(Shared shared) {
		System.out.println("Creating " + this);
		this.shared = shared;
		this.shared.addRef();
	}

	protected void dispose() {
		System.out.println("disposing " + this);
		shared.dispose();
	}

	public String toString() {
		return "Composing " + id;
	}
	
	protected void finalize() {
		if(counter == 0)
			System.err.println("counter 0");
		System.out.println("finalize()");
	}
}

public class Ch07Ex13 {

	/**
	 * Exercise 13: (3) Add a finalize( ) method to ReferenceCounting.java to verify
	 * the termination condition (see the Initialization & Cleanup chapter).
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Shared shared = new Shared();
		Composing[] composing = { new Composing(shared), new Composing(shared), new Composing(shared),
				new Composing(shared), new Composing(shared) };

		System.out.println("-----");
		for (Composing c : composing)
			c.finalize();
		
	}
}
/*
Creating Shared 0
Creating Composing 0
Creating Composing 1
Creating Composing 2
Creating Composing 3
Creating Composing 4
-----
*/