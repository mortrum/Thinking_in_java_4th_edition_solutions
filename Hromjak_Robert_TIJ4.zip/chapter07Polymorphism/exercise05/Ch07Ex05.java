package exercise05;

class Cycle {
	private int countOfWheels = 0;

	int wheels() {
		return countOfWheels;
	}

	void ride() {
		System.out.println("number of wheels: " + countOfWheels);
	}

	public Cycle(int countOfWheels) {
		super();
		this.countOfWheels = countOfWheels;
	}

}

class Unicycle extends Cycle {

	public Unicycle(int countOfWheels) {
		super(countOfWheels);
	}

}

class Bicycle extends Cycle {
	public Bicycle(int countOfWheels) {
		super(countOfWheels);
	}
}

class Tricycle extends Cycle {
	public Tricycle(int countOfWheels) {
		super(countOfWheels);
	}
}

public class Ch07Ex05 {

	/**
	 * Exercise 5: (1) Starting from Exercise 1, add a wheels( ) method in Cycle,
	 * which returns the number of wheels. Modify ride( ) to call wheels( ) and
	 * verify that polymorphism works.
	 * 
	 * @param args
	 * @return number of wheels: 2
	 * 
	 */
	public static void main(String[] args) {
		Bicycle bicycle = new Bicycle(2);
		bicycle.ride();
	}
}
