package exercise04;

class Shape {
	public void draw() {
	}

	public void erase() {
	}

	public void print() {
		System.out.println("print a message");
	}
}

class Circle extends Shape {
	@Override
	public void draw() {
		System.out.println("Circle.draw()");
	}

	@Override
	public void erase() {
		System.out.println("Circle.erase()");
	}
}

class Triangle extends Shape {
	@Override
	public void draw() {
		System.out.println("Triangle.draw()");
	}

	@Override
	public void erase() {
		System.out.println("Triangle.erase()");
	}

	@Override
	public void print() {
		System.out.println("print from triangle");
	}
}

class NewType extends Shape {
	@Override
	public void draw() {
		System.out.println("NewType.draw()");
	}

	@Override
	public void erase() {
		System.out.println("NewType.erase()");
	}
}

public class Ch07Ex04 {

	/**
	 * Exercise 4: (2) Add a new type of Shape to Shapes.java and verify in main( )
	 * that polymorphism works for your new type as it does in the old types.
	 * 
	 * @param args
	 * @return NewType.draw() NewType.erase()
	 * 
	 */
	public static void main(String[] args) {
		NewType newType = new NewType();
		newType.draw();
		newType.erase();

	}
}
