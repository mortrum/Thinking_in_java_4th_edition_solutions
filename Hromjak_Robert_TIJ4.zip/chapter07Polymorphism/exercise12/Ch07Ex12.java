package exercise12;

class SomeObject {

	public SomeObject(String str) {
		System.out.println("SomeObject Constructor " + str);
	}
}

class Rodent {

	SomeObject object = new SomeObject("from Rodent");

	public Rodent() {
		System.out.println("Rodent Constructor");
	}

	void what() {
		System.out.println("Rodent");
	}
}

class Mouse extends Rodent {

	SomeObject object = new SomeObject("from Mouse");

	public Mouse() {
		System.out.println("Mouse Constructor");
	}

	void what() {
		System.out.println("Mouse");
	}
}

class Gerbil extends Rodent {

	SomeObject object = new SomeObject("from Gerbil");

	public Gerbil() {
		System.out.println("Gerbil Constructor");
	}

	void what() {
		System.out.println("Gerbil");
	}
}

class Hamster extends Rodent {
	SomeObject object = new SomeObject("from Hamster");

	public Hamster() {
		System.out.println("Hamster Constructor");
	}

	void what() {
		System.out.println("Hamster");
	}
}

public class Ch07Ex12 {

	/**
	 * Exercise 12: (3) Modify Exercise 9 so that it demonstrates the order of
	 * initialization of the base classes and derived classes. Now add member
	 * objects to both the base and derived classes and show the order in which
	 * their initialization occurs during construction.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Rodent[] rodents = { new Mouse(), new Gerbil(), new Hamster() };
		for (Rodent rodent : rodents) {
			rodent.what();
		}
	}
}
/*
SomeObject Constructor from Rodent
Rodent Constructor
SomeObject Constructor from Mouse
Mouse Constructor
SomeObject Constructor from Rodent
Rodent Constructor
SomeObject Constructor from Gerbil
Gerbil Constructor
SomeObject Constructor from Rodent
Rodent Constructor
SomeObject Constructor from Hamster
Hamster Constructor
Mouse
Gerbil
Hamster
*/
