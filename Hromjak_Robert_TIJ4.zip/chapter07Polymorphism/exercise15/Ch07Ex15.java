package exercise15;

class Glyph {
	void draw() {
		System.out.println("Glyph.draw()");
	}

	Glyph() {
		System.out.println("Glyph() before draw()");
		draw();
		System.out.println("Glyph() after draw()");
	}
}

class RoundGlyph extends Glyph {
	private int radius = 1;

	RoundGlyph(int r) {
		radius = r;
		System.out.println("RoundGlyph.RoundGlyph(), radius = " + radius);
	}

	void draw() {
		System.out.println("RoundGlyph.draw(), radius = " + radius);
	}
}

class RectangularGlyph extends Glyph {
	private int a = 1;
	private int b = 1;

	public RectangularGlyph(int a, int b) {
		super();
		this.a = a;
		this.b = b;
		System.out.println("RectangularGlyph.draw(), a = " + a + " b = " + b);
	}

	void draw() {
		System.out.println("RectangularGlyph.draw(), a = " + a + " b = " + b);
	}

}

public class Ch07Ex15 {
	/**
	 * Exercise 15: (2) Add a RectangularGlyph to PolyConstructors.java and
	 * demonstrate the problem described in this section.
	 * 
	 * @author robert.hromjak
	 *
	 */
	public static void main(String[] args) {
		new RectangularGlyph(5, 10);
	}
}
/*
	Glyph() before draw()
	RectangularGlyph.draw(), a = 0 b = 0
	Glyph() after draw()
	RectangularGlyph.draw(), a = 5 b = 10
*/
