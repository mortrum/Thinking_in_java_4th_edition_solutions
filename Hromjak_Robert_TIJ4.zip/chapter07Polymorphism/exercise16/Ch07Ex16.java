package exercise16;

class Allert {
	public void act() {
	}
}

class HappyAllert extends Allert {
	public void act() {
		System.out.println("HappyAllert");
	}
}

class SadAllert extends Allert {
	public void act() {
		System.out.println("SadAllert");
	}
}

class NeutralAllert extends Allert {
	public void act() {
		System.out.println("NeutralAllert");
	}
}

class Starship {
	private Allert allert = new HappyAllert();

	public void change(Allert allert) {
		this.allert = allert;
	}

	public void alertStatus() {
		allert.act();
	}
}



public class Ch07Ex16 {

	/**
	 * Exercise 16: (3) Following the example in Transmogrify.java, create a
	 * Starship class containing an AlertStatus reference that can indicate three
	 * different states. Include methods to change the states.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Starship starship = new Starship();
		starship.alertStatus();
		starship.change(new SadAllert());
		starship.alertStatus();
		starship.change(new NeutralAllert());
		starship.alertStatus();
	}
}
/*
HappyAllert
SadAllert
NeutralAllert
*/