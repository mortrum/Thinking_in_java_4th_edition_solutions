package exercise01;

class Cycle {
	void ride() {
		System.out.println("ride!");
	}
}

class Unicycle extends Cycle {

}

class Bicycle extends Cycle {

}

class Tricycle extends Cycle {

}

public class Ch07Ex01 {

	/**
	 * Exercise 1: (2) Create a Cycle class, with subclasses Unicycle, Bicycle and
	 * Tricycle. Demonstrate that an instance of each type can be upcast to Cycle
	 * via a ride( ) method.
	 * 
	 * @param args
	 * @return ride! ride! ride!
	 * 
	 */
	public static void main(String[] args) {
		Unicycle unicycle = new Unicycle();
		Bicycle bicycle = new Bicycle();
		Tricycle tricycle = new Tricycle();

		Cycle cu = unicycle;
		Cycle cb = bicycle;
		Cycle ct = tricycle;
		
		cu.ride();
		cb.ride();
		ct.ride();

	}
}
