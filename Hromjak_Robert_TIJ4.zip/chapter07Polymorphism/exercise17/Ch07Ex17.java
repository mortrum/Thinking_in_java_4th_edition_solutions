package exercise17;

class Cycle {
	void ride() {
		System.out.println("ride!");
	}

	void balance() {
		System.out.println("Cycle balance");
	}
}

class Unicycle extends Cycle {

	void balance() {
		System.out.println("Unicycle balance");
	}
}

class Bicycle extends Cycle {

	void balance() {
		System.out.println("Bicycle balance");
	}
}

class Tricycle extends Cycle {

}

public class Ch07Ex17 {

	/**
	 * Exercise 17: (2) Using the Cycle hierarchy from Exercise 1, add a balance( )
	 * method to Unicycle and Bicycle, but not to Tricycle. Create instances of all
	 * three types and upcast them to an array of Cycle. Try to call balance( ) on
	 * each element of the array and observe the results. Downcast and call balance(
	 * ) and observe what happens.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Unicycle unicycle = new Unicycle();
		Bicycle bicycle = new Bicycle();
		Tricycle tricycle = new Tricycle();

		Cycle[] cycles = { unicycle, bicycle, tricycle };
		try {
			for (Cycle cycle : cycles) {
				cycle.balance();
			}
		} catch (Exception e) {
			System.err.println(e);
		}
		System.out.println("---------");

		unicycle.balance();
		bicycle.balance();
		tricycle.balance();

	}
}

/*
Unicycle balance
Bicycle balance
Cycle balance
---------
Unicycle balance
Bicycle balance
Cycle balance
*/