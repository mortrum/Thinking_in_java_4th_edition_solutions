package exercise10;

class Base {
	void first() {
		second();
		System.out.println("Base first");
	}

	void second() {
		System.out.println("Base second");
	}
}

class Derived extends Base {
	void second() {
		System.out.println("Derived second");
	}
}

public class Ch07Ex10 {

	/**
	 * Exercise 10: (3) Create a base class with two methods. In the first method,
	 * call the second method. Inherit a class and override the second method.
	 * Create an object of the derived class, upcast it to the base type, and call
	 * the first method. Explain what happens.
	 * 
	 * @param args
	 * @return Derived second Base first
	 * 
	 */
	public static void main(String[] args) {
		Derived derived = new Derived();
		Base base = (Base) derived;
		base.first();
	}
}
