package exercise06;

import polymorphism.music.Note;

class Instrument {
	void play(Note n) {
		System.out.println("Instrument.play() " + n);
	}

	String what() {
		return "Instrument";
	}

	void adjust() {
		System.out.println("Adjusting Instrument");
	}

	@Override
	public String toString() {
		return what();
	}
}

class Wind extends Instrument {
	void play(Note n) {
		System.out.println("Wind.play() " + n);
	}

	String what() {
		return "Wind";
	}

	void adjust() {
		System.out.println("Adjusting Wind");
	}
	
	@Override
	public String toString() {
		return what();
	}
}

class Percussion extends Instrument {
	void play(Note n) {
		System.out.println("Percussion.play() " + n);
	}

	String what() {
		return "Percussion";
	}

	void adjust() {
		System.out.println("Adjusting Percussion");
	}
	
	@Override
	public String toString() {
		return what();
	}
}

class Stringed extends Instrument {
	void play(Note n) {
		System.out.println("Stringed.play() " + n);
	}

	String what() {
		return "Stringed";
	}

	void adjust() {
		System.out.println("Adjusting Stringed");
	}
	
	@Override
	public String toString() {
		return what();
	}
}

class Brass extends Wind {
	void play(Note n) {
		System.out.println("Brass.play() " + n);
	}

	void adjust() {
		System.out.println("Adjusting Brass");
	}
	
	@Override
	public String toString() {
		return what();
	}
}

class Woodwind extends Wind {
	void play(Note n) {
		System.out.println("Woodwind.play() " + n);
	}

	String what() {
		return "Woodwind";
	}
	
	@Override
	public String toString() {
		return what();
	}
}

public class Ch07Ex06 {

	public static void tune(Instrument i) {
		// ...
		i.play(Note.MIDDLE_C);
	}

	public static void tuneAll(Instrument[] e) {
		for (Instrument i : e)
			tune(i);
	}

	/**
	 * Exercise 6: (1) Change Music3.java so that what( ) becomes the root Object
	 * method toString( ). Try printing the Instrument objects using
	 * System.out.println( ) (without any casting). page 202
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// Upcasting during addition to the array:
		Instrument[] orchestra = { new Wind(), new Percussion(), new Stringed(), new Brass(), new Woodwind() };
		tuneAll(orchestra);
		
		Wind wind = new Wind();
		Percussion percussion = new Percussion();
		Stringed stringed = new Stringed();
		Brass brass = new Brass();
		Woodwind woodwind = new Woodwind();
		
		System.out.println(wind.toString());
		System.out.println(percussion.toString());
		System.out.println(stringed.toString());
		System.out.println(brass.toString());
		System.out.println(woodwind.toString());
	}
}

/*
Output:
Wind.play() MIDDLE_C
Percussion.play() MIDDLE_C
Stringed.play() MIDDLE_C
Brass.play() MIDDLE_C
Woodwind.play() MIDDLE_C
Wind
Percussion
Stringed
Wind
Woodwind
*/