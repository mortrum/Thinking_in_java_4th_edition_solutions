package exercise09;

class Rodent {
	void what() {
		System.out.println("Rodent");
	}
}

class Mouse extends Rodent {
	void what() {
		System.out.println("Mouse");
	}
}

class Gerbil extends Rodent {
	void what() {
		System.out.println("Gerbil");
	}
}

class Hamster extends Rodent {
	void what() {
		System.out.println("Hamster");
	}
}

public class Ch07Ex09 {

	/**
	 * Exercise 9: (3) Create an inheritance hierarchy of Rodent: Mouse, Gerbil,
	 * Hamster, etc. In the base class, provide methods that are common to all
	 * Rodents, and override these in the derived classes to perform different
	 * behaviors depending on the specific type of Rodent. Create an array of
	 * Rodent, fill it with different specific types of Rodents, and call your
	 * base-class methods to see what happens.
	 * 
	 * @param args
	 * @return Mouse Gerbil Hamster
	 * 
	 */
	public static void main(String[] args) {
		Rodent[] rodents = { new Mouse(), new Gerbil(), new Hamster() };
		for (Rodent rodent : rodents) {
			rodent.what();
		}

	}
}
