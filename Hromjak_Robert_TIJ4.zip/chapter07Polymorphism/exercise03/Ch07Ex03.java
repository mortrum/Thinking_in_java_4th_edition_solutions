package exercise03;

class Shape {
	public void draw() {
	}

	public void erase() {
	}

	public void print() {
		System.out.println("print a message");
	}
}

class Circle extends Shape {
	@Override
	public void draw() {
		System.out.println("Circle.draw()");
	}

	@Override
	public void erase() {
		System.out.println("Circle.erase()");
	}
}

class Triangle extends Shape {
	@Override
	public void draw() {
		System.out.println("Triangle.draw()");
	}

	@Override
	public void erase() {
		System.out.println("Triangle.erase()");
	}

	@Override
	public void print() {
		System.out.println("print from triangle");
	}
}

public class Ch07Ex03 {

	/**
	 * Exercise 3: (1) Add a new method in the base class of Shapes.java that prints
	 * a message, but don�t override it in the derived classes. a) Explain what
	 * happens. b) Now override it in one of the derived classes but not the others,
	 * and see what happens. c) Finally, override it in all the derived classes.
	 * 
	 * @param args
	 * @return print a message print from triangle
	 * 
	 */
	public static void main(String[] args) {
		Circle circle = new Circle();
		circle.print();// a) we use parent method

		Triangle triangle = new Triangle();
		triangle.print();
	}
}
