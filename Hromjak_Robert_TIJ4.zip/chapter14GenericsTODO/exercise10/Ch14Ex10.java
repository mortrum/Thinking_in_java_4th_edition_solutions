package exercise10;

public class Ch14Ex10 {
	static <T> void f(T x, int y, T z) {
		 System.out.println(x.getClass().getName());
		 System.out.println(y);
		 System.out.println(z.getClass().getName());
		 }
	/**
	 * Exercise 10: (1) Modify the previous exercise so that one of f( )�s arguments
	 * is nonparameterized.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		f("alma", 1, 1l);
	}
}
/*
java.lang.String
1
java.lang.Long
*/