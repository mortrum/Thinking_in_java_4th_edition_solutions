package exercise07;

import java.util.Iterator;

interface Generator<T> {
	T next();
}

class Fibonacci implements Generator<Integer> {
	private int count = 0;
	private int max = 18;
	private int n = 0;

	public Integer next() {
		return fib(count++);
	}

	private int fib(int n) {
		if (n < 2)
			return 1;
		return fib(n - 2) + fib(n - 1);
	}

	public Iterator<Integer> iterator() {
		return new Iterator<Integer>() {
			public boolean hasNext() {
				return n < max;
			}

			public Integer next() {
				n++;
				return Fibonacci.this.next();
			}
		};
	}

	/*
	 * Exercise 7: (2) Use composition instead of inheritance to adapt Fibonacci to
	 * make it Iterable.
	 * 
	 * @return 1 1 2 3 5 8 13 21 34 55 89 144 233 377 610 987 1597 2584
	 * 
	 */
	public static void main(String[] args) {
		Fibonacci gen = new Fibonacci();
		Iterator it = gen.iterator();

		while (it.hasNext()) {
			System.out.println(it.next());
		}
	}
}
/*
1
1
2
3
5
8
13
21
34
55
89
144
233
377
610
987
1597
2584
*/