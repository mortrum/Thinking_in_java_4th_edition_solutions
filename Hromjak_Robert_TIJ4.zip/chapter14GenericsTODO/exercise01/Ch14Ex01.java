package exercise01;


import typeinfo.pets.ForNameCreator;
import typeinfo.pets.Pet;


class Holder<T> {
	private T item;

	public Holder() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Holder(T t) {
		this.item = t;
	}

	public T set(T t) {
		T old = item;
		item = t;
		return old;
	}

	public T get() {
		return item;
	}
}

public class Ch14Ex01 {

	/**
	 * Exercise 1: (1) Use Holders with the typeinfo.pets library to show that a
	 * Holders that is specified to hold a base type can also hold a derived type.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		ForNameCreator petsCreator = new ForNameCreator();
		Holder<Pet> petsHolder = new Holder<Pet>();
		int size = 10;
		for (int i = 0; i < size; i++) {
			petsHolder.set(petsCreator.randomPet());
			System.out.println(petsHolder.get());
		}
	}
}
/*
Rat
Manx
Cymric
Mutt
Pug
Cymric
Pug
Manx
Cymric
Rat
*/