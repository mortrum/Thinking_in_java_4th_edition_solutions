package exercise08;

import java.util.Random;

interface Generator<T> {
	T next();
}

interface StoryCharacters extends Generator<StoryCharacters> {
}

enum GoodGuys implements StoryCharacters {
	Jack_Nicholson, Ralph_Fiennes, Daniel_Day_Lewis, Robert_De_Niro, Al_Pacino, Dustin_Hoffman, Tom_Hanks;
	private final Random r = new Random();

	public StoryCharacters next() {
		return values()[r.nextInt(values().length)];
	}
}

enum BadGuys implements StoryCharacters {
	Brad_Pitt, Marlon_Brando, Jeremy_Irons, Denzel_Washington, Gene_Hackman, Jeff_Bridges, Tim_Robbins, Henry_Fonda;
	private final Random r = new Random();

	public StoryCharacters next() {
		return values()[r.nextInt(values().length)];
	}
}

public class Ch14Ex08 {

	/**
	 * Exercise 8: (2) Following the form of the Coffee example, create a hierarchy
	 * of StoryCharacters from your favorite movie, dividing them into GoodGuys and
	 * BadGuys. Create a generator for StoryCharacters, following the form of
	 * CoffeeGenerator.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		int size = 5;
		System.out.println("Show me " + size + " Good Guys: ");
		for (int i = 0; i < size; i++) {
			System.out.println(GoodGuys.Jack_Nicholson.next());
		}
		System.out.println("Show me " + size + " Bad Guys: ");
		for (int i = 0; i < size; i++) {
			System.out.println(BadGuys.Brad_Pitt.next());
		}
	}
}
/*
Show me 5 Good Guys: 
Daniel_Day_Lewis
Ralph_Fiennes
Jack_Nicholson
Jack_Nicholson
Tom_Hanks
Show me 5 Bad Guys: 
Henry_Fonda
Denzel_Washington
Tim_Robbins
Jeremy_Irons
Tim_Robbins
*/