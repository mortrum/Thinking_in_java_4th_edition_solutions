package exercise09;

public class Ch14Ex09 {
	static <T> void f(T x, T y, T z) {
		 System.out.println(x.getClass().getName());
		 System.out.println(y.getClass().getName());
		 System.out.println(z.getClass().getName());
		 } 
	/**
	 * Exercise 9: (1) Modify GenericMethods.java so that f( ) accepts three
	 * arguments, all of which are of a different parameterized type.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		f("da", 1, 1l);
	}
}
/*
java.lang.String
java.lang.Integer
java.lang.Long
*/