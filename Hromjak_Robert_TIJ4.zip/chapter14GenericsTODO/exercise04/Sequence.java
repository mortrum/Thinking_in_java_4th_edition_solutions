package exercise04;
// Holds a sequence of Objects.

interface Selector<T> {
	boolean end();

	Object current();

	void next();
}

public class Sequence<T> {
	private T[] items;
	private int next = 0;

	public Sequence(int size) {
		@SuppressWarnings("unchecked")
		T[] tArray = (T[]) new Object[size]; 
		items = tArray;
	}

	public void add(T t) {
		if (next < items.length)
			items[next++] = t;
	}

	private class SequenceSelector implements Selector<T> {
		private int i = 0;

		public boolean end() {
			return i == items.length;
		}

		public Object current() {
			return items[i];
		}

		public void next() {
			if (i < items.length)
				i++;
		}
	}

	public Selector<T> selector() {
		return new SequenceSelector();
	}

	/**
	 * Exercise 4: (3) "Generify" innerclasses/Sequence.java.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Sequence<String> sequence = new Sequence<String>(10);
		for (int i = 0; i < 10; i++)
			sequence.add(Integer.toString(i));
		Selector<String> selector = sequence.selector();
		while (!selector.end()) {
			System.out.print(selector.current() + " ");
			selector.next();
		}
	}
} 
/*
0 1 2 3 4 5 6 7 8 9 
*/