package exercise06;

import java.util.ArrayList;
import java.util.Random;

class RandomList<T> {
	private ArrayList<T> storage = new ArrayList<T>();
	private Random rand = new Random(47);

	public void add(T item) {
		storage.add(item);
	}

	public T select() {
		return storage.get(rand.nextInt(storage.size()));
	}

	/**
	 * Exercise 6: (1) Use RandomList with two more types in addition to the one
	 * shown in main( ).
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		RandomList<String> rs = new RandomList<String>();
		for (String s : ("The quick brown fox jumped over " + "the lazy brown dog").split(" "))
			rs.add(s);
		for (int i = 0; i < 11; i++)
			System.out.print(rs.select() + " ");

		System.out.println("");
		RandomList<Integer> rsI = new RandomList<Integer>();
		for (int i = 0; i < 10; i++) {
			rsI.add(i);
		}
		for (int i = 0; i < 11; i++)
			System.out.print(rsI.select() + " ");

		System.out.println();

		RandomList<Boolean> rsB = new RandomList<Boolean>();
		Boolean flag = false;
		for (int i = 0; i < 10; i++) {
			flag = !flag;
			rsB.add(flag);
		}
		for (int i = 0; i < 11; i++)
			System.out.print(rsB.select() + " ");
	}
}
/**
 * brown over fox quick quick dog brown The brown lazy brown 
 * 8 5 3 1 1 9 8 0 2 7 8
 * true false false false false false true true true false true
 */