package exercise02;

import typeinfo.pets.ForNameCreator;
import typeinfo.pets.Pet;

class Holder<T> {
	private T first;
	private T second;
	private T third;

	
	public T getFirst() {
		return first;
	}


	public void setFirst(T first) {
		this.first = first;
	}


	public T getSecond() {
		return second;
	}


	public void setSecond(T second) {
		this.second = second;
	}


	public T getThird() {
		return third;
	}


	public void setThird(T third) {
		this.third = third;
	}


	public String toString() {
		return "[First: " + first + "], [Second: " + second + "], [Third: " + third + "]";
	}

}

public class Ch14Ex02 {

	/**
	 * Exercise 2: (1) Create a holder class that holds three objects of the same
	 * type, along with the methods to store and fetch those objects and a
	 * constructor to initialize all three.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Holder<Pet> threePets = new Holder<>();
        ForNameCreator myCreator = new ForNameCreator();
        threePets.setFirst(myCreator.randomPet());
        threePets.setSecond(myCreator.randomPet());
        threePets.setThird(myCreator.randomPet());
        System.out.println(threePets);
	}
}
/*
[First: Rat], [Second: Manx], [Third: Cymric]
*/