package exercise03;

class FiveTuple<A, B, C, D, E> {
	public final A first;
	public final B second;
	public final C third;
	public final D fourth;
	public final E fifth;

	public FiveTuple(A first, B second, C third, D fourth, E fifth) {
		super();
		this.first = first;
		this.second = second;
		this.third = third;
		this.fourth = fourth;
		this.fifth = fifth;
	}

	public String toString() {
		return "(" + first + ", " + second + ", " + third + ", " + fourth + ", " + fifth + ")";
	}
}

class SixTuple<A, B, C, D, E, F> extends FiveTuple<A, B, C, D, E> {
	public final E sixth;

	public SixTuple(A first, B second, C third, D fourth, E fifth, E sixth) {
		super(first, second, third, fourth, fifth);
		this.sixth = sixth;
	}

	public String toString() {
		return "(" + first + ", " + second + ", " + third + ", " + fourth + ", " + fifth + ", " + sixth + ")";
	}

}

public class Ch14Ex03 {
	static SixTuple<Integer, Integer, String, Integer, Integer, Integer> six() {
		return new SixTuple<Integer, Integer, String, Integer, Integer, Integer>(1, 2, "hi", 3, 4, 5);
	}

	/*
	 * Exercise 3 : (1) Create and test a SixTuple generic.
	 */
	public static void main(String[] args) {
		System.out.println(six());
	}
}
/*
(1, 2, hi, 3, 4, 5)
*/