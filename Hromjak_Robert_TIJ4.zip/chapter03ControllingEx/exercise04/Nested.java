package exercise04;

public class Nested {

	/**
	 * Exercise 4: (3) Write a program that uses two nested for loops and the
	 * modulus operator (%) to detect and print prime numbers (integral numbers that
	 * are not evenly divisible by any other numbers except for themselves and 1).
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		int number = 1;

		int max = 100;

		while (number < max) {
			int count = 0;
			int i = 1;
			while (i < number) {
				if (number % i == 0)
					count++;
				i++;
			}
			if (count == 1)
				System.out.println("prime: " + number);
			number++;
		}

	}

}
/*
prime: 2
prime: 3
prime: 5
prime: 7
prime: 11
prime: 13
prime: 17
prime: 19
prime: 23
prime: 29
prime: 31
prime: 37
prime: 41
prime: 43
prime: 47
prime: 53
prime: 59
prime: 61
prime: 67
prime: 71
prime: 73
prime: 79
prime: 83
prime: 89
prime: 97
*/