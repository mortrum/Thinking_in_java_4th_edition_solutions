package exercise10;

import java.util.*;

public class Vampire {
	static String removeFromeStringBad(String s, String bad) { // kitorli a szambol egy szamot erteket Pl: removeFromeStringBad("1234", 2)  => "134"

		StringBuilder sb = new StringBuilder(s);
		sb.deleteCharAt(sb.indexOf(bad));

		return sb.toString();
	}

	static boolean isVampire(int begin, int end, int four) { 
		if (begin * end == four && isContains(begin, end, four))
			return true;
		else
			return false;
	}

	/*
	 * beginI = elso 2 jegyu szam
	 * endI = masodik 2 jegyu szam
	 * fourI = 4 jegyu szam
	 */
	static boolean isContains(int beginI, int endI, int fourI) { 
		String begin = Integer.toString(beginI);
		String end = Integer.toString(endI);
		String fourS = Integer.toString(fourI);

		String beginX = String.valueOf(begin.charAt(0));
		String beginY = String.valueOf(begin.charAt(1));
		String endY = String.valueOf(end.charAt(0));
		String endX = String.valueOf(end.charAt(1));

		//kitorli ha van eredeti szamba valamelyik 2 jegyu szam
		if (fourS.contains(beginX))
			fourS = removeFromeStringBad(fourS, beginX);
		if (fourS.contains(beginY))
			fourS = removeFromeStringBad(fourS, beginY);
		if (fourS.contains(endX))
			fourS = removeFromeStringBad(fourS, endX);
		if (fourS.contains(endY))
			fourS = removeFromeStringBad(fourS, endY);

		if (fourS.isEmpty())
			return true;

		return false;
	}

	/**
	 * Exercise 10: (5) A vampire number has an even number of digits and is formed
	 * by multiplying a pair of numbers containing half the number of digits of the
	 * result. The digits are taken from the original number in any order. Pairs of
	 * trailing zeroes are not allowed. Examples include: 1260 = 21 * 60; 1827 = 21
	 * * 87; 2187 = 27 * 81; Write a program that finds all the 4-digit vampire
	 * numbers. (Suggested by Dan Forhan.)
	 * 
	 * @param args
	 * @return 1260 1395 1435 1530 1827 2187 6880
	 * 
	 */
	public static void main(String[] args) {
		Set<Integer> set = new HashSet<>();
		for (int i = 10; i < 100; i++) {
			for (int j = 10; j < 100; j++) {
				for (int k = 1000; k < 10000; k++) {
					if (isVampire(i, j, k))
						set.add(k);

				}

			}
		}
		set.stream().sorted().forEach(x -> System.out.println(x));
	}

}
