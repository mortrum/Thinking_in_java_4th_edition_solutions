package exercise08;

public class TestCh03Ex08 {

	/**
	 * Exercise 8: (2) Create a switch statement that prints a message for each
	 * case, and put the switch inside a for loop that tries each case. Put a break
	 * after each case and test it, then remove the breaks and see what happens.
	 * 
	 * @param args
	 * @return one two three four five default!
	 * two three four five default! 
	 * three four five default! 
	 * four five default!
	 * five default!
	 * 
	 */
	public static void main(String[] args) {

		for (int i = 1; i < 6; i++) {
			switch (i) {
			case 1:
				System.out.println("one");
				// break;
			case 2:
				System.out.println("two");
				// break;
			case 3:
				System.out.println("three");
				// break;
			case 4:
				System.out.println("four");
				// break;
			case 5:
				System.out.println("five");
				// break;
			default:
				System.out.println("default!");

			}
		}

	}

}
