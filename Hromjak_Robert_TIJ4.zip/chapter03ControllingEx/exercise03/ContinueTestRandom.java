package exercise03;

import java.util.Random;
import java.util.Scanner;

public class ContinueTestRandom {
	/**
	 * Exercise 3: (1) Modify Exercise 2 so that your code is surrounded by an
	 * �infinite� while loop. It will then run until you interrupt it from the
	 * keyboard (typically by pressing ControlC).
	 * 
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		Random rn = new Random();

		int previous = 0;
		int now;
		Scanner sc = new Scanner(System.in);

		while (true) {
			now = rn.nextInt(100);

			if (previous < now)
				System.out.println("grater: " + now);
			else

				System.out.println("less: " + now);

			previous = now;
		}

	}
}
/*
grater: 57
less: 53
less: 26
grater: 81
less: 73
less: 33
grater: 67
less: 28
grater: 32
grater: 98
less: 55
less: 44
grater: 87
less: 57
grater: 83
less: 69
grater: 78
less: 23
grater: 94
less: 89
less: 59
less: 59
less: 51
grater: 72
less: 29
 
*/