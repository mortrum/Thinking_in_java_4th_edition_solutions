package exercise02;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class TestRandom {
	/**
	 * Exercise 2: (2) Write a program that generates 25 random int values. For each
	 * value, use an if-else statement to classify it as greater than, less than, or
	 * equal to a second randomly generated value.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Random rn = new Random();
		List<Integer> greater = new ArrayList<>();
		List<Integer> less = new ArrayList<>();
		int previous = 0;
		int now;
		for (int i = 0; i < 10; i++) {
			now = rn.nextInt(100);
			if (previous < now)
				greater.add(now);
			else
				less.add(now);

			previous = now;
		}

		System.out.print("greater: ");
		greater.stream().forEach(x -> System.out.print(x + " "));
		System.out.println();
		System.out.print("less: ");
		less.stream().forEach(x -> System.out.print(x + " "));
	}

}
/*
greater: 52 56 6 25 59 
less: 22 28 9 2 25 
*/