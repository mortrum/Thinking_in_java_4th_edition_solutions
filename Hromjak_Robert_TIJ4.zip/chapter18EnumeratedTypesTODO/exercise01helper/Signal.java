package exercise01helper;

public enum Signal {
	GREEN, YELLOW, RED,
}