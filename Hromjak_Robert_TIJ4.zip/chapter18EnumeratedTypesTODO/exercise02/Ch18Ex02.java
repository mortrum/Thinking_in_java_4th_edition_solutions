package exercise02;

import java.util.Random;

enum CartoonCharacter {
	SLAPPY, SPANKY, PUNCHY, SILLY, BOUNCY, NUTTY, BOB;

	private static Random rand = new Random();

	public static CartoonCharacter next() {
		return values()[rand.nextInt(values().length)];
	}
}

public class Ch18Ex02 {
	/**
	 * Exercise 2: (2) Instead of implementing an interface, make next( ) a static
	 * method. What are the benefits and drawbacks of this approach?
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		for (int i = 0; i < 10; i++) {
			System.out.println(CartoonCharacter.next());
		}
	}
}
/*
BOUNCY
PUNCHY
SPANKY
BOB
SLAPPY
SPANKY
SLAPPY
BOUNCY
BOB
BOUNCY
*/