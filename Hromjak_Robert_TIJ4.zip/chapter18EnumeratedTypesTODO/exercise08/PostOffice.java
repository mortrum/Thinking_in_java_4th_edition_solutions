package exercise08;

import static net.mindview.util.Print.print;

// Modeling a post office.
import java.util.Iterator;

import net.mindview.util.Enums;

class Mail {
	// The NO's lower the probability of random selection:
	enum GeneralDelivery {
		YES, NO1, NO2, NO3, NO4, NO5
	}

	enum Scannability {
		UNSCANNABLE, YES1, YES2, YES3, YES4
	}

	enum Readability {
		ILLEGIBLE, YES1, YES2, YES3, YES4
	}

	enum Forward {
		YES, NO
	}

	enum Address {
		INCORRECT, OK1, OK2, OK3, OK4, OK5, OK6
	}

	enum ReturnAddress {
		MISSING, OK1, OK2, OK3, OK4, OK5
	}

	GeneralDelivery generalDelivery;
	Scannability scannability;
	Readability readability;
	Address address;
	Forward forward;
	ReturnAddress returnAddress;
	static long counter = 0;
	long id = counter++;

	public String toString() {
		return "Mail " + id;
	}

	public String details() {
		return toString() + ", General Delivery: " + generalDelivery + ", Address Scanability: " + scannability
				+ ", Address Readability: " + readability + ", Address Address: " + address + ", Forward: " + forward
				+ ", Return address: " + returnAddress;
	}

	// Generate test Mail:
	public static Mail randomMail() {
		Mail m = new Mail();
		m.generalDelivery = Enums.random(GeneralDelivery.class);
		m.scannability = Enums.random(Scannability.class);
		m.readability = Enums.random(Readability.class);
		m.address = Enums.random(Address.class);
		m.forward = Enums.random(Forward.class);
		m.returnAddress = Enums.random(ReturnAddress.class);
		return m;
	}

	public static Iterable<Mail> generator(final int count) {
		return new Iterable<Mail>() {
			int n = count;

			public Iterator<Mail> iterator() {
				return new Iterator<Mail>() {
					public boolean hasNext() {
						return n-- > 0;
					}

					public Mail next() {
						return randomMail();
					}

					public void remove() { // Not implemented
						throw new UnsupportedOperationException();
					}
				};
			}
		};
	}
}

public class PostOffice {
	enum MailHandler {
		FORWARD_STEP {
			boolean handle(Mail m) {
				switch (m.forward) {
				case NO:
					return false;
				default:
					switch (m.address) {
					case INCORRECT:
						return false;
					default:
						System.out.println("Forward " + m + " normally");
						return true;
					}
				}
			}
		},
		GENERAL_DELIVERY {
			boolean handle(Mail m) {
				switch (m.generalDelivery) {
				case YES:
					print("Using general delivery for " + m);
					return true;
				default:
					return false;
				}
			}
		},
		MACHINE_SCAN {
			boolean handle(Mail m) {
				switch (m.scannability) {
				case UNSCANNABLE:
					return false;
				default:
					switch (m.address) {
					case INCORRECT:
						return false;
					default:
						print("Delivering " + m + " automatically");
						return true;
					}
				}
			}
		},
		VISUAL_INSPECTION {
			boolean handle(Mail m) {
				switch (m.readability) {
				case ILLEGIBLE:
					return false;
				default:
					switch (m.address) {
					case INCORRECT:
						return false;
					default:
						print("Delivering " + m + " normally");
						return true;
					}
				}
			}
		},
		RETURN_TO_SENDER {
			boolean handle(Mail m) {
				switch (m.returnAddress) {
				case MISSING:
					return false;
				default:
					print("Returning " + m + " to sender");
					return true;
				}
			}
		};
		abstract boolean handle(Mail m);
	}

	static void handle(Mail m) {
		for (MailHandler handler : MailHandler.values())
			if (handler.handle(m))
				return;
		print(m + " is a dead letter");
	}

	public static void main(String[] args) {
		for (Mail mail : Mail.generator(10)) {
			print(mail.details());
			handle(mail);
			print("*****");
		}
	}
} /*
	Mail 0, General Delivery: NO2, Address Scanability: UNSCANNABLE, Address Readability: YES3, Address Address: OK1, Forward: YES, Return address: OK5
	Forward Mail 0 normally
	*****
	Mail 1, General Delivery: NO4, Address Scanability: UNSCANNABLE, Address Readability: YES2, Address Address: INCORRECT, Forward: YES, Return address: MISSING
	Mail 1 is a dead letter
	*****
	Mail 2, General Delivery: NO3, Address Scanability: YES4, Address Readability: YES4, Address Address: OK3, Forward: NO, Return address: OK1
	Delivering Mail 2 automatically
	*****
	Mail 3, General Delivery: NO2, Address Scanability: YES3, Address Readability: YES1, Address Address: OK4, Forward: NO, Return address: MISSING
	Delivering Mail 3 automatically
	*****
	Mail 4, General Delivery: NO2, Address Scanability: YES3, Address Readability: YES1, Address Address: OK5, Forward: YES, Return address: OK2
	Forward Mail 4 normally
	*****
	Mail 5, General Delivery: YES, Address Scanability: YES4, Address Readability: ILLEGIBLE, Address Address: OK4, Forward: YES, Return address: MISSING
	Forward Mail 5 normally
	*****
	Mail 6, General Delivery: NO1, Address Scanability: YES4, Address Readability: YES4, Address Address: OK6, Forward: YES, Return address: OK5
	Forward Mail 6 normally
	*****
	Mail 7, General Delivery: YES, Address Scanability: YES2, Address Readability: YES1, Address Address: INCORRECT, Forward: NO, Return address: OK2
	Using general delivery for Mail 7
	*****
	Mail 8, General Delivery: NO4, Address Scanability: YES1, Address Readability: YES2, Address Address: INCORRECT, Forward: NO, Return address: OK5
	Returning Mail 8 to sender
	*****
	Mail 9, General Delivery: NO1, Address Scanability: YES4, Address Readability: YES1, Address Address: OK5, Forward: YES, Return address: OK1
	Forward Mail 9 normally
	*****
	 */// :~
