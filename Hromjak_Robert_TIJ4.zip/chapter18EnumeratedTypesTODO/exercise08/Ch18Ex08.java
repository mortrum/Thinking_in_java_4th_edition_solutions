package exercise08;

public class Ch18Ex08 {
	/**
	 * Exercise 8: (6) Modify PostOffice.java so it has the ability to forward mail.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

	}
}
// go to PostOffice