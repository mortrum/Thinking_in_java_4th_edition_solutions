package exercise05and06;

import java.util.Arrays;
import java.util.Random;

enum Letters {
	VOWEL('a', 'e', 'i', 'o', 'u') {
		public String toString() {
			return "vowel";
		}
	},
	SOMETIMES_A_VOWEL('w', 'y') {
		public String toString() {
			return "sometimes a vowel";
		}
	},
	CONSONANT('b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'x', 'z') {
		public String toString() {
			return "consonant";
		}
	};
	Character[] letters;

	Letters(Character... letters) {
		this.letters = letters;
	}

	public static Letters typeOfLetter(Character c) {
		if ((Arrays.asList(CONSONANT.letters)).contains(c)) {
			return CONSONANT;
		} else if ((Arrays.asList(VOWEL.letters)).contains(c)) {
			return VOWEL;
		} else {
			return SOMETIMES_A_VOWEL;
		}
	}
}

public class Ch18Ex05 {

	/**
	 * Exercise 5: (4) Modify control/VowelsAndConsonants.java so that it uses three
	 * enum types: VOWEL, SOMETIMES_A_VOWEL, and CONSONANT. The enum constructor
	 * should take the various letters that describe that particular category. Hint:
	 * Use varargs, and remember that varargs automatically creates an array for
	 * you.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Random rand = new Random(47);
		for (int i = 0; i < 10; i++) {
			int c = rand.nextInt(26) + 'a';
			System.out.println((char) c + ", " + c + ": " + Letters.typeOfLetter((char) c));
		}
	}
}
/*
 * y, 121: sometimes a vowel
n, 110: consonant
z, 122: consonant
b, 98: consonant
r, 114: consonant
n, 110: consonant
y, 121: sometimes a vowel
g, 103: consonant
c, 99: consonant
f, 102: consonant
*/
