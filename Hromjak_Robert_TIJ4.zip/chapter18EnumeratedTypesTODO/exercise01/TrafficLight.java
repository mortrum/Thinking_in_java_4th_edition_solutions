package exercise01;

import static exercise01helper.Signal.GREEN;
import static exercise01helper.Signal.RED;
import static exercise01helper.Signal.YELLOW;
import static net.mindview.util.Print.print;

import exercise01helper.Signal;

public class TrafficLight {
	Signal color = RED;

	public void change() {
		switch (color) {
		// Note that you don't have to say Signal.RED
		// in the case statement:
		case RED:
			color = GREEN;
			break;
		case GREEN:
			color = YELLOW;
			break;
		case YELLOW:
			color = RED;
			break;
		}
	}

	public String toString() {
		return "The traffic light is " + color;
	}

	/**
	 * Exercise 1: (2) Use a static import to modify TrafficLight.java so you don�t
	 * have to qualify the enum instances.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		TrafficLight t = new TrafficLight();
		for (int i = 0; i < 7; i++) {
			print(t);
			t.change();
		}
	}
}
/*
The traffic light is RED
The traffic light is GREEN
The traffic light is YELLOW
The traffic light is RED
The traffic light is GREEN
The traffic light is YELLOW
The traffic light is RED
*/