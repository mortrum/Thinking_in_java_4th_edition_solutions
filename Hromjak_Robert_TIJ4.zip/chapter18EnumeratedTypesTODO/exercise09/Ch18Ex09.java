package exercise09;

public class Ch18Ex09 {

	/**
	 * Exercise 9: (5) Modify class PostOffice so that it uses an EnumMap. Project:2
	 * Specialized languages like Prolog use backward chaining in order to solve
	 * problems like this. Using PostOffice.java for inspiration, research such
	 * languages and develop a program that allows new "rules" to be easily added to
	 * the system.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		for (Mail mail : Mail.generator(10)) {
			System.out.println(mail.details());
			PostOffice.handle(mail);
			System.out.println("*****");
		}
	}
}
/*
Mail 0, General Delivery: NO2, Address Scanability: UNSCANNABLE, Address Readability: YES3, Address Address: OK1, Forward: YES, Forward Address: OK5, Return address: OK4
Delivering Mail 0 normally
*****
Mail 1, General Delivery: NO2, Address Scanability: YES2, Address Readability: YES2, Address Address: OK2, Forward: NO, Forward Address: OK3, Return address: OK1
Delivering Mail 1 automatically
*****
Mail 2, General Delivery: NO5, Address Scanability: YES3, Address Readability: YES3, Address Address: OK5, Forward: NO, Forward Address: OK4, Return address: OK4
Delivering Mail 2 automatically
*****
Mail 3, General Delivery: YES, Address Scanability: YES1, Address Readability: YES2, Address Address: INCORRECT, Forward: YES, Forward Address: OK2, Return address: OK1
Using general delivery for Mail 3
*****
Mail 4, General Delivery: NO4, Address Scanability: YES2, Address Readability: YES4, Address Address: OK3, Forward: NO, Forward Address: INCORRECT, Return address: OK4
Delivering Mail 4 automatically
*****
Mail 5, General Delivery: YES, Address Scanability: YES3, Address Readability: YES4, Address Address: OK2, Forward: NO, Forward Address: OK3, Return address: OK5
Using general delivery for Mail 5
*****
Mail 6, General Delivery: YES, Address Scanability: YES2, Address Readability: YES1, Address Address: INCORRECT, Forward: NO, Forward Address: OK2, Return address: OK4
Using general delivery for Mail 6
*****
Mail 7, General Delivery: NO4, Address Scanability: YES2, Address Readability: YES3, Address Address: OK4, Forward: NO, Forward Address: OK1, Return address: OK2
Delivering Mail 7 automatically
*****
Mail 8, General Delivery: YES, Address Scanability: YES2, Address Readability: YES1, Address Address: OK5, Forward: NO, Forward Address: OK2, Return address: MISSING
Using general delivery for Mail 8
*****
Mail 9, General Delivery: NO5, Address Scanability: YES4, Address Readability: YES2, Address Address: OK2, Forward: NO, Forward Address: OK1, Return address: OK3
Delivering Mail 9 automatically
*****
*/