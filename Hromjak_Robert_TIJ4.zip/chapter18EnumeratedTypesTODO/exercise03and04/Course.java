//: enumerated/menu/Course.java
package exercise03and04;

import net.mindview.util.Enums;

//Exercise 3: (1) Add a new Course to Course.java and demonstrate that it works in
//Meal.java. 
public enum Course {
	APPETIZER(Food.Appetizer.class),
	MAINCOURSE(Food.MainCourse.class), 
	DESSERT(Food.Dessert.class),
	SOUP(Food.Soup.class),
	COFFEE(Food.Coffee.class);
	
	private Food[] values;

	private Course(Class<? extends Food> kind) {
		values = kind.getEnumConstants();
	}

	public Food randomSelection() {
		return Enums.random(values);
	}
} /// :~
