//: enumerated/menu/TypeOfFood.java
package exercise03and04;
import static exercise03and04.Food.*;

public class TypeOfFood {
  public static void main(String[] args) {
    Food food = Appetizer.SALAD;
    food = MainCourse.LASAGNE;
    food = Dessert.GELATO;
    food = Coffee.CAPPUCCINO;
    food = Soup.SOUP_1;
  }
} ///:~
