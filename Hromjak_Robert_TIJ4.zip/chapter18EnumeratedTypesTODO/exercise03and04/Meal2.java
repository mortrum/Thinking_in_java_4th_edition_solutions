//: enumerated/menu/Meal2.java
package exercise03and04;

import net.mindview.util.*;

public enum Meal2 {
	APPETIZER(Food.Appetizer.class), MAINCOURSE(Food.MainCourse.class), DESSERT(Food.Dessert.class),
	COFFEE(Food.Coffee.class), CNACK(Food.Snack.class);
	private Food[] values;

	private Meal2(Class<? extends Food> kind) {
		values = kind.getEnumConstants();
	}

	public interface Food {
		enum Appetizer implements Food {
			SALAD, SOUP, SPRING_ROLLS;
		}

		enum MainCourse implements Food {
			LASAGNE, BURRITO, PAD_THAI, LENTILS, HUMMOUS, VINDALOO;
		}

		enum Dessert implements Food {
			TIRAMISU, GELATO, BLACK_FOREST_CAKE, FRUIT, CREME_CARAMEL;
		}

		enum Coffee implements Food {
			BLACK_COFFEE, DECAF_COFFEE, ESPRESSO, LATTE, CAPPUCCINO, TEA, HERB_TEA;
		}

		enum Snack implements Food {
			SNACK_1, SNACK_2, SNACK_3;
		}
	}

	public Food randomSelection() {
		return Enums.random(values);
	}

	/**
	 * Exercise 3: (1) Add a new Course to Course.java and demonstrate that it works
	 * in Meal.java. Exercise 4: (1) Repeat the above exercise for Meal2.java.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		for (int i = 0; i < 5; i++) {
			for (Meal2 meal : Meal2.values()) {
				Food food = meal.randomSelection();
				System.out.println(food);
			}
			System.out.println("---");
		}
	}
} 
/*SPRING_ROLLS
VINDALOO
FRUIT
DECAF_COFFEE
SNACK_2
---
SPRING_ROLLS
HUMMOUS
TIRAMISU
TEA
SNACK_2
---
SALAD
LASAGNE
GELATO
DECAF_COFFEE
SNACK_3
---
SOUP
HUMMOUS
GELATO
BLACK_COFFEE
SNACK_2
---
SOUP
LASAGNE
GELATO
BLACK_COFFEE
SNACK_3
---*/

