package exercise23;


public class Ch06Ex23 {

	static {
        System.out.println("This code executes only first time class is loaded!");
        }
	
	/**
	 * Exercise 23: (2) Prove that class loading takes place only once. Prove that
	 * loading may be caused by either the creation of the first instance of that
	 * class or by the access of a static member. page 190
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("MAIN START");
		Ch06Ex23 test = new Ch06Ex23();
		Ch06Ex23 test2 = new Ch06Ex23();
	}
}
/*
This code executes only first time class is loaded!
MAIN START
*/