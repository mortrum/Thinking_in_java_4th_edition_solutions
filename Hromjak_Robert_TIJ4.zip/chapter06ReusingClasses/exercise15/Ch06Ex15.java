package exercise15;

import exercise15helper.Test;

class Derived extends Test {
	void derivedPrintProtected() {
		printProtect();
	}
}

public class Ch06Ex15 {

	/**
	 * Exercise 15: (2) Create a class inside a package. Your class should contain a
	 * protected method. Outside of the package, try to call the protected method
	 * and explain the results. Now inherit from your class and call the protected
	 * method from inside a method of your derived class.
	 * 
	 * @param args
	 * @return printing protected method
	 */
	public static void main(String[] args) {
		Derived derived = new Derived();
		derived.derivedPrintProtected();
		Test test = new Test();
		// test.pintProtected();//not working because method is protected
	}
}
