package exercise10;

class Component1 {
	public Component1(int i) {
		System.out.println("Component1 non-default constructor");
	}
}

class Component2 {
	public Component2(int i) {
		System.out.println("Component2 non-default constructor");
	}
}

class Component3 {
	public Component3(int t) {
		System.out.println("Component3 non-default constructor");
	}
}

class Root {
	Component1 component1 = new Component1(1);
	Component2 component2 = new Component2(2);
	Component3 component3 = new Component3(3);

	Root(int i) {
		super();
		System.out.println("Root class");
	}
}

class Stem extends Root {
	Component1 component1 = new Component1(1);
	Component2 component2 = new Component2(2);
	Component3 component3 = new Component3(3);

	Stem(int i) {
		super(i);
		System.out.println("Stem class");
	}
}

public class Ch06Ex10 {

	/**
	 * Exercise 10: (1) Modify the previous exercise so that each class only has
	 * non-default constructors.
	 * 
	 * @param args
	 * @return Root class Root class Stem class
	 * 
	 */
	public static void main(String[] args) {
		Root root = new Root(1);
		Stem stem = new Stem(2);

	}
}

/*
 * Output: Component1 non-default constructor Component2 non-default constructor
 * Component3 non-default constructor Root class Component1 non-default
 * constructor Component2 non-default constructor Component3 non-default
 * constructor Root class Component1 non-default constructor Component2
 * non-default constructor Component3 non-default constructor Stem class
 */
