package exercise06;

class Game {
	Game(int i) {
		System.out.println("Game constructor");
	}
}

class BoardGame extends Game {
	BoardGame(int i) {
		//super(); //he constructor Game() is undefined
		super(i);
		System.out.println("BoardGame constructor");
	}
}

class Chess extends BoardGame {
	Chess() {
		super(11);
		System.out.println("Chess constructor");
	}
}

public class Ch06Ex06 {

	/**
	 * Exercise 6: (1) Using Chess.java, prove the statements in the previous
	 * paragraph.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Chess x = new Chess();
	}
}
/*
Output:
Game constructor
BoardGame constructor
Chess constructor
*/