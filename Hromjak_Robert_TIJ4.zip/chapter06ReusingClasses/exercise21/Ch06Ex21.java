package exercise21;

class A {
	final void foo() {

	}
}

class B extends A {

	/*
	 * void foo() {
	 * 
	 * }
	 */
}

public class Ch06Ex21 {

	/**
	 * Exercise 21: (1) Create a class with a final method. Inherit from that class
	 * and attempt to overwrite that method.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

	}

}
