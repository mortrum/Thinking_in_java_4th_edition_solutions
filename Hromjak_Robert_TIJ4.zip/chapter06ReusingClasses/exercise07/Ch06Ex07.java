package exercise07;

class A {

	public A(int i) {
		System.out.println("create A");
	}
}

class B {
	public B(int i) {
		System.out.println("create B");
	}
}

class C extends A {
	B b;

	public C(int i) {
		super(i);
		this.b = new B(i);
	}
}

public class Ch06Ex07 {

	/**
	 * Exercise 7: (1) Modify Exercise 5 so that A and B have constructors with
	 * arguments instead of default constructors. Write a constructor for C and
	 * perform all initialization within C�s constructor.
	 * 
	 * @param args
	 * @return create 
	 * A create B
	 * 
	 */
	public static void main(String[] args) {
		C c = new C(11);
	}
}
