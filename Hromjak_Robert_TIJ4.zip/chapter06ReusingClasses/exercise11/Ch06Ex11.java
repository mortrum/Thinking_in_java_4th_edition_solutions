package exercise11;

class Cleanser {
	private String s = "Cleanser";

	public void append(String a) {
		s += a;
	}

	public void dilute() {
		append(" dilute()");
	}

	public void apply() {
		append(" apply()");
	}

	public void scrub() {
		append(" scrub()");
	}

	public String toString() {
		return s;
	}
}

class Detergent extends Cleanser {
	private String name;
	private Cleanser cleanser = new Cleanser();

	public Detergent(String name) {
		this.name = name;
	}

	public void dilute() {
		cleanser.dilute();
	}

	public void apply() {
		cleanser.apply();
	}

	public void scrub() {
		cleanser.scrub();
	}

	public void append(String s) {
		cleanser.append(s);
	}

	@Override
	public String toString() {
		return "Detergent [name=" + name + ", cleanser=" + cleanser + "]";
	}

}

public class Ch06Ex11 {

	/**
	 * Exercise 11: (3) Modify Detergent.java so that it uses delegation.
	 * 
	 * @param args
	 * @return Detergent [name=fairy, cleanser=Cleanser dilute() scrub() apply()
	 *         plusz]
	 */
	public static void main(String[] args) {
		Detergent x = new Detergent("fairy");
		x.dilute();
		x.scrub();
		x.apply();
		x.append(" plusz");

		System.out.println(x);
	}
}
