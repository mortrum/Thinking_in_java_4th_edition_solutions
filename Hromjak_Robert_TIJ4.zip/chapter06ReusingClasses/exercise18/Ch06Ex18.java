package exercise18;

class Test {
	final int a = 10;
	static final int b = 20;
}

public class Ch06Ex18 {

	/**
	 * Exercise 18: (2) Create a class with a static final field and a final field
	 * and demonstrate the difference between the two.
	 * 
	 * @param args
	 * @return 20 10
	 * 
	 */
	public static void main(String[] args) {
		System.out.println(Test.b);
		// System.out.println(Test.a);//Cannot make a static reference to the non-static
		// field Test.a

		Test test = new Test();
		System.out.println(test.a);
	}
}
