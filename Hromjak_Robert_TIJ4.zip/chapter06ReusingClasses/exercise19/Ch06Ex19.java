package exercise19;

class A {
	int a;

	@Override
	public String toString() {
		return "A [a=" + a + "]";
	}
}

class Test {
	final A a;

	public Test() {
		this.a = new A();
	}

	public Test(A a) {
		this.a = a;
	}

	/*
	 * void change() { //cannot be changed final.
	 *
	 * a = new A(); }
	 */

}

public class Ch06Ex19 {

	/**
	 * Exercise 19: (2) Create a class with a blank final reference to an object.
	 * Perform the initialization of the blank final inside all constructors.
	 * Demonstrate the guarantee that the final must be initialized before use, and
	 * that it cannot be changed once initialized.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		Test test = new Test(new A());
		Test test2 = new Test();
		/*
		 * try{ test2.a = new A(); }catch(Exception e) { System.err.println("error!");
		 * //The final field Test.a cannot be assigned }
		 */

		System.out.println(test.a);

	}
}
