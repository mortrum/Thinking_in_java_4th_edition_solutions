package exercise01;

class Simple {

	@Override
	public String toString() {
		return "Simple constructed";
	}
}

class Second {
	Simple simple;

	@Override
	public String toString() {
		if (simple == null) {
			simple = new Simple();
		}
		return "Second: " + simple;
	}
}

public class Ch06Ex01 {

	/**
	 * Exercise 1: (2) Create a simple class. Inside a second class, define a
	 * reference to an object of the first class. Use lazy initialization to
	 * instantiate this object.
	 * 
	 * @param args
	 * @return Second: Simple constructed
	 */
	public static void main(String[] args) {
		Second second = new Second();
		System.out.println(second);
	}
}
