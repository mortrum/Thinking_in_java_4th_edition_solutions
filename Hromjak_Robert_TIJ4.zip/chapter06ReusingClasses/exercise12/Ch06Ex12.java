package exercise12;

class Component1 {
	public Component1() {
		System.out.println("Component1 constructor");
	}
	
	void dispose() {
		System.out.println("Component1 dispose");
	}
}

class Component2 {
	public Component2() {
		System.out.println("Component2 constructor");
	}
	
	void dispose() {
		System.out.println("Component2 dispose");
	}
}

class Component3 {
	public Component3() {
		System.out.println("Component3 constructor");
	}
	
	void dispose() {
		System.out.println("Component3 dispose");
	}
}

class Root {
	Component1 component1 = new Component1();
	Component2 component2 = new Component2();
	Component3 component3 = new Component3();

	Root() {
		System.out.println("Root class");
	}
	
	void dispose() {
		System.out.println("Root dispose 2");
	}
}

class Stem extends Root {
	Component1 component1 = new Component1();
	Component2 component2 = new Component2();
	Component3 component3 = new Component3();

	Stem() {
		super();
		System.out.println("Stem class");
	}
	
	void dispose() {
		System.out.println("Root dispose");
		super.dispose();
	}
}

public class Ch06Ex12 {

	/**
	 * Exercise 12: (3) Add a proper hierarchy of dispose( ) methods to all the
	 * classes in Exercise 9.
	 * 
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		Root root = new Root();
		Stem stem = new Stem();
		stem.dispose();

	}
}

/*
Output:
Component1 constructor
Component2 constructor
Component3 constructor
Root class
Component1 constructor
Component2 constructor
Component3 constructor
Root class
Component1 constructor
Component2 constructor
Component3 constructor
Stem class
Root dispose
Root dispose 2
*/