package exercise02;

class Detergent {
	void scrub() {
		System.out.println("scrubbing");
	}
}

class NewClass extends Detergent {

	@Override
	void scrub() {
		System.out.println("new class scrubbing");
	}

	void sterilize() {
		System.out.println("sterilize");
	}
}

public class Ch06Ex02 {

	/**
	 * Exercise 2: (2) Inherit a new class from class Detergent. Override scrub( )
	 * and add a new method called sterilize( ).
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		NewClass class1 = new NewClass();
		class1.scrub();
		class1.sterilize();
	}
}
/*
 * Output:new
 * 
 * class scrubbing 
 * sterilize
 */