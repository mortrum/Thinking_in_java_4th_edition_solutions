package exercise17;

class Amphibian {
	void walk() {
		System.out.println("waliking Amphibian");
	}
}

class Frog extends Amphibian {
	void walk() {
		System.out.println("frog is walking");
	}
}

public class Ch06Ex17 {

	/**
	 * Exercise 17: (1) Modify Exercise 16 so that Frog overrides the method
	 * definitions from the base class (provides new definitions using the same
	 * method signatures). Note what happens in main( ).
	 * 
	 * @param args
	 * @return frog is walking
	 * 
	 */
	public static void main(String[] args) {
		Amphibian amphibian = new Frog();
		amphibian.walk(); // �upcasting�
	}
}
