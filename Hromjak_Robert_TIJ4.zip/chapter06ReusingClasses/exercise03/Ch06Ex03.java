package exercise03;

class Art {
	Art() {
		System.out.println("Art constructor");
	}
}

class Drawing extends Art {
	Drawing() {
		System.out.println("Drawing constructor");
	}
}

class Cartoon extends Drawing {

}

public class Ch06Ex03 {

	/**
	 * You can see that the construction happens from the base �outward,� so the
	 * base class is initialized before the derived-class constructors can access
	 * it. Even if you don�t create a constructor for Cartoon( ), the compiler will
	 * synthesize a default constructor for you that calls the base class
	 * constructor.
	 * 
	 * Exercise 3: (2) Prove the previous sentence.
	 * 
	 * @param args
	 * @return Art constructor 
	 * Drawing constructor
	 * 
	 */
	public static void main(String[] args) {
		Cartoon cartoon = new Cartoon();
	}
}
