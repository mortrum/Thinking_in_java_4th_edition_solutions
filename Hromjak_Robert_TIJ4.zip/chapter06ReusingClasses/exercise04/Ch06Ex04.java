package exercise04;

class Art {
	Art() {
		System.out.println("Art constructor will be called 1");
	}
}

class Drawing extends Art {
	Drawing() {
		System.out.println("Drawing constructor will be called 2");
	}
}

class Cartoon extends Drawing {
	public Cartoon() {
		System.out.println("Cartoon constructor will be called 3");
	}
}

public class Ch06Ex04 {
	/**
	 * Exercise 4: (2) Prove that the base-class constructors are (a) always called
	 * and (b) called before derived-class constructors.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Cartoon cartoon = new Cartoon();
	}
}

/*
Output:
Art constructor will be called 1
Drawing constructor will be called 2
Cartoon constructor will be called 3
*/