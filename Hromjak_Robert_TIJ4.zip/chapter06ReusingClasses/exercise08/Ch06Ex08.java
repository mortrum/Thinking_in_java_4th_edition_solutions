package exercise08;

class Base {
	Base(int i) {
		System.out.println("creat non-default constructor");
	}
}

class Derived extends Base {

	Derived() {
		super(1);
		System.out.println("default derived");
	}

	Derived(int i) {
		super(i);
		System.out.println("non default derived");
	}

}

public class Ch06Ex08 {

	/**
	 * Exercise 8: (1) Create a base class with only a non-default constructor, and
	 * a derived class with both a default (no-arg) and non-default constructor. In
	 * the derived-class constructors, call the base-class constructor.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Derived derived = new Derived();
		Derived derived2 = new Derived(2);

	}

}
/*
Output:
creat non-default constructor
default derived
creat non-default constructor
non default derived
*/