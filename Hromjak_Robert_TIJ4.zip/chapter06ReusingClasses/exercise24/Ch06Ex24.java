package exercise24;

class Insect {
	private int i = 9;
	protected int j;

	Insect() {
		System.out.println("i = " + i + ", j = " + j);
		j = 39;
	}

	private static int x1 = printInit("static Insect.x1 initialized");

	static int printInit(String s) {
		System.out.println(s);
		return 47;
	}
}

class Beetle extends Insect {
	private int k = printInit("Beetle.k initialized");

	public Beetle() {
		System.out.println("k = " + k);
		System.out.println("j = " + j);
	}

	private static int x2 = printInit("static Beetle.x2 initialized");
}

class Specific extends Beetle{
	private int sp = printInit("Specific.sp initialized");
	
	public Specific() {
		System.out.println("sp = " + sp);
		System.out.println("j = " + j);
	}
	
	private static int x2 = printInit("static Specific.x2 initialized");
}

public class Ch06Ex24 {

	/**
	 * Exercise 24: (2) In Beetle.java, inherit a specific type of beetle from class
	 * Beetle, following the same format as the existing classes. Trace and explain
	 * the output.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Beetle constructor");
		Beetle b = new Beetle(); 
		Specific sp = new Specific();
	}
}

//first always static init
/*
Output:
Beetle constructor
static Insect.x1 initialized
static Beetle.x2 initialized
i = 9, j = 0
Beetle.k initialized
k = 47
j = 39
static Specific.x2 initialized
i = 9, j = 0
Beetle.k initialized
k = 47
j = 39
Specific.sp initialized
sp = 47
j = 39
*/
