package exercise15helper;

public class Test {
	protected void printProtect() {
		System.out.println("printing protected method");
	}
}
