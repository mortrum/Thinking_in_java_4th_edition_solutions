package exercise13;

class Plus {
	void foo(int i) {
		System.out.println(i);
	}

	void foo(int i, int j) {
		System.out.println(i + j);
	}

	void foo(int i, int j, int k) {
		System.out.println(i + j + k);
	}
}

class Derived extends Plus {
	void foo(int a, int b, int c, int d) {
		System.out.println(a + b + c + d);
	}
}

public class Ch06Ex14 {

	/**
	 * Exercise 13: (2) Create a class with a method that is overloaded three times.
	 * Inherit a new class, add a new overloading of the method, and show that all
	 * four methods are available in the derived class.
	 * 
	 * @param args
	 * @return 1 3 6 10
	 * 
	 */
	public static void main(String[] args) {
		Derived derived = new Derived();
		derived.foo(1);
		derived.foo(1, 2);
		derived.foo(1, 2, 3);
		derived.foo(1, 2, 3, 4);
	}
}
