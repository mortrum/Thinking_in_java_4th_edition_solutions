package exercise22;

final class A {

}

/*
 * class B extends A{
 * 
 * }
 */
public class Ch06Ex22 {

	/**
	 * Exercise 22: (1) Create a final class and attempt to inherit from it.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

	}
}
