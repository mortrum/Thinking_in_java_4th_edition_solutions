package exercise11;

import java.util.Arrays;

public class Ch12Ex11 {

	/*
	 * Exercise 11: (2) Apply the regular expression
	 * (?i)((^[aeiou])|(\s+[aeiou]))\w+?[aeiou]\b 
	 * 
	 * to
	 * 
	 * "Arline ate eight apples and one orange while Anita hadn�t any"
	 */
	public static void main(String[] args) {
		String line = "Arline ate eight apples and one orange while Anita hadn�t any";

		System.out.println(Arrays.toString(line.split("(?i)((^[aeiou])|(\\s+[aeiou]))\\w+?[aeiou]\\b")));
	}
}

/*
[, ,  eight apples and, ,  while,  hadn�t any]
*/