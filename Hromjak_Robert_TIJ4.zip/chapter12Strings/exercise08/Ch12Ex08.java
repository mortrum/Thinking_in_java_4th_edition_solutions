package exercise08;

import java.util.Arrays;

public class Ch12Ex08 {
	public static String knights =
			 "Then, when you have found the shrubbery, you must " +
			 "cut down the mightiest tree in the forest... " +
			 "with... a herring!"; 
	
	/**
	 * Exercise 8: (2) Split the string Splitting.knights on the words "the" or �you." 
	 * @param args
	 */
	public static void main(String[] args) {
		String regex = "the|you";
		
		System.out.println(Arrays.toString(knights.split(regex)));
	}
}
/*
 * [Then, when , have found , shrubbery, , must cut down , mightiest tree in , forest... with... a herring!]
 */