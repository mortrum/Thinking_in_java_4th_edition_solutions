package exercise16;

import java.io.File;
// A very simple version of the "grep" program.
// {Args: JGrep.java "\\b[Ssct]\\w+"}
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.mindview.util.TextFile;

public class JGrep {
	public static String regex;

	public static void searchForFiles(String directoryName) {
		File[] fileList = new File(directoryName).listFiles();
		for (File file : fileList) {
			if (file.isFile()) {
				String filePath = file.getPath();
				System.out.println(filePath + " : ");
				Pattern p = Pattern.compile(regex);
				int index = 0;
				Matcher m = p.matcher("");
				for (String line : new TextFile(filePath)) {
					m.reset(line);
					while (m.find())
						System.out.println(index++ + ": " + m.group() + ": " + m.start());
				}

			} else if (file.isDirectory()) {
				searchForFiles(file.getPath());
			}
			System.out.println();
		}
	}

	/**
	 * Exercise 16: (5) Modify JGrep.java to accept a directory name or a file name
	 * as argument (if a directory is provided, search should include all files in
	 * the directory). Hint: You can generate a list of file names with: File[]
	 * files = new File(".").listFiles();
	 * 
	 * @args JGrep.java "\b[sct]\w++" "Pattern.CASE_INSENSITIVE"
	 */
	public static void main(String[] args) throws Exception {
		if (args.length < 2) {
			System.out.println("Usage: java JGrep file/folder regex");
			System.exit(0);
		}
		regex = args[1];
		if (new File(args[0]).listFiles() == null) {
			System.out.println("No such file/directory: " + args[0]);
			System.exit(0);
		}
		System.out.println("Searching for files in " + args[0] + "...");
		System.out.println("Regular expression: " + regex);
		System.out.println("********************");
		System.out.println();
		searchForFiles(args[0]);

	}
} /*
	 * 0: simple: 10 1: the: 28 2: Ssct: 26 3: TextFile: 25 4: class: 7 5: static: 8
	 * 6: String: 15 7: static: 8 8: searchForFiles: 20 9: String: 35 10: String: 4
	 * 11: System: 4 12: compile: 24 13: String: 9 14: TextFile: 27 15: System: 6
	 * 16: start: 63 17: searchForFiles: 4 18: System: 3 19: to: 39 20: search: 45
	 * 21: should: 52 22: the: 4 23: can: 30 24: sct: 25 25: CASE_INSENSITIVE: 44
	 * 26: static: 8 27: String: 25 28: throws: 40 29: System: 3 30: System: 3 31:
	 * System: 3 32: such: 26 33: System: 3 34: System: 2 35: Searching: 22 36:
	 * System: 2 37: System: 2 38: System: 2 39: searchForFiles: 2 40: simple: 7 41:
	 * the: 21 42: Ssct: 32 43: class: 44 44: to: 56 45: CASE_INSENSITIVE: 4 46:
	 * sct: 28 47: CASE_INSENSITIVE: 39 48: throws: 63 49: static: 4 50: String: 18
	 * 51: throws: 33 52: System: 48 53: System: 62 54: CANON_EQ: 4 55: CANON_EQ: 21
	 * 56: CASE_INSENSITIVE: 38 57: CASE_INSENSITIVE: 63 58: COMMENTS: 11 59:
	 * COMMENTS: 28 60: compile: 45 61: String: 61 62: TextFile: 4 63: System: 21
	 * 64: start: 35 65: simple: 49 66: the: 63 67: class: 75 68: to: 11 69: sct: 22
	 * 70: throws: 34 71: static: 49 72: throws: 63 73: compile: 4 74: through: 20
	 * 75: the: 36 76: the: 48 77: start: 60 78: strings: 73 79: simple: 11 80: the:
	 * 26 81: class: 38 82: static: 52 83: throws: 66 84: compile: 4 85: through: 20
	 * 86: the: 36 87: the: 48 88: start: 60
	 * 
	 * 
	 * 
	 */// :~
