package exercise10;

import java.util.Arrays;

public class Ch12Ex10 {

	/**
	 * Exercise 10: (2) For the phrase "Java now has regular expressions" evaluate
	 * whether the following expressions will find a match: 
	 * ^Java 
	 * \Breg.*
	 * n.w\s+h(a|i)s
	 * s?
	 * s*
	 * s+ 
	 * s{4} 
	 * S{1}. 
	 * s{0,3}
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		String line = "Java now has regular expressions";
		
		System.out.println(Arrays.toString(line.split("^Java")));
		System.out.println(Arrays.toString(line.split("\\Breg.*")));
		System.out.println(Arrays.toString(line.split("n.w\\s+h(a|i)s")));
		System.out.println(Arrays.toString(line.split("s?")));
		System.out.println(Arrays.toString(line.split("s*")));
		System.out.println(Arrays.toString(line.split("S{1}.")));
		System.out.println(Arrays.toString(line.split("s{0,3}")));
		
		
	}
}

/*
[,  now has regular expressions]
[Java now has regular expressions]
[Java ,  regular expressions]
[J, a, v, a,  , n, o, w,  , h, a, ,  , r, e, g, u, l, a, r,  , e, x, p, r, e, , , i, o, n]
[J, a, v, a,  , n, o, w,  , h, a, ,  , r, e, g, u, l, a, r,  , e, x, p, r, e, , i, o, n]
[Java now has regular expressions]
[J, a, v, a,  , n, o, w,  , h, a, ,  , r, e, g, u, l, a, r,  , e, x, p, r, e, , i, o, n]
*/