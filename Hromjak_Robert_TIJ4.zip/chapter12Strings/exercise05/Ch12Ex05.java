package exercise05;

import java.util.*;

public class Ch12Ex05 {
	/**
	 * Exercise 5: (5) For each of the basic conversion types in the above table,
	 * write the most complex formatting expression possible. That is, use all the
	 * possible format specifiers available for that conversion type.
	 */
	public static void main(String[] args) {
		Formatter f = new Formatter(System.out);
		char u = 'a';
		System.out.println("u = �a�");
		f.format("s: %1$-15.15s\n", u);
		// f.format("d: %d\n", u);
		f.format("c: %1$-15c\n", u);
		f.format("b: %1$-15.5b\n", u);
		// f.format("f: %f\n", u);
		// f.format("e: %e\n", u);
		// f.format("x: %x\n", u);
		f.format("h: %1$-15.5h\n", u);
	}
}

/*
u = �a�
s: a              
c: a              
b: true           
h: 61             
*/