package exercise20;

import java.util.Scanner;

class Item {
	int i;
	long l;
	float f;
	double d;
	String s;

	public Item(String s) {
		super();
		Scanner sc = new Scanner(s);
		i = sc.nextInt();
		l = sc.nextLong();
		f = sc.nextFloat();
		d = sc.nextDouble();
		this.s = sc.next();
	}

	@Override
	public String toString() {
		return "Item [i=" + i + ", l=" + l + ", f=" + f + ", d=" + d + ", s=" + s + "]";
	}

	
}

public class Ch02Ey20 {

	/**
	 * Exercise 20: (2) Create a class that contains int, long, float and double and
	 * String fields. Create a constructor for this class that takes a single String
	 * argument, and scans that string into the various fields. Add a toString( )
	 * method and demonstrate that your class works correctly.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Item item = new Item("1 2 3 4 alma");
		
		System.out.println(item);
	}
}
/*
Item [i=1, l=2, f=3.0, d=4.0, s=alma]
*/