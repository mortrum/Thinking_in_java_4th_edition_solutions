package exercise01;

// Composition for code reuse.
/**
 * Exercise 1: (2) Analyze SprinklerSystem.toString( ) in
 * reusing/SprinklerSystem.java to discover whether writing the toString( ) with
 * an explicit StringBuilder will save any StringBuilder creations.
 */
class WaterSource {
	private String s;

	WaterSource() {
		System.out.println("WaterSource()");
		s = "Constructed";
	}

	public String toString() {
		return s;
	}
}

public class SprinklerSystem {
	private String valve1, valve2, valve3, valve4;
	private WaterSource source = new WaterSource();
	private int i;
	private float f;

	public String toString() {
		StringBuilder result = new StringBuilder("valve1 = ");
		result.append(valve1).append(" valve2 = ").append(valve1).append(" valve3 = ").append(valve3)
				.append(" valve4 = ").append(valve4).append("\ni = ").append(i).append(" f = ").append(f)
				.append(" source = ").append(source);
		return result.toString();
	}
	
	/**
	 * Exercise 1: (2) Analyze SprinklerSystem.toString( ) in
	 * reusing/SprinklerSystem.java to discover whether writing the toString( ) with
	 * an explicit StringBuilder will save any StringBuilder creations.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		SprinklerSystem sprinklers = new SprinklerSystem();
		System.out.println(sprinklers);
	}
} 
/*
WaterSource()
valve1 = null valve2 = null valve3 = null valve4 = null
i = 0 f = 0.0 source = Constructed
*/
