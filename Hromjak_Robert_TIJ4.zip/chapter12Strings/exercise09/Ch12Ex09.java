package exercise09;

public class Ch12Ex09 {

	public static String knights =
			 "Then, when you have found the shrubbery, you must " +
			 "cut down the mightiest tree in the forest... " +
			 "with... a herring!"; 
	
	/**
	 * Exercise 9: (4) Using the documentation for java.util.regex.Pattern as a
	 * resource, replace all the vowels in Splitting.knights with underscores.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		String regex = "a|o|u|e|i|A|O|U|E|I";
		
		String tokens[] = knights.split(regex);
		
		for (String string : tokens) {
			System.out.print(string + "_");
		}
	}
}

/*
Th_n, wh_n y__ h_v_ f__nd th_ shr_bb_ry, y__ m_st c_t d_wn th_ m_ght__st tr__ _n th_ f_r_st... w_th... _ h_rr_ng!_
*/