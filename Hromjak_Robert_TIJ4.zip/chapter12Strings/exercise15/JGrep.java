package exercise15;

// A very simple version of the "grep" program.
// {Args: JGrep.java "\\b[Ssct]\\w+"}
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.mindview.util.TextFile;

public class JGrep {

	/**
	 * Exercise 15: (5) Modify JGrep.java to accept flags as arguments (e.g.,
	 * Pattern.CASE_INSENSITIVE, Pattern.MULTILINE).
	 * 
	 * @param args JGrep.java "\b[sct]\w++" "Pattern.CASE_INSENSITIVE"
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		if (args.length < 2) {
			System.out.println("Usage: java JGrep file regex");
			System.exit(0);
		}

		int flag = 0;
		if (args[2].equals("Pattern.CANON_EQ"))
			flag = Pattern.CANON_EQ;
		else if (args[2].equals("Pattern.CASE_INSENSITIVE"))
			flag = Pattern.CASE_INSENSITIVE;
		else if (args[2].equals("Pattern.COMMENTS"))
			flag = Pattern.COMMENTS;
		else if (args[2].equals("Pattern.DOTALL"))
			flag = Pattern.DOTALL;
		else if (args[2].equals("Pattern.LITERAL"))
			flag = Pattern.LITERAL;
		else if (args[2].equals("Pattern.MULTILINE"))
			flag = Pattern.MULTILINE;
		else if (args[2].equals("Pattern.UNICODE_CASE"))
			flag = Pattern.UNICODE_CASE;
		else if (args[2].equals("Pattern.UNIX_LINES"))
			flag = Pattern.UNIX_LINES;

		Pattern p = Pattern.compile(args[1], flag);
		int index = 0;
		Matcher m = p.matcher("");
		for (String line : new TextFile(args[0])) {
			m.reset(line);
			while (m.find())
				System.out.println(index++ + ": " + m.group() + ": " + m.start());
		}

	}
} /*
	 * 0: simple: 10 1: the: 28 2: Ssct: 26 3: class: 7 4: to: 39 5:
	 * CASE_INSENSITIVE: 12 6: sct: 31 7: CASE_INSENSITIVE: 50 8: throws: 5 9:
	 * static: 8 10: String: 25 11: throws: 40 12: System: 3 13: System: 3 14:
	 * CANON_EQ: 30 15: CANON_EQ: 18 16: CASE_INSENSITIVE: 35 17: CASE_INSENSITIVE:
	 * 18 18: COMMENTS: 35 19: COMMENTS: 18 20: compile: 22 21: String: 9 22:
	 * TextFile: 27 23: System: 7 24: start: 29 25: simple: 7 26: the: 21 27: class:
	 * 32 28: to: 44 29: sct: 54 30: throws: 65 31: static: 4 32: throws: 17 33:
	 * compile: 31 34: through: 46 35: the: 62 36: the: 74 37: start: 8 38: strings:
	 * 22 39: simple: 38 40: the: 53 41: class: 65 42: static: 4 43: throws: 18 44:
	 * compile: 33 45: through: 48 46: the: 64 47: the: 76 48: start: 11
	 * 
	 * 
	 */// :~
