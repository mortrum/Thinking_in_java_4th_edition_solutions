package exercise12;

import java.util.HashSet;
import java.util.Set;

public class Groups {
	static public final String POEM = "Twas brillig, and the slithy toves\n" + "Did gyre and gimble in the wabe.\n"
			+ "All mimsy were the borogoves,\n" + "And the mome raths outgrabe.\n\n"
			+ "Beware the Jabberwock, my son,\n" + "The jaws that bite, the claws that catch.\n"
			+ "Beware the Jubjub bird, and shun\n" + "The frumious Bandersnatch.";

	/*
	 * Exercise 12: (5) Modify Groups.java to count all of the unique words that do
	 * not start with a capital letter
	 * 
	 * @return 9
	 */
	public static void main(String[] args) {

		String regex = " |,|\\.|\\r?\\n";
		String [] words = POEM.split(regex);

		Set<String> set = new HashSet<>();
		
		for (String word : words) {
			set.add(word);
		}
		set.remove("");
		
		//System.out.println(set);
		int count=0;
		for (String string : set) {
			if (Character.isUpperCase(string.charAt(0)))
				count++;
		}
		
		System.out.println("unique words: " + count);
	}
}
/*
unique words: 9
*/