package exercise06;

class Item {
	int i = 1;
	long l = 2;
	float f = 3;
	double d = 4;

	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		result.append(String.format("int: %d ", i));
		result.append(String.format("Long: %d ", l));
		result.append(String.format("float: %.2f ", f));
		result.append(String.format("double: %1$,.2f ", d));

		return result.toString();
	}

}

public class Ch12Ex06 {

	/**
	 * Exercise 6: (2) Create a class that contains int, long, float and double
	 * fields. Create a toString( ) method for this class that uses String.format(
	 * ), and demonstrate that your class works correctly.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Item item = new Item();
		System.out.println(item.toString());
	}
}

/*
int: 1 Long: 2 float: 3.00 double: 4.00 
*/