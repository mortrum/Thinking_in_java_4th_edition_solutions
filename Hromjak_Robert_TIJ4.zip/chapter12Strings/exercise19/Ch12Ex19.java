package exercise19;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.mindview.util.TextFile;

public class Ch12Ex19 {

	/**
	 * Exercise 17: (8) Write a program that reads a Java source-code file (you
	 * provide the file name on the command line) and displays all the comments.
	 * 
	 * @param args chapter12Strings\exercise19\Ch12ex19.java
	 */
	public static void main(String[] args) {

		if (args.length < 1) {
			System.out.println("Usage: java Ch13ex19 file");
			System.exit(0);
		}
		String s = TextFile.read(args[0]);
		int index = 1;
		Matcher m = Pattern.compile("class\\s+(([(\\S+)&&[^\\{]])+)").matcher(s);

		while (m.find()) {
			System.out.println(index++ + ". " + m.group());
			System.out.println();
		}
	}
}
/**
 * 1. class Ch12Ex19
 * 
 */