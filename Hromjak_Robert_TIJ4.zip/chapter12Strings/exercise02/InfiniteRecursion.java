package exercise02;

import java.util.*;

public class InfiniteRecursion {
	public String toString() {
		return " InfiniteRecursion address: " + super.toString() + "\n";
	}

	/**
	 * Exercise 2: (1) Repair InfiniteRecursion.java. 
	 * @param args
	 */
	public static void main(String[] args) {
		List<InfiniteRecursion> v = new ArrayList<InfiniteRecursion>();
		for (int i = 0; i < 10; i++)
			v.add(new InfiniteRecursion());
		System.out.println(v);
	}
}
/*
Output:
[ InfiniteRecursion address: exercise02.InfiniteRecursion@15db9742
,  InfiniteRecursion address: exercise02.InfiniteRecursion@6d06d69c
,  InfiniteRecursion address: exercise02.InfiniteRecursion@7852e922
,  InfiniteRecursion address: exercise02.InfiniteRecursion@4e25154f
,  InfiniteRecursion address: exercise02.InfiniteRecursion@70dea4e
,  InfiniteRecursion address: exercise02.InfiniteRecursion@5c647e05
,  InfiniteRecursion address: exercise02.InfiniteRecursion@33909752
,  InfiniteRecursion address: exercise02.InfiniteRecursion@55f96302
,  InfiniteRecursion address: exercise02.InfiniteRecursion@3d4eac69
,  InfiniteRecursion address: exercise02.InfiniteRecursion@42a57993
]
*/