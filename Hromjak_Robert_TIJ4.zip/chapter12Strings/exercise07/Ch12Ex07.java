package exercise07;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Ch12Ex07 {

	/**
	 * Exercise 7: (5) Using the documentation for java.util.regex.Pattern as a
	 * resource, write and test a regular expression that checks a sentence to see
	 * that it begins with a capital letter and ends with a period.
	 * 
	 * @param args
	 * @return Alma fa.xx.
	 */
	public static void main(String[] args) {
		String line = "Alma fa.xx.";
		String regex = "^[A-Z].*\\.";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(line);
		
		if (Pattern.matches(regex, line)) {
			System.out.println(line);
		}

	}
}
/*Output:
Alma fa.xx.
*/