package exercise09;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class Ch17Ex09 {

	/**
	 * Exercise 9: (1) Modify Exercise 8 to force all the lines in the LinkedList to
	 * uppercase and send the results to System.out.
	 * 
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		List<String> list = new LinkedList<String>();
		BufferedReader br = new BufferedReader(new FileReader("sample.txt"));
		String line;
		
		while ((line = br.readLine()) != null) {
			list.add(line.toUpperCase());
		}
		
		System.out.println(list);
	}
}
/*
[FIRST ROW, SECOND ROW, THIRD ROW, LAST ROW]
*/