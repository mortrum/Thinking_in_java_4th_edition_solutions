package exercise08;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class Ch17Ex08 {

	/**
	 * Exercise 8: (1) Modify Exercise 7 so that the name of the file you read is
	 * provided as a command-line argument.
	 * 
	 * @param args
	 * @throws IOException
	 * @args alma.txt
	 */
	public static void main(String[] args) throws IOException {
		List<String> list = new LinkedList<String>();
		
		String line;
		if (args.length == 0) {
			BufferedReader br = new BufferedReader(new FileReader("sample.txt"));
			while ((line = br.readLine()) != null) {
				list.add(line);
			}
		}
		else {
			BufferedReader br = new BufferedReader(new FileReader(args[0]));
			while ((line = br.readLine()) != null) {
				list.add(line);
			}
		}

		System.out.println(list);

	}
}

/*
[The free online random word generator tool allows you to create any number of random words you need for your project alma korte]
*/