package exercise12;

import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class Ch17Ex12 {

	/**
	 * Exercise 12: (3) Modify Exercise 8 to also open a text file so you can write
	 * text into it. Write the lines in the LinkedList, along with line numbers (do
	 * not attempt to use the "LineNumber" classes), out to the file.
	 * 
	 * @param args
	 * @throws IOException 
	 * @args output.txt
	 */
	public static void main(String[] args) throws IOException {
	List<String> list = new LinkedList<String>();
	list.add("first row");
	list.add("second row");
	list.add("bla bla row");
	list.add("bla bla end row");
	
	FileWriter writer = new FileWriter(args[0]); 
	for(String str: list) {
	  writer.write(str + System.lineSeparator());
	}
	writer.close();
	
	System.out.println("end");
	}
}
/*
	in output.txt:
	
	first row
	second row
	bla bla row
	bla bla end row
	
	in console:
	end

*/