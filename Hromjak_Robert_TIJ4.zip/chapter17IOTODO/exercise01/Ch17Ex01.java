package exercise01;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.util.Arrays;
import java.util.regex.Pattern;

class DirFilter implements FilenameFilter {
	private Pattern pattern;

	public DirFilter(String regex) {
		pattern = Pattern.compile(regex);
	}

	public boolean accept(File dir, String name) {
		return pattern.matcher(name).matches();
	}
}

public class Ch17Ex01 {

	/**
	 * Exercise 1: (3) Modify DirList.java (or one of its variants) so that the
	 * FilenameFilter opens and reads each file (using the
	 * net.mindview.util.TextFile utility) and accepts the file based on whether any
	 * of the trailing arguments on the command line exist in that file.
	 * 
	 * @param args
	 */

	public static void main(String[] args) {
		File path = new File(".");
		String[] list;
		final String p;
		if(args.length == 0){
            p=".*alma.*";
        }else{
            p=args[0];
        }

		list = path.list(new FilenameFilter() {
            private Pattern pattern = Pattern.compile(p);
            public boolean accept(File dir, String name) {
                boolean result=false;
                try{
                    BufferedReader br=new BufferedReader(new FileReader(new File(dir.getAbsolutePath()+"/"+name)));
                    while(true){
                        String line=br.readLine();
                        if(line==null){break;}
                        if(pattern.matcher(line).matches()){
                            result=true;
                        }
                    }
                }catch(Exception e){
                    System.out.println("Can not open file:  "+dir.getAbsolutePath()+name);
                }
                return result;
            }
        });

		
		Arrays.sort(list, String.CASE_INSENSITIVE_ORDER);
		for (String dirItem : list)
			System.out.println(dirItem);
	}
}

/*
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\..settings
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.bin
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.chapter01Object
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.chapter02Operators
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.chapter03ControllingEx
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.chapter04Initialization
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.chapter05AccessControl
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.chapter06ReusingClasses
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.chapter07Polymorphism
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.chapter08Interfaces
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.chapter09InnerClasses
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.chapter10HoldingYourObject
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.chapter11Exceptions
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.chapter12Strings
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.chapter13TypeInformation
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.chapter14GenericsTODO
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.chapter15Arrays
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.chapter16DeepTODO
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.chapter17I
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.chapter18EnumeratedTypesTODO
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.doc
Can not open file:  C:\Users\robert.hromjak\Documents\eclipse\exercises\.src
alma.txt
*/