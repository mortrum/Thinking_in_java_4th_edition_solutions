package exercise10;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class Ch17Ex10 {

	/**
	 * Exercise 10: (2) Modify Exercise 8 to take additional command-line arguments
	 * of words to find in the file. Print all lines in which any of the words
	 * match.
	 * 
	 * @param args
	 * @throws IOException
	 * @args first
	 */
	public static void main(String[] args) throws IOException {
		List<String> list = new LinkedList<String>();
		String line;
		if (args.length == 0)
			System.out.println("no args");
		else {
			BufferedReader br = new BufferedReader(new FileReader("sample.txt"));
			while ((line = br.readLine()) != null) {
				if(line.contains(args[0])) {
					list.add(line);
				}
			}
		}

		System.out.println(list);
	}
}
/*
[first row]
*/