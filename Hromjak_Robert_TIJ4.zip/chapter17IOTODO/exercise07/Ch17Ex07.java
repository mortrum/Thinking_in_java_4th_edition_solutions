package exercise07;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class Ch17Ex07 {

	/**
	 * Exercise 7: (2) Open a text file so that you can read the file one line at a
	 * time. Read each line as a String and place that String object into a
	 * LinkedList. Print all of the lines in the LinkedList in reverse order
	 * 
	 * @param args
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException, IOException {
		List<String> list = new LinkedList<String>();
		BufferedReader br = new BufferedReader(new FileReader("sample.txt"));
		String line;
		
		while ((line = br.readLine()) != null) {
			list.add(line);
		}
		
		System.out.println(list);

	}
}
/*
[first row, second row, third row, last row]
*/