package exercise12;
// Holds a sequence of Objects.

interface Selector {
	boolean end();

	Object current();

	void next();
}

public class Sequence {
	private Object[] items;
	private int next = 0;

	public Sequence(int size) {
		items = new Object[size];
	}

	public void add(Object x) {
		if (next < items.length)
			items[next++] = x;
		else
			throw new IndexOutOfBoundsException();
	}

	private class SequenceSelector implements Selector {
		private int i = 0;

		public boolean end() {
			return i == items.length;
		}

		public Object current() {
			return items[i];
		}

		public void next() {
			if (i < items.length)
				i++;
		}
	}

	public Selector selector() {
		return new SequenceSelector();
	}

	/**
	 * Exercise 12: (3) Modify innerclasses/Sequence.java so that it throws an
	 * appropriate exception if you try to put in too many elements.
	 * 
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		Sequence sequence = new Sequence(10);
		for (int i = 0; i < 10; i++)
			sequence.add(Integer.toString(i));
		Selector selector = sequence.selector();
		while (!selector.end()) {
			System.out.print(selector.current() + " ");
			selector.next();
		}
		// ! sequence.add("alma");//java.lang.IndexOutOfBoundsException
	}
} /*
	 * Output: 0 1 2 3 4 5 6 7 8 9
	 */// :~
