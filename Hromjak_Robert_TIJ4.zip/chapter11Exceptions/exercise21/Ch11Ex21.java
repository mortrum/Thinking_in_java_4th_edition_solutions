package exercise21;

class Base {
	public Base() throws Exception {
		System.out.println("I am Constructor of BaseClass!");
	}
}

class Derived extends Base {

	public Derived() throws Exception {
		try {

		} catch (Exception e) {
			// TODO: handle exception
		}
		// ! super();
		// TODO Auto-generated constructor stub
	}

}

public class Ch11Ex21 {
	/**
	 * Exercise 21: (2) Demonstrate that a derived-class constructor cannot catch
	 * exceptions thrown by its base-class constructor.
	 * 
	 * @param args
	 * @return I am Constructor of BaseClass!
	 * 
	 */
	public static void main(String[] args) {
		try {
			Derived derived = new Derived();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
