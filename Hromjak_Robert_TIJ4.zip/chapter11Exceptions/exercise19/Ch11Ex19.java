package exercise19;

class VeryImportantException extends Exception {
	public String toString() {
		return "A very important exception!";
	}
}

class HoHumException extends Exception {
	public String toString() {
		return "A trivial exception";
	}
}

class VeryTrivialExceprion extends Exception{
	public String toString() {
		return "A very trivial exception";
	}
}

class LostMessage {
	void f() throws VeryImportantException {
		throw new VeryImportantException();
	}

	void dispose() throws HoHumException {
		throw new HoHumException();
	}
	
	void veryTrivial() throws VeryTrivialExceprion{
		throw new VeryTrivialExceprion();
	}
}

public class Ch11Ex19 {

	/**
	 * Exercise 18: (3) Add a second level of exception loss to LostMessage.java so
	 * that the HoHumException is itself replaced by a third exception.
	 * 
	 * @param args
	 * @return  very trivial exception
	 */
	public static void main(String[] args) {
		try {
			LostMessage lm = new LostMessage();
			try {
				lm.f();
			} finally {
				try {
					lm.veryTrivial();
				} catch (VeryTrivialExceprion e) {
					System.out.println(e);
				}
				finally {
					try {
						lm.dispose();
					} catch (HoHumException e2) {
						System.out.println(e2);
					}
				}

			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
/*Output:
 * A very trivial exception
A trivial exception
A very important exception!
*/
