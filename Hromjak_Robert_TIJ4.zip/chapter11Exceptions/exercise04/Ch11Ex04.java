package exercise04;

class MyException extends Exception{
	private String s;

	public MyException(String s) {
		super();
		this.s = s;
	}
	
	public void printS() {
		System.out.println(s);
	}
}


public class Ch11Ex04 {

	/**
	 * Exercise 4: (2) Create your own exception class using the extends keyword.
	 * Write a constructor for this class that takes a String argument and stores it
	 * inside the object with a String reference. Write a method that displays the
	 * stored String. Create a try-catch clause to exercise your new exception.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			throw new MyException("apple");
		} catch (MyException e) {
			e.printS();
		}
	}
}
/*
apple
*/