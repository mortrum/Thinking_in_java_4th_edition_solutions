package exercise09;

class ExceptionA extends Exception {

}

class ExceptionB extends Exception {

}

class ExceptionC extends Exception {

}

class AllThreeException {
	void foo(int i) throws Exception {
		switch (i) {
		case 1:
			throw new ExceptionA();
		case 2:
			throw new ExceptionB();
		case 3:
			throw new ExceptionC();

		default:
			break;
		}
	}
}

public class Ch11Ex09 {

	/**
	 * Exercise 9: (2) Create three new types of exceptions. Write a class with a
	 * method that throws all three. In main( ), call the method but only use a
	 * single catch clause that will catch all three types of exceptions.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		AllThreeException allThreeException = new AllThreeException();
		for (int i = 1; i < 4; i++) {
			try {
				allThreeException.foo(i);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
/*
Output:
exercise09.ExceptionA
	at exercise09.AllThreeException.foo(Ch11Ex09.java:19)
	at exercise09.Ch11Ex09.main(Ch11Ex09.java:45)
exercise09.ExceptionB
	at exercise09.AllThreeException.foo(Ch11Ex09.java:21)
	at exercise09.Ch11Ex09.main(Ch11Ex09.java:45)
exercise09.ExceptionC
	at exercise09.AllThreeException.foo(Ch11Ex09.java:23)
	at exercise09.Ch11Ex09.main(Ch11Ex09.java:45)
	*/
