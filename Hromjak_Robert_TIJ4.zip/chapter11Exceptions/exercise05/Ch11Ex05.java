package exercise05;

public class Ch11Ex05 {

	/**
	 * Exercise 5: (3) Create your own resumption-like behavior using a while loop
	 * that repeats until an exception is no longer thrown.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		int tooBig = 10;
		while (true) {
			try {
				int[] array = { 1, 2, 3, 4, 5 };
				System.out.println("last element " + array[tooBig]);
				break;
			} catch (ArrayIndexOutOfBoundsException e) {
				System.out.println("not last element " + tooBig);
				tooBig--;
			}
		}

	}
}
/*
Output:
not last element 10
not last element 9
not last element 8
not last element 7
not last element 6
not last element 5
last element 5

*/