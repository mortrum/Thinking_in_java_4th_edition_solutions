package exercise14;

class Switch {
	private boolean state = false;

	public boolean read() {
		return state;
	}

	public void on() {
		if (state)
			throw new RuntimeException();
		state = true;
		net.mindview.util.Print.print(this);
	}

	public void off() {
		if (!state)
			throw new RuntimeException();
		state = false;
		net.mindview.util.Print.print(this);
	}

	public String toString() {
		return state ? "on" : "off";
	}
}

public class OnOffSwitch {
	private static Switch sw = new Switch();

	public static void f() throws OnOffException1, OnOffException2 {
	}

	/**
	 * Exercise 14: (2) Show that OnOffSwitch.java can fail by throwing a
	 * RuntimeException inside the try block.
	 * 
	 * @param args
	 * @throws OnOffException2
	 */
	public static void main(String[] args) throws OnOffException2 {
		try {
			sw.on();
			// !sw.on();
			// Code that can throw exceptions...
			f();
			sw.off();
		} catch (OnOffException1 e) {
			System.out.println("OnOffException1");
			sw.off();
		} catch (OnOffException2 e) {
			System.out.println("OnOffException2");
			sw.off();
		}
	}
} /*
	 * Output:on off
	 * 
	 */// :~