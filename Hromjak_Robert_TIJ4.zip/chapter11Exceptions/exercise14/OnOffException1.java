package exercise14;
public class OnOffException1 extends Exception {} ///:~
