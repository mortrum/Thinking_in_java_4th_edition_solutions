package exercise14;
public class OnOffException2 extends Exception {} ///:~
