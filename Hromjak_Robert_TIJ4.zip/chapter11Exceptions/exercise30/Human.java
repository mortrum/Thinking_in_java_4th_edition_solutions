package exercise30;

//Catching exception hierarchies.

class Annoyance extends RuntimeException {
}

class Sneeze extends Annoyance {
}

public class Human {
	public static void wrapException(int exceptionNum) {
		try {
			switch (exceptionNum) {
			case 1:
				throw new Annoyance();
			case 2:
				throw new Sneeze();
			default:
				return;
			}
		} catch (Sneeze e) {
			throw new RuntimeException(e);
		} catch (Annoyance e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Exercise 30: (2) Modify Human.java so that the exceptions inherit from
	 * RuntimeException. Modify main( ) so that the technique in
	 * TurnOffChecking.java is used to handle the different types of exceptions.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// Catch the exact type:
		for (int i : new int[] { 1, 2 }) {
			try {
				wrapException(i);
			} catch (RuntimeException e) {
				try {
					throw e.getCause();
				} catch (Sneeze s) {
					System.out.println("Caught Sneeze");
				} catch (Annoyance a) {
					System.out.println("Caught Annoyance");
				} catch (Throwable t) {
					System.out.println("Caught other Throwable!");
				}
			}
		}
	}
}
/*
Caught Annoyance
Caught Sneeze
*/