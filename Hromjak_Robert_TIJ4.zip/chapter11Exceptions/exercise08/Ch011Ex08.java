package exercise08;

class MyException extends Exception {
	private String s;

	public MyException(String s) {
		super();
		this.s = s;
	}

	public MyException() {
		
	}

	public void printS() {
		System.out.println(s);
	}
}

class TestException {
	void foo() throws MyException {
		throw new MyException();
	}
}

public class Ch011Ex08 {
	/*
	 * Exercise 8: (1) Write a class with a method that throws an exception of the
	 * type created in Exercise 4. Try compiling it without an exception
	 * specification to see what the compiler says. Add the appropriate exception
	 * specification. Try out your class and its exception inside a try-catch
	 * clause.
	 */
	public static void main(String[] args) {
		TestException testException = new TestException();
		try {
			testException.foo();
		} catch (MyException e) {
			e.printStackTrace();
		}
	}
}
/*
Output:
exercise08.MyException
		at exercise08.TestException.foo(Ch011Ex08.java:22)
		at exercise08.Ch011Ex08.main(Ch011Ex08.java:37)
*/