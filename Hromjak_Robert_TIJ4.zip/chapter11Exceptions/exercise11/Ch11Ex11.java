package exercise11;

class ExceptionA extends Exception {

}

class ExceptionB extends Exception {

}

class TwoMethods {
	void f() {
		try {
			g();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	void g() {
		try {
			throw new ExceptionA();
		} catch (ExceptionA e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

public class Ch11Ex11 {

	/**
	 * Exercise 11: (1) Repeat the previous exercise, but inside the catch clause,
	 * wrap g( )�s exception in a RuntimeException.
	 * 
	 * @param args
	 * @return
	 */
	public static void main(String[] args) {
		TwoMethods methods = new TwoMethods();
		methods.g();
		System.out.println("end");
	}
}
/*
exercise11.ExceptionA
end
	at exercise11.TwoMethods.g(Ch11Ex11.java:22)
	at exercise11.Ch11Ex11.main(Ch11Ex11.java:41)
 */