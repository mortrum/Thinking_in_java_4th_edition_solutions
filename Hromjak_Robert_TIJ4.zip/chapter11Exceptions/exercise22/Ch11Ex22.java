package exercise22;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

class FailingConstructor {
	static void notTheBestMethod(File file) {
		try {
			try {
				BufferedReader br = new BufferedReader(new FileReader(file));
				System.out.println(br);
			} finally {

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

public class Ch11Ex22 {

	/**
	 * Exercise 22: (2) Create a class called FailingConstructor with a constructor
	 * that might fail partway through the construction process and throw an
	 * exception. In main( ), write code that properly guards against this failure.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			FailingConstructor.notTheBestMethod(new File("alma.txt"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
/*
	java.io.BufferedReader@15db9742
*/