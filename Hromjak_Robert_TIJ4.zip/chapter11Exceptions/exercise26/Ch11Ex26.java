package exercise26;

import java.io.FileInputStream;

public class Ch11Ex26 {
	// Pass all exceptions to the console:
	/**
	 * Exercise 26: (1) Change the file name string in MainException.java to name a
	 * file that doesn�t exist. Run the program and note the result.
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// Open the file:
		FileInputStream file = new FileInputStream("alma3.txt");
		// Use the file ...
		// Close the file:
		file.close();
	}
}
/*
java.io.FileNotFoundException:
*/