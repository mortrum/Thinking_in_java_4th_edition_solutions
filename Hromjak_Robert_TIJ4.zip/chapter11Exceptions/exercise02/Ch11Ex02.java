package exercise02;

class Item {
	String s = null;

	void printS() {
		System.out.println(s);
	}
}

public class Ch11Ex02 {

	/**
	 * Exercise 2: (1) Define an object reference and initialize it to null. Try to
	 * call a method through this reference. Now wrap the code in a try-catch clause
	 * to catch the exception.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Item item = new Item();
		int i = Integer.parseInt(item.s);
		try {
			System.err.println(i);
		}catch (Exception e) {
			e.printStackTrace(System.out);
		}
	}
}
/*
Exception in thread "main" java.lang.NumberFormatException: null
		at java.lang.Integer.parseInt(Unknown Source)
		at java.lang.Integer.parseInt(Unknown Source)
		at exercise02.Ch11Ex02.main(Ch11Ex02.java:22)
*/