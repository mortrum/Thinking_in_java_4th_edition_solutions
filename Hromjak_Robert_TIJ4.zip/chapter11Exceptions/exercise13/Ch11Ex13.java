package exercise13;

class ExceptionA extends Exception {

}

class ExceptionB extends Exception {

}

class ExceptionC extends Exception {

}

class AllThreeException {
	void foo(int i) throws Exception {
		switch (i) {
		case 1:
			throw new ExceptionA();
		case 2:
			throw new ExceptionB();
		case 3:
			throw new ExceptionC();

		default:
			break;
		}
	}
}

public class Ch11Ex13 {

	/**
	 * Exercise 13: (2) Modify Exercise 9 by adding a finally clause. Verify that
	 * your finally clause is executed, even if a NullPointerException is thrown.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		AllThreeException allThreeException = new AllThreeException();
		for (int i = 1; i < 4; i++) {
			try {
				allThreeException.foo(i);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally {
				System.out.println("Finally!!");
			}
		}
	}
}
/*
 * Output:
 * exercise13.ExceptionA
Finally!!	at exercise13.AllThreeException.foo(Ch11Ex13.java:19)
	at exercise13.Ch11Ex13.main(Ch11Ex13.java:44)
exercise13.ExceptionB

	at exercise13.AllThreeException.foo(Ch11Ex13.java:21)
	at exercise13.Ch11Ex13.main(Ch11Ex13.java:44)
Finally!!
exercise13.ExceptionC
	at exercise13.AllThreeException.foo(Ch11Ex13.java:23)
	at exercise13.Ch11Ex13.main(Ch11Ex13.java:44)
Finally!!

 */
