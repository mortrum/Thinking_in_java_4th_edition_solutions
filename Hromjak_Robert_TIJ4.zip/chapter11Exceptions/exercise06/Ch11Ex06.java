package exercise06;

import java.io.*;
import java.util.*;
import java.util.logging.*;

public class Ch11Ex06 {
	public static class Exception1 extends Exception {
		private static final long serialVersionUID = 0;
		private Logger log = Logger.getLogger("Exception1");

		public Exception1() {
			super();
			StringWriter traceStr = new StringWriter();
			printStackTrace(new PrintWriter(traceStr));
			this.log.severe(traceStr.toString());
		}
	}

	public static class Exception2 extends Exception {
		private static final long serialVersionUID = 0;
		private Logger log = Logger.getLogger("Exception2");

		public Exception2() {
			super();
			StringWriter traceStr = new StringWriter();
			printStackTrace(new PrintWriter(traceStr));
			this.log.severe(traceStr.toString());
		}
	}

	/**
	 * Exercise 6: (1) Create two exception classes, each of which performs its own
	 * logging automatically. Demonstrate that these work.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			throw new Ch11Ex06.Exception1();
		} catch (Ch11Ex06.Exception1 e) {
			System.err.println(e);
		}
		try {
			throw new Ch11Ex06.Exception2();
		} catch (Ch11Ex06.Exception2 e) {
			System.err.println(e);
		}
	}
}
/*
Aug 27, 2019 3:50:21 PM exercise06.Ch11Ex06$Exception1 <init>
SEVERE: exercise06.Ch11Ex06$Exception1
	at exercise06.Ch11Ex06.main(Ch11Ex06.java:40)

exercise06.Ch11Ex06$Exception1
Aug 27, 2019 3:50:21 PM exercise06.Ch11Ex06$Exception2 <init>
SEVERE: exercise06.Ch11Ex06$Exception2
	at exercise06.Ch11Ex06.main(Ch11Ex06.java:45)

exercise06.Ch11Ex06$Exception2
*/
