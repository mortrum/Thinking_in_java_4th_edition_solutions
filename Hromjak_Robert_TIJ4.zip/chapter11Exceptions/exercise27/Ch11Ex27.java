package exercise27;

public class Ch11Ex27 {

	/**
	 * Exercise 27: (1) Modify Exercise 3 to convert the exception to a
	 * RuntimeException.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		int[] a = new int[2];
		try {
			a[3] = 11;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
