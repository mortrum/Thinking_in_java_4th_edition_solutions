package exercise03;

public class Ch11Ex03 {

	/**
	 * Exercise 3: (1) Write code to generate and catch an
	 * ArraylndexOutOfBoundsException.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		int[] a = new int[2];
		try {
			a[3] = 11;
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}
/*
java.lang.ArrayIndexOutOfBoundsException: 3
		at exercise03.Ch11Ex03.main(Ch11Ex03.java:14)
*/