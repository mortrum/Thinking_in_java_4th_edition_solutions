package exercise24;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

class FailingConstructor {
	static int i = 0;
	
	void dispose() {
		if(i++ == 1)
			throw new RuntimeException();
	}

	public FailingConstructor() {
		super();
		dispose();
	}

	void notTheBestMethod(File file) {
		try {
			try {
				BufferedReader br = new BufferedReader(new FileReader(file));
				System.out.println(br);
			} finally {

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

public class Ch11Ex24 {

	/**
	 * Exercise 24: (3) Add a dispose( ) method to the FailingConstructor class and
	 * write code to properly use this class.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		FailingConstructor failingConstructor = new FailingConstructor();
		failingConstructor.notTheBestMethod(new File("alma.txt"));
		
		//! FailingConstructor failingConstructor2 = new FailingConstructor();
		
		
	}
}
/*
java.io.BufferedReader@15db9742
*/