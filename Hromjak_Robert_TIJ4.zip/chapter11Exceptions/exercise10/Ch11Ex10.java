package exercise10;

class ExceptionA extends Exception {

}

class ExceptionB extends Exception {

}

class TwoMethods{
	void f() {
		try{
			g();
		}catch (Exception e) {
			try {
				throw new ExceptionB();
			} catch (ExceptionB e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	void g() {
		try {
			throw new ExceptionA();
		} catch (ExceptionA e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

public class Ch11Ex10 {

	/**
	 * Exercise 10: (2) Create a class with two methods, f( ) and g( ). In g( ),
	 * throw an exception of a new type that you define. In f( ), call g( ), catch
	 * its exception and, in the catch clause, throw a different exception (of a
	 * second type that you define). Test your code in main( ).
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		TwoMethods methods = new TwoMethods();
		methods.g();
		System.out.println("end");
	}
}
/*
Output:
exercise10.ExceptionA
		at exercise10.TwoMethods.g(Ch11Ex10.java:27)
		at exercise10.Ch11Ex10.main(Ch11Ex10.java:47)
end
*/