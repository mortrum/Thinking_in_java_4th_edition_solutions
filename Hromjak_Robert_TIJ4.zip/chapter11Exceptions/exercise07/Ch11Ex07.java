package exercise07;

import java.io.*;
import java.util.logging.Logger;

public class Ch11Ex07 {

	/**
	 * Exercise 7: (1) Modify Exercise 3 so that the catch clause logs the results.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		int[] a = new int[2];
		try {
			a[3] = 11;
		}catch (Exception e) {
			Logger log = Logger.getLogger("ArrayIndexOutOfBoundsException");
            StringWriter trace = new StringWriter();
            e.printStackTrace(new PrintWriter(trace));
            log.severe(trace.toString());
            System.err.println(e);
		}
	}
}
/*
Output:
Aug 14, 2019 2:15:55 PM exercise07.Ch11Ex07 main
SEVERE: java.lang.ArrayIndexOutOfBoundsException: 3
	at exercise07.Ch11Ex07.main(Ch11Ex07.java:16)

java.lang.ArrayIndexOutOfBoundsException: 3

*/