package exercise25;

public class Ch11Ex25 {
	public static class BaseException extends Exception {
		private static final long serialVersionUID = 0;
	}

	public static class DerivedException extends BaseException {
		private static final long serialVersionUID = 0;
	}

	public static class DerivedLevelTwoException extends DerivedException {
		private static final long serialVersionUID = 0;
	}

	public static class A {
		public void foo() throws BaseException {
			throw new BaseException();
		}
	}

	public static class B extends A {
		public void foo() throws DerivedException {
			throw new DerivedException();
		}
	}

	public static class C extends B {
		public void foo() throws DerivedLevelTwoException {
			throw new DerivedLevelTwoException();
		}
	}

	public static class D extends C {
		public void foo() {
		}
	}

	/**
	 * Exercise 25: (2) Create a three-level hierarchy of exceptions. Now create a
	 * base-class A with a method that throws an exception at the base of your
	 * hierarchy. Inherit B from A and override the method so it throws an exception
	 * at level two of your hierarchy. Repeat by inheriting class C from B. In main(
	 * ), create a C and upcast it to A, then call the method.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		C myC = new C();
        A myA = (A)myC;
        try {
            myA.foo();
        } catch (BaseException e) {
            e.printStackTrace();
        }
	}
}
/*
exercise25.Ch11Ex25$DerivedLevelTwoException
	at exercise25.Ch11Ex25$C.foo(Ch11Ex25.java:30)
	at exercise25.Ch11Ex25.main(Ch11Ex25.java:52)
*/
