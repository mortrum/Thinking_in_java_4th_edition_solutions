package exercise28;

class MyException extends RuntimeException {
	static final long serialVersionUID = 1L;
	private String s;

	public MyException(String s) {
		super();
		this.s = s;
	}

	public void printS() {
		System.out.println(s);
	}
}

public class Ch11Ex28 {

	/**
	 * Exercise 28: (1) Modify Exercise 4 so that the custom exception class
	 * inherits from RuntimeException, and show that the compiler allows you to
	 * leave out the try block.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		throw new MyException("apple");

	}
}
/*
Exception in thread "main" exercise28.MyException
at exercise28.Ch11Ex28.main(Ch11Ex28.java:28)
*/