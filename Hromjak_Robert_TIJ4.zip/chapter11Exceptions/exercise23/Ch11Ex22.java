package exercise23;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

class FailingConstructor {

	public FailingConstructor() {
		super();
		Dispose d = new Dispose();
	}

	static void notTheBestMethod(File file) {
		try {
			try {
				BufferedReader br = new BufferedReader(new FileReader(file));
				System.out.println(br);
			} finally {

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

class Dispose {
	static int id = 0;

	public Dispose() {
		super();
		if (id++ >= 1)
			throw new RuntimeException();
	}

	void dispose() {
		System.out.println("dispose ...");
	}
}

public class Ch11Ex22 {

	/**
	 * Exercise 23: (4) Add a class with a dispose( ) method to the previous
	 * exercise. Modify FailingConstructor so that the constructor creates one of
	 * these disposable objects as a member object, after which the constructor
	 * might throw an exception, after which it creates a second disposable member
	 * object. Write code to properly guard against failure, and in main( ) verify
	 * that all possible failure situations are covered.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			FailingConstructor fc = new FailingConstructor();
			FailingConstructor fc2 = new FailingConstructor();
			FailingConstructor.notTheBestMethod(new File("alma.txt"));
		} catch (Exception e) {
			System.err.println(e);
		}

	}
}
/*
 * java.lang.RuntimeException
 */
