package exercise18;

class VeryImportantException extends Exception {
	public String toString() {
		return "A very important exception!";
	}
}

class HoHumException extends Exception {
	public String toString() {
		return "A trivial exception";
	}
}

class VeryTrivialExceprion extends Exception{
	public String toString() {
		return "A very trivial exception";
	}
}

class LostMessage {
	void f() throws VeryImportantException {
		throw new VeryImportantException();
	}

	void dispose() throws HoHumException {
		throw new HoHumException();
	}
	
	void veryTrivial() throws VeryTrivialExceprion{
		throw new VeryTrivialExceprion();
	}
}

public class Ch11Ex18 {

	/**
	 * Exercise 18: (3) Add a second level of exception loss to LostMessage.java so
	 * that the HoHumException is itself replaced by a third exception.
	 * 
	 * @param args
	 * @return very trivial exception
	 */
	public static void main(String[] args) {
		try {
			LostMessage lm = new LostMessage();
			try {
				lm.f();
			} finally {
				lm.veryTrivial();
				lm.dispose();

			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
