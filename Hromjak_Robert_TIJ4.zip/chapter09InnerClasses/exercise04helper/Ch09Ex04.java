package exercise04helper;

public class Ch09Ex04 {

	/**
	 * Exercise 4: (2) Add a method to the class Sequence.SequenceSelector that
	 * produces the reference to the outer class Sequence.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

	}
}
