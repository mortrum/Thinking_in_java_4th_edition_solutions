package exercise17;

import java.util.Random;

interface Game {
	void value();
}

interface GameFactory {
	Game getGame();
}

class Coin implements Game {
	Random rand = new Random();
	int value = rand.nextInt(2) + 1;


	public void value() {
		System.out.println("coin value: " + value);
	}

	public static GameFactory factory = new GameFactory() {

		@Override
		public Game getGame() {
			return new Coin();
		}
	};
}

class Dice implements Game {
	Random rand = new Random();
	int value = rand.nextInt(6) + 1;

	public void value() {
		System.out.println("dice value: " + value);
	}

	public static GameFactory factory = new GameFactory() {

		@Override
		public Game getGame() {
			return new Dice();
		}
	};
}

public class Ch09Ex17 {
	public static void playGame(GameFactory factory) {
		Game game = factory.getGame();
		game.value();
	}

	/**
	 * Exercise 19: (3) Create a framework using Factory Methods that performs both
	 * coin tossing and dice tossing.
	 * 
	 * @param args
	 * @return dice value: 6 coin value: 2
	 * 
	 */
	public static void main(String[] args) {
		playGame(Dice.factory);
		playGame(Coin.factory);
	}

}
