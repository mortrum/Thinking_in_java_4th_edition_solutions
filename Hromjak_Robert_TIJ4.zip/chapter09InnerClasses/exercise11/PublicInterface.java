package exercise11;

public interface PublicInterface {
	void f();
}
