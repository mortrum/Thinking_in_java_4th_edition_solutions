package exercise11;

class Outer {
	private class Inner implements PublicInterface {
		@Override
		public void f() {
			System.out.println("f()");
		}
	}

	PublicInterface createInner() {
		return new Inner();
	}
}

public class Ch09Ex11 {

	/**
	 * Exercise 11: (2) Create a private inner class that implements a public
	 * interface. Write a method that returns a reference to an instance of the
	 * private inner class, upcast to the interface. Show that the inner class is
	 * completely hidden by trying to downcast to it.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Outer obj = new Outer();
		obj.createInner().f();
		// !((Inner)obj.createInner()).f();
	}
}
/*
f()
*/