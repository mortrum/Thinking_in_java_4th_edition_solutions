package exercise16;

interface Cycle {
	void name();
}

interface CycleFactory {
	Cycle getCycle();
}

class Unicycle implements Cycle {
	public Unicycle() {

	}

	@Override
	public void name() {
		System.out.println("Unicycle Impl");
	}
	
	public static CycleFactory factory = new CycleFactory() {
		@Override
		public Cycle getCycle() {
			return new Unicycle();
		}
	};
}


class Bicycle implements Cycle {
	public Bicycle() {

	}

	@Override
	public void name() {
		System.out.println("Bicycle Impl");
	}
	
	public static CycleFactory factory = new CycleFactory() {
		@Override
		public Cycle getCycle() {
			return new Bicycle();
		}
	};
}


class Tricycle implements Cycle {
	public Tricycle() {

	}

	@Override
	public void name() {
		System.out.println("Tricycle Impl");

	}
	
	public static CycleFactory factory = new CycleFactory() {
		
		@Override
		public Cycle getCycle() {
			return new Tricycle();
		}
	};
}


public class Ch09Ex16 {

	public static void cycleConsumer(CycleFactory fact) {
		Cycle c = fact.getCycle();
		c.name();
	}

	/**
	 * Exercise 16: (1) Modify the solution to Exercise 18 from the Interfaces
	 * chapter to use anonymous inner classes.
	 * 
	 * @param args
	 * @return Unicycle Impl Bicycle Impl Tricycle Impl
	 * 
	 */
	public static void main(String[] args) {
		cycleConsumer(Unicycle.factory);
		cycleConsumer(Bicycle.factory);
		cycleConsumer(Tricycle.factory);
	}

}
