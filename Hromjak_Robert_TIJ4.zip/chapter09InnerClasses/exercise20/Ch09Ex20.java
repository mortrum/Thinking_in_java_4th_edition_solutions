package exercise20;

interface Interface {
	class Nested {
		void f() {
			System.out.println("f()");
		}
	}
}

public class Ch09Ex20 implements Interface {

	/**
	 * Exercise 20: (1) Create an interface containing a nested class. Implement
	 * this interface and create an instance of the nested class.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Interface.Nested n = new Nested();
		n.f();
	}
}
/*
f()
*/