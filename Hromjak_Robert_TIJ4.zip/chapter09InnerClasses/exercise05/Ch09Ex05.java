package exercise05;

class Outer {
	Outer() {
		System.out.println("Outer");
	}

	class Inner {
		Inner() {
			System.out.println("Inner");
		}
	}
}

public class Ch09Ex05 {

	/**
	 * Exercise 5: (1) Create a class with an inner class. In a separate class, make
	 * an instance of the inner class
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Outer outer = new Outer();
		Outer.Inner inner = outer.new Inner();
	}
}
