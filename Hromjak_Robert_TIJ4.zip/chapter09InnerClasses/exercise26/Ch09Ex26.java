package exercise26;

class FirstOuter {
	class FirstInner {
		FirstInner() {
			System.out.println("first inner");
		}
	}
}

public class Ch09Ex26 {
	
	public class SecondInner extends FirstOuter.FirstInner{

		public SecondInner(FirstOuter o) {
			o.super();
			System.out.println("second inner");
		}
		
	}

	/**
	 * Exercise 26: (2) Create a class with an inner class that has a non-default
	 * constructor (one that takes arguments). Create a second class with an inner
	 * class that inherits from the first inner class.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		FirstOuter firstOuter = new FirstOuter();
		Ch09Ex26 ex26 = new Ch09Ex26();
		SecondInner si = ex26.new SecondInner(firstOuter);
	}
}
/*
first inner
second inner
*/