package exercise06helper2;

import exercise06.Interface2;
import exercise06helper.Helper;

public class Third extends Helper {
	public Interface2 createInner() {
		return this.new Inner();
	}

	/**
	 * Exercise 6: (2) Create an interface with at least one method, in its own
	 * package. Create a class in a separate package. Add a protected inner class
	 * that implements the interface. In a third package, inherit from your class
	 * and, inside a method, return an object of the protected inner class,
	 * upcasting to the interface during the return.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Third obj = new Third();
		System.out.println(obj.createInner().f());
	}
}
/*
 * inner constuctor inner f()
 */