package exercise13;

interface MakesSounds {
	public void ring();
}

public class Ch09Ex13 {
	public MakesSounds sound(String s) {
		return new MakesSounds() {

			@Override
			public void ring() {
				System.out.println("sound: " + s);
			}
		};
	}

	/**
	 * Exercise 13: (1) Repeat Exercise 9 using an anonymous inner class.
	 * 
	 * @param args
	 * @return sound: almafa
	 * 
	 */
	public static void main(String[] args) {
		Ch09Ex13 device = new Ch09Ex13();
		device.sound("almafa").ring();
	}
}
