package exercise21;

interface Interface {
	String name();

	void showName();

	static class Nested {
		static void invokeShowName(Interface m) {
			System.out.println("MyInterface.Nested.invokeShowName()");
			m.showName();
		}
	}
}

public class Ch09Ex21 implements Interface {

	/**
	 * Exercise 21: (2) Create an interface that contains a nested class that has a
	 * static method that calls the methods of your interface and displays the
	 * results. Implement your interface and pass an instance of your implementation
	 * to the method.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Ch09Ex21 obj = new Ch09Ex21();
		Interface.Nested.invokeShowName(obj);
	}

	@Override
	public String name() {
		return "name";
	}

	@Override
	public void showName() {
		System.out.println("showName()");
		System.out.println(name());

	}
}
/*
MyInterface.Nested.invokeShowName()
showName()
name
*/