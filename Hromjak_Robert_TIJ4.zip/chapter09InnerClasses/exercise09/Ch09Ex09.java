package exercise09;

interface MakesSounds {
	public void ring();
}

public class Ch09Ex09 {

	public MakesSounds sound(String r) {
		class Smartphone implements MakesSounds {
			private String ringtone;

			private Smartphone(String rt) {
				this.ringtone = rt;
			}

			public void ring() {
				System.out.println("Smartphone makes sound: " + ringtone);
			}
		}
		return new Smartphone(r);
	}

	/**
	 * Exercise 9: (1) Create an interface with at least one method, and implement
	 * that interface by defining an inner class within a method, which returns a
	 * reference to your interface.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Ch09Ex09 obj = new Ch09Ex09();
		obj.sound("alam").ring();
	}
}
