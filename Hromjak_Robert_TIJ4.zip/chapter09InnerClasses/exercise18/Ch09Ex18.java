package exercise18;

public class Ch09Ex18 {
	static class Nested{
		int i = 1;
	}
	/**
	 * Exercise 18: (1) Create a class containing a nested class. In main( ), create
	 * an instance of the nested class
	 */
	public static void main(String[] args) {
		Nested nested = new Nested();
		System.out.println(nested.i);
	}
}
/*
1
*/