package exercise12;

interface Inner{
	void modifyOuterS(String s);
}

public class Ch09Ex12 {
	private String s;

	private void showS() {
		System.out.println("String: " + s);
	}
	
	public Inner inner() {
		return new Inner() {
			
			@Override
			public void modifyOuterS(String str) {
				s = str;
				System.out.println("modified!");
				showS();
			}
		};
	}
	/**
	 * Exercise 12: (1) Repeat Exercise 7 using an anonymous inner class. 
	 * @param args
	 */
	public static void main(String[] args) {
		Ch09Ex12 obj = new Ch09Ex12();
		obj.showS();
		obj.inner().modifyOuterS("alma");
	}
}
/*
String: null
modified!
String: alma
*/