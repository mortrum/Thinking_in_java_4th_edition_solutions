package exercise08;

public class Ch09Ex08 {

	/**
	 * Exercise 8: (2) Determine whether an outer class has access to the private
	 * elements of its inner class.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Outer outer = new Outer();
		outer.showOuterI();
		outer.showInnerI();
	}
}
/*
11
i: 11
*/