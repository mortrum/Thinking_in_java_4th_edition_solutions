package exercise08;

public class Outer {

	class Inner{
		private int i = 11;
		private void showI(){
			System.out.println("i: " + i);
		}
	}

	public int outerI = new Inner().i;
	public void showOuterI() {
		System.out.println(outerI);
	}
	public void showInnerI() {
		new Inner().showI();
	}
}
