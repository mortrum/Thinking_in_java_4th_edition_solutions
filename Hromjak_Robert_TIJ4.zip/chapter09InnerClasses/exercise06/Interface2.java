package exercise06;

public interface Interface2 {
	String f();
}