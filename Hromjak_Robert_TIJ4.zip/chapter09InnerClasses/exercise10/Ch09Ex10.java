package exercise10;

interface Interface {
	void testMessage(String s);
}

class Outer {
	private class Inner implements Interface {
		public void testMessage(String s) {
			System.out.println("testMessage from Inner class: " + s);
		}
	}

	Interface createInner() {
		return new Inner();
	}
}

public class Ch09Ex10 {
	/**
	 * Exercise 10: (1) Repeat the previous exercise but define the inner class
	 * within a scope within a method.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Outer obj = new Outer();
		obj.createInner().testMessage("Hello !");
	}
}
/*
 * testMessage from Inner class: Hello !
 */