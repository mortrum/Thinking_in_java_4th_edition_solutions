package exercise19;

public class Ch09Ex19 {
	private class Inner {
		private class Inner2 {

		}
	}

	static class Nested{
		static class Nested2{
			
		}
	}
	
	/**
	 * Exercise 19: (2) Create a class containing an inner class that itself
	 * contains an inner class. Repeat this using nested classes. Note the names of
	 * the .class files produced by the compiler.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Ch09Ex19 obj = new Ch09Ex19();
		Ch09Ex19.Inner inner = obj.new Inner();
		Ch09Ex19.Inner.Inner2 inner2 = inner.new Inner2();
		
		Nested nested = new Nested();
		Nested.Nested2 nested2 = new Nested.Nested2();
		
		System.out.println(obj.getClass());
		System.out.println(inner.getClass());
		System.out.println(inner2.getClass());
		
		System.out.println("********");
		
		System.out.println(nested.getClass());
		System.out.println(nested2.getClass());
	}
}
/*class exercise19.Ch09Ex19
class exercise19.Ch09Ex19$Inner
class exercise19.Ch09Ex19$Inner$Inner2
********
class exercise19.Ch09Ex19$Nested
class exercise19.Ch09Ex19$Nested$Nested2
*/