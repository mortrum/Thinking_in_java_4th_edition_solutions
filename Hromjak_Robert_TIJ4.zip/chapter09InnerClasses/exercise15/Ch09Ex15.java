package exercise15;

class Dog {
	String name;

	public Dog(String s) {
		name = s;
	}

	void f() {
		System.out.println("Dog name: " + name);
	}
}

public class Ch09Ex15 {
	Dog createDog(String s) {
		return new Dog(s);
	}

	/**
	 * Exercise 15: (2) Create a class with a non-default constructor (one with
	 * arguments) and no default constructor (no "no-arg" constructor). Create a
	 * second class that has a method that returns a reference to an object of the
	 * first class. Create the object that you return by making an anonymous inner
	 * class that inherits from the first class.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Ch09Ex15 obj = new Ch09Ex15();
		obj.createDog("Max").f();
	}
}
