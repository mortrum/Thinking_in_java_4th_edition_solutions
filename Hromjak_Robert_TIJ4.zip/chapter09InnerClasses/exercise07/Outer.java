package exercise07;

public class Outer {
	private String s;

	private void print() {
		System.out.println("Outer print()");
	}

	void second() {
		Inner inner = new Inner();
		inner.modifier();
	}
	
	
	@Override
	public String toString() {
		return "Outer [s=" + s + "]";
	}


	class Inner {
		void modifier() {
			s = "alma";
			print();
		}
	}
}
