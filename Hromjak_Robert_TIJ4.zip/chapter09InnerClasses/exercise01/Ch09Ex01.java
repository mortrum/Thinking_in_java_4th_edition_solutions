package exercise01;

class Outer{
	class Inner{
		
	}
	Inner getInner() {
		return new Inner();
	}
}

public class Ch09Ex01 {

	/**
	 * Exercise 1: (1) Write a class named Outer that contains an inner class named
	 * Inner. Add a method to Outer that returns an object of type Inner. In main(
	 * ), create and initialize a reference to an Inner.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Outer outer = new Outer();
		outer.getInner();
	}
}
