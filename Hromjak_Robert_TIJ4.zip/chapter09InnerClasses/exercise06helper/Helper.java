package exercise06helper;

import exercise06.Interface2;

public class Helper {

	protected class Inner implements Interface2 {

		public Inner() {
			super();
			System.out.println("inner constuctor");
		}

		@Override
		public String f() {
			return "inner f()";
		}

	}
}
