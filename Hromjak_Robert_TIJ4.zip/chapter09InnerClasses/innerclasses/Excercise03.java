package innerclasses;

public class Excercise03 {
	private String s;

	public Excercise03(String s) {
		this.s = s;
	}

	class Inner {


		@Override
		public String toString() {
			return "Inner [] " + s;
		}
		
	}

//	public Inner inner() {
//		return new Inner();
//
//	}

	/**
	 * Exercise 3: (1) Modify Exercise 1 so that Outer has a private String field
	 * (initialized by the constructor), and Inner has a toString( ) that displays
	 * this field. Create an object of type Inner and display it.
	 * 
	 * @param String
	 * @return Inner []test
	 */
	public static void main(String[] args) {
		Excercise03 excercise03 = new Excercise03("test");
		Inner inner = excercise03.new Inner();
		System.out.println(inner.toString());

	}

}
