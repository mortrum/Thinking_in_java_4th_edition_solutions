package innerclasses;

public class Excercise01 {
	class Inner {

	}

	public Inner inner() {
		return new Inner();
	}

	/**
	 * Exercise 1: (1) Write a class named Outer that contains an inner class named
	 * Inner. Add a method to Outer that returns an object of type Inner. In main(
	 * ), create and initialize a reference to an Inner.
	 * 
	 * @param args
	 * @returns
	 * 
	 */

	public static void main(String[] args) {

		Excercise01 outer = new Excercise01();
		outer.inner();

	}
}
