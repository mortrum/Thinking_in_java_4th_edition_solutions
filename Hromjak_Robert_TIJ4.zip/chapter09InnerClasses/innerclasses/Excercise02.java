package innerclasses;

import java.util.Arrays;

class TestClass1 {
	String s;

	@Override
	public String toString() {
		return "TestClass1 [s=" + s + "]";
	}

}

class Sequence {
	String[] array = new String[5];

}

public class Excercise02 {

	/**
	 * 
	 * @author robert.hromjak
	 *
	 *         Exercise 2: (1) Create a class that holds a String, and has a
	 *         toString( ) method that displays this String. Add several instances
	 *         of your new class to a Sequence object, then display them.
	 * 
	 * @param "egy"
	 * @returns [egy, null, null, null, null]
	 * 
	 */
	public static void main(String[] args) {
		Sequence seq = new Sequence();
		TestClass1 testClass1 = new TestClass1();
		testClass1.s = "egy";
		seq.array[0] = testClass1.s;
		System.out.println(Arrays.toString(seq.array));
	}
}
