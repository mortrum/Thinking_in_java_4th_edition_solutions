package exercise02;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import net.mindview.util.Countries;

public class Ch16Ex02 {

	/**
	 * Exercise 2: (2) Produce a Map and a Set containing all the countries that
	 * begin with �A�.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Map<String, String> map = new HashMap<String, String>();
		Set<String> set = new HashSet<>();

		int size = Countries.DATA.length;

		int index = 0;
		while (index < size) {
			if (Countries.DATA[index][0].matches("^A.*")) {
				map.put(Countries.DATA[index][0], Countries.DATA[index][1]);
				set.add(Countries.DATA[index][0]);
			}
			index++;
		}

		System.out.println(set);
		System.out.println(map);
	}
}
/*
 * [AUSTRALIA, AFGHANISTAN, AZERBAIJAN, ALBANIA, ANDORRA, ANTIGUA AND BARBUDA,
 * ARGENTINA, ANGOLA, ARMENIA, ALGERIA, AUSTRIA]
 * 
 * {AUSTRALIA=Canberra, AFGHANISTAN=Kabul, AZERBAIJAN=Baku, ALBANIA=Tirana, ANDORRA=Andorra la Vella,
 * ANTIGUA AND BARBUDA=Saint John's, ARGENTINA=Buenos Aires, ANGOLA=Luanda,
 * ARMENIA=Yerevan, ALGERIA=Algiers, AUSTRIA=Vienna}
 */