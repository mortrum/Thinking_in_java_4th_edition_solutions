package exercise03;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

import net.mindview.util.Countries;

public class Ch16Ex03 {

	/**
	 * Exercise 3: (1) Using Countries, fill a Set multiple times with the same data
	 * and verify that the Set ends up with only one of each instance. Try this with
	 * HashSet, LinkedHashSet, and TreeSet.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		Set<String> set = new HashSet<>();
		Set<String> set2 = new LinkedHashSet<>();
		Set<String> set3 = new TreeSet<>();

		int size = Countries.DATA.length;

		int index = 0;
		while (index < 10) {
			set.add(Countries.DATA[index][0]);
			set.add(Countries.DATA[index][0]);
			set2.add(Countries.DATA[index][0]);
			set2.add(Countries.DATA[index][0]);
			set3.add(Countries.DATA[index][0]);
			set3.add(Countries.DATA[index][0]);

			index++;
		}

		
		System.out.println(set);
		System.out.println(set2);
		System.out.println(set3);
	}
}
/*
[BENIN, BOTSWANA, CENTRAL AFRICAN REPUBLIC, CHAD, CAMEROON, CAPE VERDE, ANGOLA, BURKINA FASO, ALGERIA, BURUNDI]
[ALGERIA, ANGOLA, BENIN, BOTSWANA, BURKINA FASO, BURUNDI, CAMEROON, CAPE VERDE, CENTRAL AFRICAN REPUBLIC, CHAD]
[ALGERIA, ANGOLA, BENIN, BOTSWANA, BURKINA FASO, BURUNDI, CAMEROON, CAPE VERDE, CENTRAL AFRICAN REPUBLIC, CHAD]
*/