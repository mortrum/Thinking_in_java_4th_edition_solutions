package exercise23TODO;

public class Ch16Ex23 {

	/**
	 * Exercise 23: (3) Implement the rest of the Map interface for SimpleHashMap. (19 ex)
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

	}
}
