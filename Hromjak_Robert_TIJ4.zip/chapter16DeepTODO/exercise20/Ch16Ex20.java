package exercise20;

import java.util.Map;

import exercise19.SimpleHashMap;

public class Ch16Ex20 {

	/**
	 * Exercise 20: (3) Modify SimpleHashMap so that it reports collisions, and test
	 * this by adding the same data set twice so that you see collisions.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Map<String,Integer> map = new SimpleHashMap<>();
        map.put("Hello Ronald", 100);
        map.put("Hello Shen", 200);
        map.put("Hello Ronald", 23);
        
        System.out.println(map);
	}
}
/*
report! Collisions!
{Hello Ronald=23, Hello Shen=200}
*/