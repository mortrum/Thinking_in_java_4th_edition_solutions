package exercise14;

import java.util.Map;

import net.mindview.util.CountingMapData;
import static net.mindview.util.Print.*;

public class Ch16Ex14 {

	public static void printKeys(Map<Integer, String> map) {
		printnb("Size = " + map.size() + ", ");
		printnb("Keys: ");
		print(map.keySet()); // Produce a Set of the keys
	}

	public static void printKeysObj(Map<Object, Object> map) {
		printnb("Size = " + map.size() + ", ");
		printnb("Keys: ");
		print(map.keySet()); // Produce a Set of the keys
	}

	public static void test(Map<Integer, String> map) {
		print(map.getClass().getSimpleName());
		map.putAll(new CountingMapData(25));
		// Map has 'Set' behavior for keys:
		map.putAll(new CountingMapData(25));
		printKeys(map);
		// Producing a Collection of the values:
		printnb("Values: ");
		print(map.values());
		print(map);
		print("map.containsKey(11): " + map.containsKey(11));
		print("map.get(11): " + map.get(11));
		print("map.containsValue(\"F0\"): " + map.containsValue("F0"));
		Integer key = map.keySet().iterator().next();
		print("First key in map: " + key);
		map.remove(key);
		printKeys(map);
		map.clear();
		print("map.isEmpty(): " + map.isEmpty());
		map.putAll(new CountingMapData(25));
		// Operations on the Set change the Map:
		map.keySet().removeAll(map.keySet());
		print("map.isEmpty(): " + map.isEmpty());
	}

	public static void testObj(Map<Object, Object> map) {
		print(map.getClass().getSimpleName());
		map.putAll(new CountingMapData(25));
		// Map has 'Set' behavior for keys:
		map.putAll(new CountingMapData(25));
		printKeysObj(map);
		// Producing a Collection of the values:
		printnb("Values: ");
		print(map.values());
		print(map);
		print("map.containsKey(11): " + map.containsKey(11));
		print("map.get(11): " + map.get(11));
		print("map.containsValue(\"F0\"): " + map.containsValue("F0"));
		Object key = map.keySet().iterator().next();
		print("First key in map: " + key);
		map.remove(key);
		printKeysObj(map);
		map.clear();
		print("map.isEmpty(): " + map.isEmpty());
		map.putAll(new CountingMapData(25));
		// Operations on the Set change the Map:
		map.keySet().removeAll(map.keySet());
		print("map.isEmpty(): " + map.isEmpty());
	}

	/**
	 * Exercise 14: (3) Show that java.util.Properties works in the above program.
	 * 
	 * @param args
	 */

	public static void main(String[] args) {
		testObj(System.getProperties());
	}
}
/*
Properties
Size = 79, Keys: [java.vendor, sun.java.launcher, sun.management.compiler, os.name, sun.boot.class.path, sun.desktop, java.vm.specification.vendor, java.runtime.version, user.name, user.language, sun.boot.library.path, java.version, user.timezone, sun.arch.data.model, java.endorsed.dirs, sun.cpu.isalist, sun.jnu.encoding, file.encoding.pkg, file.separator, java.specification.name, java.class.version, user.country, java.home, java.vm.info, os.version, path.separator, java.vm.version, user.variant, java.awt.printerjob, sun.io.unicode.encoding, awt.toolkit, user.script, user.home, java.specification.vendor, java.library.path, java.vendor.url, java.vm.vendor, java.runtime.name, sun.java.command, java.class.path, java.vm.specification.name, java.vm.specification.version, sun.cpu.endian, sun.os.patch.level, java.io.tmpdir, java.vendor.url.bug, os.arch, java.awt.graphicsenv, java.ext.dirs, user.dir, line.separator, java.vm.name, 24, 23, 22, 21, 20, 19, 18, 17, 16, file.encoding, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, java.specification.version, 5, 4, 3, 2, 1, 0]
Values: [Oracle Corporation, SUN_STANDARD, HotSpot 64-Bit Tiered Compilers, Windows 10, C:\Program Files\Java\jre1.8.0_131\lib\resources.jar;C:\Program Files\Java\jre1.8.0_131\lib\rt.jar;C:\Program Files\Java\jre1.8.0_131\lib\sunrsasign.jar;C:\Program Files\Java\jre1.8.0_131\lib\jsse.jar;C:\Program Files\Java\jre1.8.0_131\lib\jce.jar;C:\Program Files\Java\jre1.8.0_131\lib\charsets.jar;C:\Program Files\Java\jre1.8.0_131\lib\jfr.jar;C:\Program Files\Java\jre1.8.0_131\classes, windows, Oracle Corporation, 1.8.0_131-b11, robert.hromjak, en, C:\Program Files\Java\jre1.8.0_131\bin, 1.8.0_131, , 64, C:\Program Files\Java\jre1.8.0_131\lib\endorsed, amd64, Cp1252, sun.io, \, Java Platform API Specification, 52.0, US, C:\Program Files\Java\jre1.8.0_131, mixed mode, 10.0, ;, 25.131-b11, , sun.awt.windows.WPrinterJob, UnicodeLittle, sun.awt.windows.WToolkit, , C:\Users\robert.hromjak, Oracle Corporation, C:\Program Files\Java\jre1.8.0_131\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:/Program Files/Java/jre1.8.0_131/bin/server;C:/Program Files/Java/jre1.8.0_131/bin;C:/Program Files/Java/jre1.8.0_131/lib/amd64;C:\ProgramData\Oracle\Java\javapath;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Windows\System32\OpenSSH\;C:\Users\robert.hromjak\AppData\Local\Microsoft\WindowsApps;;C:\eclipse\eclipse-2018-09;;., http://java.oracle.com/, Oracle Corporation, Java(TM) SE Runtime Environment, exercise14.Ch16Ex14, C:\Users\robert.hromjak\Documents\eclipse\exercises\bin, Java Virtual Machine Specification, 1.8, little, , C:\Users\ROBERT~1.HRO\AppData\Local\Temp\, http://bugreport.sun.com/bugreport/, amd64, sun.awt.Win32GraphicsEnvironment, C:\Program Files\Java\jre1.8.0_131\lib\ext;C:\Windows\Sun\Java\lib\ext, C:\Users\robert.hromjak\Documents\eclipse\exercises, 
, Java HotSpot(TM) 64-Bit Server VM, Y0, X0, W0, V0, U0, T0, S0, R0, Q0, Cp1252, P0, O0, N0, M0, L0, K0, J0, I0, H0, G0, 1.8, F0, E0, D0, C0, B0, A0]
{java.vendor=Oracle Corporation, sun.java.launcher=SUN_STANDARD, sun.management.compiler=HotSpot 64-Bit Tiered Compilers, os.name=Windows 10, sun.boot.class.path=C:\Program Files\Java\jre1.8.0_131\lib\resources.jar;C:\Program Files\Java\jre1.8.0_131\lib\rt.jar;C:\Program Files\Java\jre1.8.0_131\lib\sunrsasign.jar;C:\Program Files\Java\jre1.8.0_131\lib\jsse.jar;C:\Program Files\Java\jre1.8.0_131\lib\jce.jar;C:\Program Files\Java\jre1.8.0_131\lib\charsets.jar;C:\Program Files\Java\jre1.8.0_131\lib\jfr.jar;C:\Program Files\Java\jre1.8.0_131\classes, sun.desktop=windows, java.vm.specification.vendor=Oracle Corporation, java.runtime.version=1.8.0_131-b11, user.name=robert.hromjak, user.language=en, sun.boot.library.path=C:\Program Files\Java\jre1.8.0_131\bin, java.version=1.8.0_131, user.timezone=, sun.arch.data.model=64, java.endorsed.dirs=C:\Program Files\Java\jre1.8.0_131\lib\endorsed, sun.cpu.isalist=amd64, sun.jnu.encoding=Cp1252, file.encoding.pkg=sun.io, file.separator=\, java.specification.name=Java Platform API Specification, java.class.version=52.0, user.country=US, java.home=C:\Program Files\Java\jre1.8.0_131, java.vm.info=mixed mode, os.version=10.0, path.separator=;, java.vm.version=25.131-b11, user.variant=, java.awt.printerjob=sun.awt.windows.WPrinterJob, sun.io.unicode.encoding=UnicodeLittle, awt.toolkit=sun.awt.windows.WToolkit, user.script=, user.home=C:\Users\robert.hromjak, java.specification.vendor=Oracle Corporation, java.library.path=C:\Program Files\Java\jre1.8.0_131\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:/Program Files/Java/jre1.8.0_131/bin/server;C:/Program Files/Java/jre1.8.0_131/bin;C:/Program Files/Java/jre1.8.0_131/lib/amd64;C:\ProgramData\Oracle\Java\javapath;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Windows\System32\OpenSSH\;C:\Users\robert.hromjak\AppData\Local\Microsoft\WindowsApps;;C:\eclipse\eclipse-2018-09;;., java.vendor.url=http://java.oracle.com/, java.vm.vendor=Oracle Corporation, java.runtime.name=Java(TM) SE Runtime Environment, sun.java.command=exercise14.Ch16Ex14, java.class.path=C:\Users\robert.hromjak\Documents\eclipse\exercises\bin, java.vm.specification.name=Java Virtual Machine Specification, java.vm.specification.version=1.8, sun.cpu.endian=little, sun.os.patch.level=, java.io.tmpdir=C:\Users\ROBERT~1.HRO\AppData\Local\Temp\, java.vendor.url.bug=http://bugreport.sun.com/bugreport/, os.arch=amd64, java.awt.graphicsenv=sun.awt.Win32GraphicsEnvironment, java.ext.dirs=C:\Program Files\Java\jre1.8.0_131\lib\ext;C:\Windows\Sun\Java\lib\ext, user.dir=C:\Users\robert.hromjak\Documents\eclipse\exercises, line.separator=
, java.vm.name=Java HotSpot(TM) 64-Bit Server VM, 24=Y0, 23=X0, 22=W0, 21=V0, 20=U0, 19=T0, 18=S0, 17=R0, 16=Q0, file.encoding=Cp1252, 15=P0, 14=O0, 13=N0, 12=M0, 11=L0, 10=K0, 9=J0, 8=I0, 7=H0, 6=G0, java.specification.version=1.8, 5=F0, 4=E0, 3=D0, 2=C0, 1=B0, 0=A0}
map.containsKey(11): true
map.get(11): L0
map.containsValue("F0"): true
First key in map: java.vendor
Size = 78, Keys: [sun.java.launcher, sun.management.compiler, os.name, sun.boot.class.path, sun.desktop, java.vm.specification.vendor, java.runtime.version, user.name, user.language, sun.boot.library.path, java.version, user.timezone, sun.arch.data.model, java.endorsed.dirs, sun.cpu.isalist, sun.jnu.encoding, file.encoding.pkg, file.separator, java.specification.name, java.class.version, user.country, java.home, java.vm.info, os.version, path.separator, java.vm.version, user.variant, java.awt.printerjob, sun.io.unicode.encoding, awt.toolkit, user.script, user.home, java.specification.vendor, java.library.path, java.vendor.url, java.vm.vendor, java.runtime.name, sun.java.command, java.class.path, java.vm.specification.name, java.vm.specification.version, sun.cpu.endian, sun.os.patch.level, java.io.tmpdir, java.vendor.url.bug, os.arch, java.awt.graphicsenv, java.ext.dirs, user.dir, line.separator, java.vm.name, 24, 23, 22, 21, 20, 19, 18, 17, 16, file.encoding, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, java.specification.version, 5, 4, 3, 2, 1, 0]
map.isEmpty(): true
map.isEmpty(): true
*/
