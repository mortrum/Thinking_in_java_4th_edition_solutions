package exercise26and27;

import java.util.ArrayList;
import java.util.List;

class CountedString {
	private static List<String> created = new ArrayList<String>();
	private String s;
	private char c;
	private int id = 0;

	public CountedString(String str, char ch) {
		s = str;
		c = ch;
		created.add(s);
		// id is the total number of instances
		// of this string in use by CountedString:
		for (String s2 : created)
			if (s2.equals(s))
				id++;
	}

	public String toString() {
		return "String: " + s + " id: " + id + " char: " + c + " hashCode(): " + hashCode();
	}

	public int hashCode() {
		// The very simple approach:
		// return s.hashCode() * id;
		// Using Joshua Bloch's recipe:
		int result = 17;
		result = 37 * result + s.hashCode();
		result = 37 * result + (int) c;

		return result;
	}

	public boolean equals(Object o) {
		return o instanceof CountedString && s.equals(((CountedString) o).s) && id == ((CountedString) o).id;
	}
}

public class Ch16Ex26 {

	/**
	 * Exercise 26: (2) Add a char field to CountedString that is also initialized
	 * in the constructor, and modify the hashCode( ) and equals( ) methods to
	 * include the value of this char.
	 * 
	 * Exercise 27: (3) Modify the hashCode( ) in CountedString.java by removing the
	 * combination with id, and demonstrate that CountedString still works as a key.
	 * What is the problem with this approach?
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(new CountedString("a", 'a'));
		System.out.println(new CountedString("a", 'b'));
	}
}
/*
String: a id: 1 char: a hashCode(): 26959
String: a id: 2 char: b hashCode(): 26960
*/
