package exercise11;

import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;

class Item implements Comparable<Item> {
	Random random = new Random();
	int i = random.nextInt(100);

	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
	}

	@Override
	public int compareTo(Item o) {

		return i - o.getI();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + i;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		if (i != other.i)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Item [random=" + random + ", i=" + i + "]";
	}

}

public class Ch16Ex11 {
	public static void testWithPriorityQueue(int size, int max) {
		Queue<Item> priQue = new PriorityQueue<>(size);
		for (int i = 0; i < size; i++) {
			if (!priQue.offer(new Item())) {
				throw new IllegalStateException("Out of the queue capacity: " + size);
			}
		}
		System.out.println(priQue);
		for (int i = 0; i < size; i++) {
			System.out.println(priQue.poll());
		}
	}

	/**
	 * Exercise 11: (2) Create a class that contains an Integer that is initialized
	 * to a value between o and 100 using java.util.Random. Implement Comparable
	 * using this Integer field. Fill a PriorityQueue with objects of your class,
	 * and extract the values using poll( ) to show that it produces the expected
	 * order.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		testWithPriorityQueue(10, 100);
	}
}
/*
 * [Item [random=java.util.Random@6d06d69c, i=1], Item
 * [random=java.util.Random@7852e922, i=5], Item
 * [random=java.util.Random@4e25154f, i=50], Item
 * [random=java.util.Random@70dea4e, i=63], Item
 * [random=java.util.Random@5c647e05, i=27], Item
 * [random=java.util.Random@33909752, i=86], Item
 * [random=java.util.Random@55f96302, i=67], Item
 * [random=java.util.Random@3d4eac69, i=67], Item
 * [random=java.util.Random@42a57993, i=93], Item
 * [random=java.util.Random@75b84c92, i=64]] Item
 * [random=java.util.Random@6d06d69c, i=1] Item
 * [random=java.util.Random@7852e922, i=5] Item
 * [random=java.util.Random@5c647e05, i=27] Item
 * [random=java.util.Random@4e25154f, i=50] Item
 * [random=java.util.Random@70dea4e, i=63] Item
 * [random=java.util.Random@75b84c92, i=64] Item
 * [random=java.util.Random@3d4eac69, i=67] Item
 * [random=java.util.Random@55f96302, i=67] Item
 * [random=java.util.Random@33909752, i=86] Item
 * [random=java.util.Random@42a57993, i=93]
 */
