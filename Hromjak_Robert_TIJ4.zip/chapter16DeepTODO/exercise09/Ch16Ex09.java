package exercise09;

import java.util.TreeSet;

import net.mindview.util.Generator;
import net.mindview.util.RandomGenerator;

public class Ch16Ex09 {

	/**
	 * Exercise 9: (2) Use RandomGenerator.String to fill a TreeSet, but use
	 * alphabetic ordering. Print the TreeSet to verify the sort order.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Generator<String> strGen = new RandomGenerator.String();
		TreeSet<String> set = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
		set.add(strGen.next());
		set.add(strGen.next());
		set.add(strGen.next());
		set.add(strGen.next());
		set.add(strGen.next());
		set.add(strGen.next());
		set.add(strGen.next());
		set.add(strGen.next());
		set.add(strGen.next());
		set.add(strGen.next());
		set.add(strGen.next());
		set.add(strGen.next());

		System.out.println(set);
	}
}

/*
[ahKcxrE, GcFOWZn, GZMmJMR, kZPgwsq, naMesbt, oEsuEcU, OneOEdL, qUCBbkI, smwHLGE, TcQrGse, WHkjUrU, YNzbrny]
*/