package exercise18;

import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class SlowSet<E> extends AbstractSet<E>{
	private List<E> list = new ArrayList<E>();
	@Override
	public Iterator<E> iterator() {
		return list.iterator();
	}

	@Override
	public int size() {
		return list.size();
	}
	
	public boolean add(E e) {
		if(!list.contains(e)) {
			list.add(e);
			return true;
		}
		return false;
	}	
}


public class Ch16Ex18 {

	/**
	 * Exercise 18: (3) Using SlowMap.java for inspiration, create a SlowSet. 
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		SlowSet<String> set = new SlowSet<String>();
		
		set.add("alma");
		System.out.println(set);
	}
}
/*
[alma]
*/