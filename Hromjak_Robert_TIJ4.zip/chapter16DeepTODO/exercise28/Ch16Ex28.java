package exercise28;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import net.mindview.util.TwoTuple;

class Tuple {
	public static <A extends Comparable<? super A>, B extends Comparable<? super B>> TwoTuple<A, B> tuple(A a, B b) {
		return new TwoTuple<A, B>(a, b);
	}

	
} /// :~

public class Ch16Ex28 {

	/**
	 * Exercise 28: (4) Modify net/mindview/util/Tuple.java to make it a
	 * general-purpose class by adding hashCode( ), equals( ), and implementing
	 * Comparable for each type of Tuple.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		TwoTuple<String, String> tuple = new TwoTuple<String, String>("1", "1");
		TwoTuple<String, String> tuple2 = new TwoTuple<String, String>("2", "2");

		List<TwoTuple<String, String>> list = new ArrayList<TwoTuple<String, String>>();

		list.add(tuple);
		list.add(tuple2);
		list.add(new TwoTuple<String, String>("3", "bds"));
		list.add(new TwoTuple<String, String>("4", "cds"));
		list.add(new TwoTuple<String, String>("3", "ads"));

		Collections.sort(list);

		System.out.println(list);
	}
}

/*
[TwoTuple [first=1, second=1], TwoTuple [first=2, second=2], TwoTuple [first=3, second=bds], TwoTuple [first=4, second=cds], TwoTuple [first=3, second=ads]]
*/