package exercise13;

import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

import net.mindview.util.TextFile;

class AssociativeArray<K, V> {
	private Object[][] pairs;
	private int index;

	public AssociativeArray(int length) {
		pairs = new Object[length][2];
	}

	public void put(K key, V value) {
		if (index >= pairs.length)
			throw new ArrayIndexOutOfBoundsException();
		pairs[index++] = new Object[] { key, value };
	}

	@SuppressWarnings("unchecked")
	public V get(K key) {
		for (int i = 0; i < index; i++)
			if (key.equals(pairs[i][0]))
				return (V) pairs[i][1];
		return null; // Did not find key
	}

	public Boolean contains(K key) {
		for (int i = 0; i < pairs.length; i++) {
			if (key.equals(pairs[i][0]))
				return true;
		}

		return false;
	}

	public String toString() {
		StringBuilder result = new StringBuilder();
		for (int i = 0; i < index; i++) {
			result.append(pairs[i][0].toString());
			result.append(" : ");
			result.append(pairs[i][1].toString());
			if (i < index - 1)
				result.append("\n");
		}
		return result.toString();
	}

}

public class Ch16Ex13 {

	/**
	 * Exercise 13: (4) Use AssociativeArray Java to create a wordoccurrence
	 * counter, mapping String to Integer. Using the net.mindview.util.TextFile
	 * utility in this book, open a text file and break up the words in that file
	 * using whitespace and punctuation, and count the occurrence of the words in
	 * that file.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Set<String> wordsSet = new TreeSet<String>(new TextFile("alma.txt", "\\W++"));
		AssociativeArray<String, Integer> wordCounter = new AssociativeArray<String, Integer>(wordsSet.size());
		ArrayList<String> wordsList = new ArrayList<String>(new TextFile("alma.txt", "\\W++"));
		for (String s : wordsSet) {
			int counter = 0;
			for (String ss : wordsList) {
				if (ss.equals(s))
					counter++;
			}
			wordCounter.put(s, counter);
		}
		System.out.println(wordCounter);
	}
}
/*
	The : 1
	allows : 1
	any : 1
	create : 1
	for : 1
	free : 1
	generator : 1
	need : 1
	number : 1
	of : 1
	online : 1
	project : 1
	random : 2
	to : 1
	tool : 1
	word : 1
	words : 1
	you : 2
	your : 1
*/
