package exercise10TODO;

public class Ch16Ex10 {

	/**
	 * Exercise 10: (7) Using a LinkedList as your underlying implementation, define
	 * your own SortedSet.
	 */
	public static void main(String[] args) {

	}

}
