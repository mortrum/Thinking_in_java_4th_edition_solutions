package exercise19;

import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

import net.mindview.util.TextFile;

public class Ch16Ex19 {

	/**
	 * Exercise 19: (1) Repeat Exercise 13 using a SimpleHashMap.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Set<String> wordsSet = new TreeSet<String>(new TextFile("alma.txt", "\\W++"));
		SimpleHashMap<String, Integer> wordCounter = new SimpleHashMap<String, Integer>();
		ArrayList<String> wordsList = new ArrayList<String>(new TextFile("alma.txt", "\\W++"));
		for (String s : wordsSet) {
			int counter = 0;
			for (String ss : wordsList) {
				if (ss.equals(s))
					counter++;
			}
			wordCounter.put(s, counter);
		}
		System.out.println(wordCounter);
	}
}


/*
{allows=1, need=1, project=1, generator=1, words=1, for=1, your=1, any=1, tool=1, 
number=1, The=1, random=2, of=1, online=1, create=1, to=1, you=2, word=1, free=1}
*/