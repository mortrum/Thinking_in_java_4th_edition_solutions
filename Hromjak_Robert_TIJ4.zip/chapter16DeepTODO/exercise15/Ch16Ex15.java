package exercise15;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import net.mindview.util.TextFile;


class MapEntry<K,V> implements Map.Entry<K,V> {
	  private K key;
	  private V value;
	  public MapEntry(K key, V value) {
	    this.key = key;
	    this.value = value;
	  }
	  public K getKey() { return key; }
	  public V getValue() { return value; }
	  public V setValue(V v) {
	    V result = value;
	    value = v;
	    return result;
	  }
	  public int hashCode() {
	    return (key==null ? 0 : key.hashCode()) ^
	      (value==null ? 0 : value.hashCode());
	  }
	  public boolean equals(Object o) {
	    if(!(o instanceof MapEntry)) return false;
	    MapEntry me = (MapEntry)o;
	    return
	      (key == null ?
	       me.getKey() == null : key.equals(me.getKey())) &&
	      (value == null ?
	       me.getValue()== null : value.equals(me.getValue()));
	  }
	  public String toString() { return key + "=" + value; }
	}

class SlowMap<K, V> extends AbstractMap<K, V> {
	private List<K> keys = new ArrayList<K>();
	private List<V> values = new ArrayList<V>();

	public V put(K key, V value) {
		V oldValue = get(key); // The old value or null
		if (!keys.contains(key)) {
			keys.add(key);
			values.add(value);
		} else
			values.set(keys.indexOf(key), value);
		return oldValue;
	}

	public V get(Object key) { // key is type Object, not K
		if (!keys.contains(key))
			return null;
		return values.get(keys.indexOf(key));
	}

	public Set<Map.Entry<K, V>> entrySet() {
		Set<Map.Entry<K, V>> set = new HashSet<Map.Entry<K, V>>();
		Iterator<K> ki = keys.iterator();
		Iterator<V> vi = values.iterator();
		while (ki.hasNext())
			set.add(new MapEntry<K, V>(ki.next(), vi.next()));
		return set;
	}
}

public class Ch16Ex15 {

	/**
	 * Exercise 15: (1) Repeat Exercise 13 using a SlowMap.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Set<String> wordsSet =  new TreeSet<String>(new TextFile("alma.txt","\\W++"));
		SlowMap<String,Integer> wordCounter = new SlowMap<String,Integer>();
		ArrayList<String> wordsList = new ArrayList<String>(new TextFile("alma.txt","\\W++"));
		for(String s : wordsSet) {
			int counter = 0;
			for(String ss : wordsList) {
				if(ss.equals(s))
					counter++;
			}
			wordCounter.put(s, counter);
		}
		System.out.println(wordCounter);
	}
}
/*
{allows=1, need=1, generator=1, project=1, for=1, words=1, your=1, any=1, tool=1, number=1, The=1, random=2, of=1, create=1, online=1, to=1, word=1, you=2, free=1}
*/
