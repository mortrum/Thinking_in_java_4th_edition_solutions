package exercise21;

import java.util.Map;

import exercise19.SimpleHashMap;

public class Ch16Ex21 {

	/**
	 * Exercise 21: (2) Modify SimpleHashMap so that it reports the number of
	 * "probes" necessary when collisions occur. That is, how many calls to next( )
	 * must be made on the Iterators that walk the LinkedLists looking for matches?
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Map<String, Integer> map = new SimpleHashMap<>();
		map.put("Hello Ronald", 100);
		map.put("Hello Shen", 200);
		map.put("Hello Ronald", 100);
		map.remove("Hello Ronald");
        System.out.println(map);
        map.clear();
        System.out.println("SimpleHashMap is empty now? " + map.isEmpty());
	}
}
/*
report! Collisions! next() count: 1
Hello Ronald=100 removed!
{Hello Shen=200}
SimpleHashMap is empty now? true
*/