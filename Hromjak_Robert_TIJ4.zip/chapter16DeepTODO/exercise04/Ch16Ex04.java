package exercise04;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Ch16Ex04 {

	/**
	 * Exercise 4: (2) Create a Collection initializer that opens a file and breaks
	 * it into words using TextFile, and then uses the words as the source of data
	 * for the resulting Collection. Demonstrate that it works.
	 * 
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		List<String> list = new ArrayList<String>();
		
		BufferedReader br = new BufferedReader(new FileReader(new File("alma.txt")));
		String regex = " ";
		String read = null;
		while ((read = br.readLine()) != null) {
	        String[] splited = read.split(regex);
	        for (String part : splited) {
	            list.add(part);
	        }
	    }
		br.close();
	System.out.println(list);
	}
}

/*
[The, free, online, random, word, generator, tool, allows, you, to, create, any, number, of, random, words, you, need, for, your, project]
*/