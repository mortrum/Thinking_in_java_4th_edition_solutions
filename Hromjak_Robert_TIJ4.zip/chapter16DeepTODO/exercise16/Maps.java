package exercise16;

import static net.mindview.util.Print.print;
import static net.mindview.util.Print.printnb;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;

import net.mindview.util.CountingMapData;

class MapEntry<K, V> implements Map.Entry<K, V> {
	private K key;
	private V value;

	public MapEntry(K key, V value) {
		this.key = key;
		this.value = value;
	}

	public K getKey() {
		return key;
	}

	public V getValue() {
		return value;
	}

	public V setValue(V v) {
		V result = value;
		value = v;
		return result;
	}

	public int hashCode() {
		return (key == null ? 0 : key.hashCode()) ^ (value == null ? 0 : value.hashCode());
	}

	public boolean equals(Object o) {
		if (!(o instanceof MapEntry))
			return false;
		MapEntry me = (MapEntry) o;
		return (key == null ? me.getKey() == null : key.equals(me.getKey()))
				&& (value == null ? me.getValue() == null : value.equals(me.getValue()));
	}

	public String toString() {
		return key + "=" + value;
	}
}

class SlowMap<K, V> extends AbstractMap<K, V> {
	private List<K> keys = new ArrayList<K>();
	private List<V> values = new ArrayList<V>();

	public V put(K key, V value) {
		V oldValue = get(key); // The old value or null
		if (!keys.contains(key)) {
			keys.add(key);
			values.add(value);
		} else
			values.set(keys.indexOf(key), value);
		return oldValue;
	}

	public V get(Object key) { // key is type Object, not K
		if (!keys.contains(key))
			return null;
		return values.get(keys.indexOf(key));
	}

	public Set<Map.Entry<K, V>> entrySet() {
		Set<Map.Entry<K, V>> set = new HashSet<Map.Entry<K, V>>();
		Iterator<K> ki = keys.iterator();
		Iterator<V> vi = values.iterator();
		while (ki.hasNext())
			set.add(new MapEntry<K, V>(ki.next(), vi.next()));
		return set;
	}
}

public class Maps {
	public static void printKeys(Map<Integer, String> map) {
		printnb("Size = " + map.size() + ", ");
		printnb("Keys: ");
		print(map.keySet()); // Produce a Set of the keys
	}

	public static void test(Map<Integer, String> map) {
		print(map.getClass().getSimpleName());
		map.putAll(new CountingMapData(25));
		// Map has 'Set' behavior for keys:
		map.putAll(new CountingMapData(25));
		printKeys(map);
		// Producing a Collection of the values:
		printnb("Values: ");
		print(map.values());
		print(map);
		print("map.containsKey(11): " + map.containsKey(11));
		print("map.get(11): " + map.get(11));
		print("map.containsValue(\"F0\"): " + map.containsValue("F0"));
		Integer key = map.keySet().iterator().next();
		print("First key in map: " + key);
		map.remove(key);
		printKeys(map);
		map.clear();
		print("map.isEmpty(): " + map.isEmpty());
		map.putAll(new CountingMapData(25));
		// Operations on the Set change the Map:
		map.keySet().removeAll(map.keySet());
		print("map.isEmpty(): " + map.isEmpty());
	}

	/**
	 * Exercise 16: (7) Apply the tests in Maps.java to SlowMap to verify that it
	 * works. Fix anything in SlowMap that doesn�t work correctly.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		test(new SlowMap<Integer, String>());
	}
}

/*
SlowMap
Size = 25, Keys: [6, 0, 2, 4, 8, 10, 12, 14, 17, 19, 21, 23, 7, 1, 3, 5, 9, 11, 13, 15, 16, 18, 20, 22, 24]
Values: [G0, A0, C0, E0, I0, K0, M0, O0, R0, T0, V0, X0, H0, B0, D0, F0, J0, L0, N0, P0, S0, U0, W0, Y0, Q0]
{6=G0, 0=A0, 2=C0, 4=E0, 8=I0, 10=K0, 12=M0, 14=O0, 17=R0, 19=T0, 21=V0, 23=X0, 7=H0, 1=B0, 3=D0, 5=F0, 9=J0, 11=L0, 13=N0, 15=P0, 18=S0, 20=U0, 22=W0, 24=Y0, 16=Q0}
map.containsKey(11): true
map.get(11): L0
map.containsValue("F0"): true
First key in map: 6
Size = 25, Keys: [6, 0, 2, 4, 8, 10, 12, 14, 17, 19, 21, 23, 7, 1, 3, 5, 9, 11, 13, 15, 16, 18, 20, 22, 24]
map.isEmpty(): false
map.isEmpty(): false
*/