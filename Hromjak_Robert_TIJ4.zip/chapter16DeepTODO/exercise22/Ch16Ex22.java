package exercise22;

import java.util.Map;

import exercise19.SimpleHashMap;

public class Ch16Ex22 {
	/**
	 * Exercise 23: (3) Implement the rest of the Map interface for SimpleHashMap.
	 */
	public static void main(String[] args) {
		Map<String, Integer> map = new SimpleHashMap<>();
		map.put("Hello Ronald", 100);
		map.put("Hello Shen", 200);
		System.out.println(map.containsKey("Hello Ronald"));
	}
}

/*
true
*/