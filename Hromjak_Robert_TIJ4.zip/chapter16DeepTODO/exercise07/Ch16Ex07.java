package exercise07;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import net.mindview.util.Countries;

public class Ch16Ex07 {

	/**
	 * Exercise 7: (4) Create both an ArrayList and a LinkedList, and fill each
	 * using the Countries.names( ) generator. Print each list using an ordinary
	 * Iterator, then insert one list into the other by using a Listlterator,
	 * inserting at every othetir locaon. Now perform the insertion starting at the
	 * end of the first list and moving backward.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		List<String> list2 = new LinkedList<>();
		List<String> list3 = new LinkedList<>();
		List<String> list4 = new LinkedList<>();

		list.addAll(Countries.names(10));
		list2.addAll(Countries.names(10));

		for (String string : list) {
			System.out.print(string + " ");
		}

		System.out.println();

		for (String string : list2) {
			System.out.print(string + " ");
		}
		System.out.println();
		for (String string : list2) {
			list3.add(string);
		}
		Iterator<String> it = list2.iterator();
		while(it.hasNext()) {
			list4.add(0, it.next());
		}
		

		System.out.println(list3);
		System.out.println(list4);
	}
}
/*
ALGERIA ANGOLA BENIN BOTSWANA BURKINA FASO BURUNDI CAMEROON CAPE VERDE CENTRAL AFRICAN REPUBLIC CHAD 
ALGERIA ANGOLA BENIN BOTSWANA BURKINA FASO BURUNDI CAMEROON CAPE VERDE CENTRAL AFRICAN REPUBLIC CHAD 
[ALGERIA, ANGOLA, BENIN, BOTSWANA, BURKINA FASO, BURUNDI, CAMEROON, CAPE VERDE, CENTRAL AFRICAN REPUBLIC, CHAD]
[CHAD, CENTRAL AFRICAN REPUBLIC, CAPE VERDE, CAMEROON, BURUNDI, BURKINA FASO, BOTSWANA, BENIN, ANGOLA, ALGERIA]
*/