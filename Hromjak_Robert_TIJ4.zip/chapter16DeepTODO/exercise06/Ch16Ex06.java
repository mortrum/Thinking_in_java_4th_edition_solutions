
package exercise06;

import java.util.Arrays;
import java.util.List;

public class Ch16Ex06 {

	/**
	 * Exercise 6: (2) Note that List has additional "optional" operations that are
	 * not included in Collection. Write a version of Unsupported.java that tests
	 * these additional optional operations.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		List<String> list = Arrays.asList("alma", "korte");
		
		//! list.add("c");
	}
}
