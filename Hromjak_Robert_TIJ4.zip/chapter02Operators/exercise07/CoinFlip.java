package exercise07;

import java.util.Random;

public class CoinFlip {
	private boolean coin;
	
	void flip() {
		Random rand = new Random();
		if(rand.nextInt(2) > 0)
			coin = true;
		else
			coin = false;
		
		System.out.println(coin);
	}
	/**
	 * Exercise 7: (3) Write a program that simulates coin-flipping.
	 * @param args
	 * @return true (50 % match)
	 */
	public static void main(String[] args) {
		CoinFlip coinFlip = new CoinFlip();
		coinFlip.flip();
	}

}
