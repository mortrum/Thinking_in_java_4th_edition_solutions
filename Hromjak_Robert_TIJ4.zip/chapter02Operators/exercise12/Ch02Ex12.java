package exercise12;

public class Ch02Ex12 {

	/**
	 * Exercise 12: (3) Start with a number that is all binary ones. Left shift it,
	 * then use the unsigned right-shift operator to right shift through all of its
	 * binary positions, each time displaying the result using
	 * Integer.toBinaryString( ).
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		int i=-1;
        System.out.println(Integer.toBinaryString(i));
        i<<=10;
        System.out.println(Integer.toBinaryString(i));
        for(int j=0;j<32;j++){
            i>>>=1;
            System.out.println(Integer.toBinaryString(i));
		}
	}

}
/*
11111111111111111111111111111111
11111111111111111111110000000000
1111111111111111111111000000000
111111111111111111111100000000
11111111111111111111110000000
1111111111111111111111000000
111111111111111111111100000
11111111111111111111110000
1111111111111111111111000
111111111111111111111100
11111111111111111111110
1111111111111111111111
111111111111111111111
11111111111111111111
1111111111111111111
111111111111111111
11111111111111111
1111111111111111
111111111111111
11111111111111
1111111111111
111111111111
11111111111
1111111111
111111111
11111111
1111111
111111
11111
1111
111
11
1
0
*/