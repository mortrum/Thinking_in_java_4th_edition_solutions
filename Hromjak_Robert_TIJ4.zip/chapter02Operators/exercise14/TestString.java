package exercise14;

public class TestString {

	static void stringEquals(String s1, String s2) {
		System.out.println(s1 == s2);
		System.out.println(s1 != s2);
		System.out.println(s1.equals(s2));
	}
	/**
	 * Exercise 14: (3) Write a method that takes two String arguments and uses all
	 * the boolean comparisons to compare the two Strings and print the results. For
	 * the == and !=, also perform the equals( ) test. In main( ), call your method
	 * with some different String objects
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		stringEquals("alma", "beka");
		System.out.println("**********");
		stringEquals("alma", "alma");

	}
}
/*
false
true
false
**********
true
false
true
*/