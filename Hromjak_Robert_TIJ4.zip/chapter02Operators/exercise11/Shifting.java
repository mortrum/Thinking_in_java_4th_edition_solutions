package exercise11;

public class Shifting {

	/**
	 * Exercise 11: (3) Start with a number that has a binary one in the most
	 * significant position (hint: Use a hexadecimal constant). Using the signed
	 * right-shift operator, right shift it all the way through all of its binary
	 * positions, each time displaying the result using Integer.toBinaryString( ).
	 * 
	 * @param args
	 * @return 101
	 */
	public static void main(String[] args) {

		int i = 0x10000000;
		System.out.println(Integer.toBinaryString(i));
		for (int j = 0; j < 28; j++) {
			i >>>= 1;
			System.out.println(Integer.toBinaryString(i));
		}

	}
}
/*
10000000000000000000000000000
1000000000000000000000000000
100000000000000000000000000
10000000000000000000000000
1000000000000000000000000
100000000000000000000000
10000000000000000000000
1000000000000000000000
100000000000000000000
10000000000000000000
1000000000000000000
100000000000000000
10000000000000000
1000000000000000
100000000000000
10000000000000
1000000000000
100000000000
10000000000
1000000000
100000000
10000000
1000000
100000
10000
1000
100
10
1
*/