package exercise01;

import static java.lang.System.out;

public class Print {
	/**
	 * Exercise 1: (1) Write a program that uses the �short� and normal form of
	 * print statement.
	 * 
	 * @param args
	 * @return short form 
	 * normal form
	 */
	public static void main(String[] args) {
		out.println("short form");
		System.out.println("normal form");
	}
}
