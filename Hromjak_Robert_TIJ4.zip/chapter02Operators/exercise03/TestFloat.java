package exercise03;

public class TestFloat {
	float f;

	void printFloat() {
		System.out.println(f);
	}

	/**
	 * Exercise 3: (1) Create a class containing a float and use it to demonstrate
	 * aliasing during method calls.
	 * 
	 * @param args
	 * @return 0.0
	 */
	public static void main(String[] args) {
		TestFloat testFloat = new TestFloat();
		testFloat.printFloat();
	}

}
