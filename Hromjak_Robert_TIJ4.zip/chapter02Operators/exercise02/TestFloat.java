package exercise02;

public class TestFloat {
	float f;
	/**
	 * Exercise 2: (1) Create a class containing a float and use it to demonstrate aliasing. 
	 * @param args
	 * @return 0.0
	 */
	public static void main(String[] args) {
		TestFloat testFloat = new TestFloat();
		System.out.println(testFloat.f);
	}

}
