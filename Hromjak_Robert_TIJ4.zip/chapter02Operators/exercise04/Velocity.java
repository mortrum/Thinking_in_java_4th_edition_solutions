package exercise04;

public class Velocity {
	float velocytyCalc(float distance, float time) {
		return distance / time;
	}

	/**
	 * Exercise 4: (2) Write a program that calculates velocity using a constant
	 * distance and a constant time.
	 * 
	 * @param args
	 * @return 2.5
	 */
	public static void main(String[] args) {
		Velocity velocity = new Velocity();
		System.out.println(velocity.velocytyCalc(10, 4));
	}
}
