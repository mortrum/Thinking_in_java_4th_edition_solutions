package exercise08;

public class Test {

	/**
	 * Exercise 8: (2) Show that hex and octal notations work with long values. Use
	 * Long.toBinaryString( ) to display the results.
	 * 
	 * @param args
	 * @return 11111111 1001
	 */
	public static void main(String[] args) {
		long longHex = 0xff; // hex
		long longOct = 011; // oct
		System.out.println(Long.toBinaryString(longHex));
		System.out.println(Long.toBinaryString(longOct));
	}

}
