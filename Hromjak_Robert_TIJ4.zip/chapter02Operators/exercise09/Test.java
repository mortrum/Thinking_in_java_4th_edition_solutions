package exercise09;

public class Test {

	/**
	 * Exercise 9: (1) Display the largest and smallest numbers for both float and
	 * double exponential notation.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(Float.MIN_VALUE);
		System.out.println(Float.MAX_VALUE);
		System.out.println(Double.MIN_VALUE);
		System.out.println(Double.MAX_VALUE);

	}
}
/*
1.4E-45
3.4028235E38
4.9E-324
1.7976931348623157E308
*/