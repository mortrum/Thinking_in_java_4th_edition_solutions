package exercise13;

public class Test {

	static void f(char c) {
		System.out.println(Integer.toBinaryString(c));
		
	}
	/**
	 * Exercise 13: (1) Write a method that displays char values in binary form.
	 * Demonstrate it using several different characters.
	 * 
	 * @param args
	 * @return 1000001
	 */
	public static void main(String[] args) {
		f('A');
	}

}
