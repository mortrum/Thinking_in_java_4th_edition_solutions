package exercise05;

public class Dog {

	String name;
	String says;

	public Dog(String name, String says) {
		this.name = name;
		this.says = says;
	}

	@Override
	public String toString() {
		return "name=" + name + ", says=" + says;
	}

	/**
	 * Exercise 5: (2) Create a class called Dog containing two Strings: name and
	 * says. In main( ), create two dog objects with names �spot� (who says,
	 * �Ruff!�) and �scruffy� (who says, �Wurf!�). Then display their names and what
	 * they say.
	 * 
	 * @param args
	 * @return name=spot, says=Ruff! name=scruffy, says=Wurf!
	 */
	public static void main(String[] args) {
		Dog dog1 = new Dog("spot", "Ruff!");
		Dog dog2 = new Dog("scruffy", "Wurf!");
		System.out.println(dog1 + " " + dog2);
	}

}
